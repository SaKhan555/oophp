<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Application Name
    |--------------------------------------------------------------------------
    |
    | This value is the name of your application. This value is used when the
    | framework needs to place the application's name in a notification or
    | any other location as required by the application or its packages.
    */

    'accounts' => [
        'name' => 'Finance Dept',
        'email' => 'finance@abtach.org',
        'designation' => 'Accounts Department',
    ],
    'roles' => [
        'admin' => 'Admin',
        // 'finance' => 'Finance',
        // 'auditor' => 'Auditor',
        // 'assistant' => 'Assistant',
        // 'marketing' => 'Marketing',
        'hr' => 'HR',
        'manager' => 'Manager',
        // 'employee' => 'Employee',
        // 'executive' => 'Executive',
		// 'fleet-manager' => 'Fleet Manager',
    ],
    'type' => ['Brand'=>'Brand', 'Client'=>'Client', 'Admin' => 'Admin'],
    'emails' => [
        'cc_default' => 'Saad.Iqbal@abtach.org',
        'salmanyousuf' => 'Salman.Yousuf@abtach.org',
        'azneembilwani' => 'azneemb@hotmail.com',
        'hr' => 'hr@abtach.org',
    ],
    'IT_emails' => [
        'Asif.Aleem@abtach.org',
        'Farhan.Nyaz@abtach.org',
        'Usman.Sheikh@abtach.org',
        'Asif.UrRehman@abtach.org'
    ],
    'HR_emails' => [
        'Umema.Ali@abtach.org'
    ],
    'finance_emails' => [
        'Younus.Dawood@abtach.org',
        'M.khurram@abtach.org',
        'Muhammad.Owais@abtach.org',
        'Hassan.Amin@abtach.org'
    ],
    'admin_emails' => [
        'Muhammad.Ashraf@abtach.org',
    ],
];