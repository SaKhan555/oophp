<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Application Name
    |--------------------------------------------------------------------------
    |
    | This value is the name of your application. This value is used when the
    | framework needs to place the application's name in a notification or
    | any other location as required by the application or its packages.
    */
    'sms' => [
        'create' => 'admin.sms.create',
        'view' => 'admin.sms.index',
        'store' => 'admin.sms.store',
    ],
    'expense' => [
        'upload excel' => 'admin.expense.excel.upload',
        'save excel' => 'admin.expense.excel.upload_save',
    ],
    'job subscription' => [
        'view' => 'admin.job-subscription.index',
        'delete' => 'admin.job-subscription.destroy',
    ],
    'user' => [
        'create' => 'admin.user.create',
        'store' => 'admin.user.store',
        'view' => 'admin.user.index',
        'edit' => 'admin.user.edit',
        'update' => 'admin.user.update',
        'delete' => 'admin.user.destroy',
        'show' => 'admin.user.show'
    ],
    'attendence' => [
        'create' => 'admin.attendence.create',
        'store' => 'admin.attendence.store',
        'view' => 'admin.attendence.index',
        'edit' => 'admin.attendence.edit',
        'update' => 'admin.attendence.update',
        'delete' => 'admin.attendence.destroy',
        'show' => 'admin.attendence.show'
    ],
    'letter' => [
        'create' => 'admin.letter.create',
        'store' => 'admin.letter.store',
        'view' => 'admin.letter.index',
        'edit' => 'admin.letter.edit',
        'update' => 'admin.letter.update',
        'delete' => 'admin.letter.destroy',
        'show' => 'admin.letter.show'
    ],
    'job' => [
        'create' => 'admin.job.create',
        'store' => 'admin.job.store',
        'view' => 'admin.job.index',
        'edit' => 'admin.job.edit',
        'update' => 'admin.job.update',
        'delete' => 'admin.job.destroy',
        'show' => 'admin.job.show'
    ],
    'employee' => [
        'create' => 'admin.employee.create',
        'store' => 'admin.employee.store',
        'view' => 'admin.employee.index',
        'edit' => 'admin.employee.edit',
        'update' => 'admin.employee.update',
        'delete' => 'admin.employee.destroy',
        'show' => 'admin.employee.show',
        'upload' => 'admin.employee.excel.upload',
        'generate letter' => 'admin.employee.generate_letter',
        'view generated letters' => 'admin.employee.letters',
        'edit status' => 'admin.employee.status.edit',
        'update status' => 'admin.employee.status.update',
        'edit salary' => 'admin.employee.salary.edit',
        'update salary' => 'admin.employee.salary.update',
        'edit designation' => 'admin.employee.designation.edit',
        'update designation' => 'admin.employee.designation.update',
        'edit shift' => 'admin.employee.shift',
        'upload excel' => 'admin.employee.excel.save',
        'vehicle close' => 'admin.employee.vehicle.close',
        'vehicle close update' => 'admin.employee.vehicle.close.update',
    ],
    'vehicle' => [
        'create' => 'admin.vehicle.create',
        'store' => 'admin.vehicle.store',
        'view' => 'admin.vehicle.index',
        'edit' => 'admin.vehicle.edit',
        'update' => 'admin.vehicle.update',
        'delete' => 'admin.vehicle.destroy',
        'show' => 'admin.vehicle.show',
        'vehicle status' => 'admin.vehicle.status',
        'employee vehicle' => 'admin.vehicle.employee',
        'employee vehicle save' => 'admin.vehicle.employee.add',
        'view departments' => 'admin.employee.departments',
        'update department' => 'admin.employee.departments.store',
        'view managers' => 'admin.employee.managers',
        'update manager' => 'admin.employee.departments.managers.store',
    ],
    'job category' => [
        'create' => 'admin.job-category.create',
        'store' => 'admin.job-category.store',
        'view' => 'admin.job-category.index',
        'edit' => 'admin.job-category.edit',
        'update' => 'admin.job-category.update',
        'delete' => 'admin.job-category.destroy',
        'show' => 'admin.job-category.show',
        'update status' => 'admin.job-category.update_status'
    ],
];