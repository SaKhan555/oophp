<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Agent extends Model
{
    protected $guarded = ['id'];

    // belongs to an employee
    public function employee()
    {
    	return $this->belongsTo(Employee::class,'employee_id','employee_id');
    }
    // belongs to many brands
    public function brands()
    {
    	return $this->belongsToMany(Brand::class,'agent_brands');
    }
    // has many brands with targets
    public function brands_with_targets()
    {
        return $this->hasMany(AgentBrand::class, 'agent_id');
    }
    // belongs to many depratments
    public function departments()
    {
    	return $this->belongsToMany(Department::class,'agent_departments');
    }
    // has many agent brands
    public function agent_brands()
    {
        return $this->hasMany(AgentBrand::class);
    }
}
