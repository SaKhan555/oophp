<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Role extends Model
{
	protected $guarded = ['id'];

    // has many users
    public function users()
    {
    	return $this->hasMany(User::class);
    }
    // total users
    public function total_users()
    {
    	return $this->users()->count();
    }
    // permissions
    public function permissions()
    {
    	return json_decode($this->permissions);
    }
}
