<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class EmployeeNotification extends Model
{
    protected $guarded = ['id'];

}
