<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class EmployeeLetter extends Model
{
    protected $guarded = ['id'];

    /**
     * belongs to letter
     */
    public function letter()
    {
    	return $this->belongsTo(Letter::class);
    }
    /**
     * belongs to employee
     */
    public function employee()
    {
    	return $this->belongsTo(Employee::class);
    }
    /**
     * letter file path
     */
    public function filePath()
    {
        return '/uploads/letters/'.$this->filename;
    }
}
