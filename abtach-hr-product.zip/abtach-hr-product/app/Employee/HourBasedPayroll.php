<?php

namespace App\Employee;

use App\Employee;
use App\Employee\Attendance;
use Carbon\Carbon;

class HourBasedPayroll
{
    private $employee;
    private $month;
    private $year;
    private $total_year_salary;
    public $additions;
    public $deductions;
    public $actual_salary;
    public $gross_salary;
    public $net_salary;
    public $extra_days_salary;
    public $per_day_salary;

    public function __construct(Employee $employee, $month)
    {
        $this->employee = $employee;
        $this->total_days = $this->total_month_days();
        $this->month = explode('-', $month)[0];      
        $this->year = explode('-', $month)[1];      
        $this->actual_salary = $employee->salary_for_month($this->month, $this->year);
        $this->net_salary = 0;
        $this->gross_salary = $this->actual_salary;
        $this->init();
    }

    // initialize
    private function init()
    {
        $this->calculate_days();
        // per day salary
        $this->per_day_salary = floor($this->actual_salary / $this->total_days);
        // calculate additions and deductions
        $this->calculate_additions();
        $this->calculate_deductions();
        // calculate yearly taxable salary 
        $this->total_taxable_salary = $this->yearly_taxable_salary();
        // calculate tax
        $this->calculate_income_tax();
        // calculate salary
        $this->calculate_salary();
    }
    // total month days
    public function total_month_days()
    {
        $month = carbon()->now();
        if($month->format('d') > 25){
            $month = $month->addMonth();
        }
        $total_days = cal_days_in_month(CAL_GREGORIAN, $month->format('m'), $month->format('Y'));
        return $total_days;
    }
    // calculate days
    private function calculate_days()
    {
        $month = $this->month;
        $year = $this->year;
        $checkinouts = period_interval(carbon()->parse("26-$month-$year")->subMonths(1));
        $this->days = [];
        foreach($checkinouts as $day) {
            $this->days[] = formatDate($day, 'd-m-Y');
        }
    }
    // calculate additions
    private function calculate_additions()
    {
        $actual_salary = $this->actual_salary;
        $calculated_salary = (($actual_salary - 775));
        $salary_percent = ($calculated_salary / 155);
        $this->additions['house_rent'] = floor(($salary_percent * 45));
        $this->additions['medical'] = floor(($salary_percent * 10));
        $this->additions['basic'] = floor(($calculated_salary - $this->additions['house_rent'] - $this->additions['medical']));
        $this->additions['cola'] = 475;
        $this->additions['special'] = 300;
        $this->additions['arrears'] = $this->employee->arrears($this->month, $this->year);
    }
    // calculate deductions
    private function calculate_deductions()
    {
        $days = $this->days;
        $employee = $this->employee;
        $month_attendance_data = array_map(function($day) use($employee){
            $current_attendance = new Attendance($employee, $day);
            return [
                'late_in' => ($current_attendance->actual_status() == 'late in'),
                'early_out' => ($current_attendance->actual_status() == 'early out'),
                'absent' => ($current_attendance->actual_status() == 'absent'),
                'half_day' => ($current_attendance->actual_status() == 'half day'),
                'extra_day' => ($employee->department_id == 2 && $current_attendance->actual_status() == 'extra day') 
            ];
        }, $days);
        $this->deductions['late_ins'] = count(array_filter($month_attendance_data, function($i){
            return $i['late_in'] == 1;
        }));
        $this->deductions['early_outs'] = count(array_filter($month_attendance_data, function($i){
            return $i['early_out'] == 1;
        }));
        $this->deductions['absents'] = count(array_filter($month_attendance_data, function($i){
            return $i['absent'] == 1;
        }));
        $this->deductions['half_days'] = count(array_filter($month_attendance_data, function($i){
            return $i['half_day'] == 1;
        }));
        $this->additions['extradays'] = count(array_filter($month_attendance_data, function($i){
            return $i['extra_day'] == 1;
        }));
        $this->deductions['eobi'] = $this->eobi();
        $this->deductions['loan'] = $this->loan();
    }
    // income tax
    private function calculate_income_tax()
    {
        $prev_year = carbon()->now()->subYear()->format('Y');
        $current_year = carbon()->now()->format('Y');
        $current_month = carbon()->now()->format('m');
        $paid_taxes = $this->employee->paid_taxes();
        if(carbon()->now()->format('m') > 06){
            $paid_taxes = $paid_taxes->whereYear('month', '=', $current_year)
                                        ->whereMonth('month', '>=', '07');
        } else {
            $paid_taxes = $paid_taxes->where(function($q){
                return $q->whereYear('month', '=', $prev_year)
                            ->whereMonth('month', '>=', '07');
            })->orWhere(function($q){
                return $q->whereYear('month', '=', $current_year)
                        ->whereMonth('month', '<', $current_month);
            });
        }
        $total_year_salary = $this->total_taxable_salary+$this->calculate_incentives();
        $paid_taxes = $paid_taxes->pluck('amount')->toArray();
        $total_paid_tax = array_sum($paid_taxes);
        $remaining_months = (12 - count($paid_taxes));
        if($total_year_salary > 400000 && $total_year_salary <= 800000){
            // if salary exceeds 4 lac but does'nt exceeds 8 lac
            $total_tax = 1000;
        } elseif($total_year_salary > 800000 && $total_year_salary <= 1200000) {
            // if salary exceeds 8 lac but does'nt exceeds 12 lac
            $total_tax = 3000;
        } elseif($total_year_salary > 1200000 && $total_year_salary <= 2400000) {
            // if salary exceeds 12 lac but does'nt exceeds 24 lac
            // 5% of amount exceeds 12 lac or 2000 the greater one
            $tax_amount = ((($total_year_salary - 1200000) * 5) / 100);
            // $total_tax = (($tax_amount < 2000) ? 2000 : $tax_amount) + 3000;
            $total_tax = $tax_amount + 3000;
        } elseif($total_year_salary > 2400000 && $total_year_salary <= 4800000) {
            // if salary exceeds 24 lac but does'nt exceeds 48 lac
            // 60 thousand + 10% of amount exceeds 24 lac
            $total_tax = (63000 + ( (($total_year_salary - 2400000) * 10) / 100 ) );
        } elseif($total_year_salary > 4800000) {
            // if salary exceeds 2400000 lac
            // 30 thousand + 15% of amount exceeds 48 lac
            $total_tax = (303000 + ( (($total_year_salary - 4800000) * 15) / 100 ) );
        } else {
            $total_tax = 0;
        }
        $income_tax = floor((($total_tax - $total_paid_tax))/$remaining_months);
        $this->deductions['income_tax'] = $income_tax;
    }
    // last incentive
    private function calculate_incentives()
    {
        $employee = $this->employee;
        $current = carbon()->now();
        $year = $current->format('Y');
        $current_month = $current->format('m');
        if($current_month <= 06){
            $year = $current->subYear()->format('Y');
        }
        $month = carbon()->parse("first day of june ".$year);
        $incentive_amount = 0;
        $latest_incentive = $employee->incentives()->whereYear('date', '=', $year)->orderBy('date', 'desc')->pluck('amount')->first();
        for ($i = 0; $i < 12; $i++) {
            $month = $month->addMonth();
            $incentive = $employee->incentives()
                                ->whereMonth('date', '=', $month->format('m'))
                                ->whereYear('date', '=', $month->format('Y'))
                                ->pluck('amount')->first();
            $incentive_amount += ($incentive) ? $incentive : $latest_incentive;
        }
        return $incentive_amount;
    }
    // eobi
    private function eobi()
    {
        $total_month_days = $this->total_days;
        $perday_eobi = (150/$total_month_days);
        $join_date = carbon()->parse($this->employee->join_date);
        if($join_date->format('m') == carbon()->now()->format('m')){
            $subtract_eobi = str_replace('0', '', $join_date->format('d'));
        } else {
            $subtract_eobi = 0;
        }
        $eobi = ($this->actual_salary >= 15000) ? ((15000/100) - ($perday_eobi * $subtract_eobi)) : 0;
        return $eobi;
    }
    // load
    private function loan()
    {
        return 0;
    }
    // calculate salary
    private function calculate_salary()
    {
        $employee = $this->employee;
        $deductions = $this->deductions;
        $actual_salary = $this->actual_salary;
        $deducted_salary = $this->calculate_deducted_salary();
        $extra_days_salary = ($this->per_day_salary * $this->additions['extradays']);
        $this->extra_days_salary = $extra_days_salary;
        $this->additions['extra_days_salary'] = $extra_days_salary;
        $this->gross_salary += ($extra_days_salary + $this->additions['arrears']);
        $net_salary = floor($this->gross_salary - $deducted_salary);
        $this->net_salary = (($net_salary + $extra_days_salary) - $this->deductions['eobi']) - $this->deductions['income_tax'];
    }
    // calculate deducted salary
    private function calculate_deducted_salary()
    {
        $per_day_salary = $this->per_day_salary;
        $employee = $this->employee;
        $deductions = $this->deductions;
        if($employee->is_flexible_timing){
            $deduction_days = $deductions['absents'];
        } elseif(strtolower($employee->sex) == 'female' && in_array(strtolower($employee->current_status), ['probation', 'permanent'])){
            $deduction_days = (((floor(($deductions['early_outs']) / 3) / 2)) + ($deductions['half_days'] / 2)) + $deductions['absents'];
        } else {
            $deduction_days = (((floor(($deductions['late_ins'] + $deductions['early_outs']) / 3) / 2)) + ($deductions['half_days'] / 2)) + $deductions['absents'];
        }
        return floor($per_day_salary * $deduction_days);
    }
    // taxable salary
    private function yearly_taxable_salary()
    {
        $current_taxable_salary = ($this->actual_salary - ((($this->actual_salary - 775) / 155) * 10));
        $current_taxable_salary -= $this->calculate_deducted_salary();
        return $this->employee->current_year_taxable_salary() + $current_taxable_salary + $this->additions['arrears'];
    }
}
