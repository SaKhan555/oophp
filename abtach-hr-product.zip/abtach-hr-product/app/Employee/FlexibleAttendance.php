<?php

namespace App\Employee;

use App\Employee;
use Carbon\Carbon;
use App\EmployeeAttendancePolicy;
use App\EmployeeAttendanceLog;
use App\EmployeeAttendanceDiscrepancy;

class FlexibleAttendance
{
	private $employee;
    private $date;
    private $day;
	private $offdays;
    private $check_in_grace;
    private $check_out_grace;
    private $half_day_grace;
	public $shift;
    public $duty_hours;
    public $check_in_id;
	public $check_in;
	public $check_in_timestamp;
    public $check_out_id;
	public $check_out;
	public $check_out_timestamp;
	public $working_hours;
	public $late_hours;
	public $is_half_day;
	public $attend_status;
	public $check_in_status;
	public $check_out_status;

    public function __construct(Employee $employee, $date)
    {
    	$this->employee = $employee;
    	$this->date = $date;
        $this->day = carbon()->parse($date);
        $this->offdays = ['saturday','sunday'];
    	$this->init();
    }
    // initialize
    private function init()
    {
    	$date = $this->date;
    	$this->shift = $this->employee->shift($date);
        $this->duty_hours = $this->duty_hours();

        // set policy
        $policy = EmployeeAttendancePolicy::whereDate('effective_date', '<=', formatDate($date, 'Y-m-d'))->orderBy('effective_date', 'desc')->first();
        $this->check_in_grace = $policy->check_in_grace;
        $this->check_out_grace = $policy->check_out_grace;
        $this->half_day_grace = $policy->half_day_grace;

        $checked_in = $this->check_in();
        if($checked_in) {
            $this->check_in_id = $checked_in->id;
        	$this->check_in = formatDate($checked_in->checked_at, 'h:i A');
        	$this->check_in_timestamp = formatDate($checked_in->checked_at, 'Y-m-d H:i:s');
        }

        $checked_out = $this->check_out();
        if($checked_out) {
            $this->check_out_id = $checked_out->id;
        	$this->check_out = formatDate($checked_out->checked_at, 'h:i A');
        	$this->check_out_timestamp = formatDate($checked_out->checked_at, 'Y-m-d H:i:s');
        }

    	$this->working_hours = $this->working_hours();
    	$this->late_hours = $this->late_hours();
    	$this->is_half_day = $this->is_half_day();
    	$this->attend_status = $this->attend_status();
    	$this->check_in_status = $this->check_in_status();
    	$this->check_out_status = $this->check_out_status();
    }
    // duty hours
    private function duty_hours()
    {
        $shift = $this->shift;
        $date = formatDate($this->date, 'Y-m-d');
        $current_status = $this->employee->employee_status()->where('status' , 'Contractual')->whereDate('status_at', '<=', $date)->whereDate('end_at', '>=', $date)->orderBy('status_at', 'desc')->pluck('status')->first();
        if(strtolower($current_status) == 'contractual'){
            return 6;
        } else {
            if($shift) {
                $shift_time_in = carbon()->parse($shift->check_in);
                $shift_time_out = carbon()->parse($shift->check_out);
                if(explode(' ',$shift->check_in)[1] == 'PM' && explode(' ',$shift->check_out)[1] == 'AM') {
                    $shift_time_out = $shift_time_out->addDays(1);
                    $duty_hours = $shift_time_out->diffInHours($shift_time_in);
                } else {
                    $duty_hours = $shift_time_out->diffInHours($shift_time_in);
                }
                return $duty_hours;
            }
        }
    }
    // check in
    private function check_in()
    {
    	$employee = $this->employee;
        $date = formatDate($this->date, 'Y-m-d');
        $shift = $this->shift;
        if($shift){
            $shift_time_in = $shift->check_in;
            $shift_time_out = $shift->check_out;
            if($shift_time_in && $shift_time_out){
                if((strtolower(explode(' ',$shift_time_in)[1]) == 'pm') && (strtolower(explode(' ',$shift_time_out)[1]) == 'am')){
                    $shift_time_in = carbon()->createFromFormat('h:i A',$shift_time_in)
                        ->subHours(3)
                        ->format('h:i A');
                    $checked_in = $employee->employee_attendance()->whereDate('checked_at', $date)->whereTime('checked_at','>=', date("H:i", strtotime($shift_time_in)))->whereStatus('01')
                        ->orderBy('checked_at','asc')->first();
                    if(!$checked_in){
                        $date_new = carbon()->parse($date)->addDays(1)->format('Y-m-d');
                        $checked_in = $employee->employee_attendance()->whereDate('checked_at', $date_new)->whereTime('checked_at','<', date("H:i", strtotime($shift_time_out)))->whereStatus('01')
                        ->orderBy('checked_at','asc')->first();
                    }
                } else {
                    $shift_time_in = carbon()->createFromFormat('h:i A',$shift_time_in)
                        ->subHours(5)
                        ->format('h:i A');
                    $checked_in = $employee->employee_attendance()->whereTime('checked_at' , '>=', $shift_time_in)->whereDate('checked_at', $date)->whereStatus('01')
                        ->orderBy('checked_at','asc')->first();
                }
            }
            return ($checked_in) ? $checked_in : '';
        } 
        return '';
    }

    // check out
    private function check_out()
    {
    	$date = $this->date;
    	$employee = $this->employee;
        $shift = $this->shift;
        if($shift){
            $shift_time_in = $shift->check_in;
            $shift_time_out = $shift->check_out;
            // convert shift time in to 24 hours format
            $shift_time_24_hours = carbon()->createFromFormat('h:i A', $shift_time_in)->format('H:i');
            $date = Carbon::parse($date.' '.$shift_time_in)->addHours(9)->format('Y-m-d H:i:s');
            $datenew = formatDate($date, 'Y-m-d');
            if(($shift_time_in && strtolower(explode(' ',$shift_time_in)[1]) == 'pm') && ($shift_time_out && strtolower(explode(' ',$shift_time_out)[1]) == 'am')){
                $shift_time_in_new = carbon()->createFromFormat('h:i A', $shift_time_in)->subHours(4)->format('h:i A');
                $checked_out = $employee->employee_attendance()->whereTime('checked_at','<', date("H:i", strtotime($shift_time_in_new)))->whereDate('checked_at',$datenew)->whereStatus('02')->orderBy('checked_at','desc')->first();
                if(!$checked_out){
                    $datenew = Carbon::parse($datenew)->subDay(1)->format('Y-m-d');
                    $checked_out = $employee->employee_attendance()->whereTime('checked_at','>', $shift_time_24_hours)->whereDate('checked_at',$datenew)->whereStatus('02')->orderBy('checked_at','desc')->first();
                }
            } else {
                $checked_out = $employee->employee_attendance()->whereTime('checked_at','>', $shift_time_24_hours)->whereDate('checked_at', $datenew)->whereStatus('02')->orderBy('checked_at','desc')->first();
                // if(!$checked_out){
                    $datenew = Carbon::parse($datenew)->addDay(1)->format('Y-m-d');
                    $shift_time_in = Carbon::parse($shift_time_in)->subHours(2)->format('H:i A');
                    $checked_out_2 = $employee->employee_attendance()->whereTime('checked_at','<', $shift_time_in)->whereDate('checked_at',$datenew)->whereStatus('02')->orderBy('checked_at','desc')->first();
                // }
            }
            if(isset($checked_out_2)){
                return $checked_out_2;
            } elseif($checked_out) {
                return $checked_out;
            } else {
                return '';
            }
        }
        return '';
    }

    // working hours
    private function working_hours()
    {
    	$date = $this->date;
        $check_in = $this->check_in;
        $check_out = $this->check_out;
        if($check_in && $check_out) {
            $to = Carbon::parse($this->check_out_timestamp);
            $from = Carbon::parse($this->check_in_timestamp);
            return $to->diff($from)->format('%H:%I');
        }
        return '';
    }

    // late hours
    private function late_hours()
    {
    	$employee = $this->employee;
        $check_in = ($this->check_in) ? Carbon::parse($this->check_in) : '';
        $check_in_status = $this->check_in_status();
        $shift = $this->shift;
        if($shift) {
            $shift_time_in = carbon()->parse($shift->check_in);
            if($check_in && $shift_time_in) {
                $late_hours = $check_in->diff($shift_time_in)->format('%H:%I');
                if($check_in->lessThan($shift_time_in)) {
                    $late_hours .= ' (early)';
                } elseif($check_in_status == 'late') {
                    $late_hours .= ' (late)';
                } else {
                    $late_hours .= ' (grace)';
                }
                return $late_hours;
            }
        }
        return '';
    }

     // late hours
    public function is_half_day()
    {
        $status = false;
        if($this->on_leave()){
            $status = false;
        } else {
            if($this->working_hours){
                $worked_time = explode(':', $this->working_hours);
                $worked_hours = $worked_time[0];
                $worked_minutes = $worked_time[1];
                $min_hours = ($this->duty_hours - $this->half_day_grace['hours']);
                if(($worked_hours < $min_hours) || (($worked_hours == $min_hours) 
                    && $worked_minutes < 00)){
                    $status = true;
                }
            }
        }
        return $status;
    }

    // attend status
    public function attend_status()
    {
    	$check_in = $this->check_in;
    	$check_out = $this->check_out;
        $output = '';
        $attend_status = function($status,$title='') {
            return "<span class='attend-status attend-$status' title='$title'></span>";
        };
        if($check_in && $check_out){
            $output = $attend_status('both', 'Checked in and checked out');
        } elseif($check_in && !$check_out) {
            $output = $attend_status('checkin','Only checked in');
        } elseif($check_out && !$check_in) {
            $output = $attend_status('checkout','Only checked out');
        } else {
            $output = $attend_status('none','No Checked in and Checked out');
        }
        return $output;
    }

    // check in status
    public function check_in_status()
    {
        return 'normal';
    }

    // check out status
    public function check_out_status()
    {
        $status = 'normal';
        if($this->working_hours){
            $worked_time = explode(':', $this->working_hours);
            $worked_hours = $worked_time[0];
            $worked_minutes = $worked_time[1];
            $min_hours = ($this->duty_hours - $this->check_out_grace['hours']);
            // if(($this->duty_hours > $worked_hours) && ($worked_minutes < $this->check_out_grace['minutes'])) {
            //     $status = 'early';
            // }
            if(($worked_hours < $min_hours) && ($this->check_out_grace['minutes'] > $worked_minutes)){
                $status = 'early';
            }
        }
        return $status;
    }

    // in status
    public function in_status()
    {
        $in_status = $this->check_out_status;
        return function($status='') use($in_status) {
            return $in_status == $status;
        };
    }

    // in status class
    public function in_status_class($check_in_status)
    {
        switch ($check_in_status) {
            case 'early':
                $status_class = 'alert-success';
                break;
            case 'late':
                $status_class = 'alert-danger';
                break;
            default:
                $status_class = '';
                break;
        }
        return $status_class;
    }
    // is off day
    public function is_off()
    {
        $day = strtolower(formatDate($this->date, 'l'));
        $holiday = \App\EmployeeHoliday::where("date","=",formatDate($this->date, 'Y-m-d'))->first();
        return (in_array($day, $this->offdays) || $holiday); 
    }
    // is off day
    public function is_absent()
    {
        if($this->on_leave()){
            return false;
        } //elseif($this->day->lessThan(carbon()->now()->format('Y-m-d')) && strtotime($this->working_hours) < strtotime('4:30')) {
            //return true;
        //}
         else {
            $shift = $this->shift;
            $shift_time_24_hours = ($shift) ? carbon()->createFromFormat('h:i A',$shift->check_in)->format('H:i') : '';
            $date = carbon()->parse($this->date.' '.$shift_time_24_hours);
            return ($date->lessThanOrEqualTo(carbon()->now()) && (!$this->check_in && !$this->check_out));
        } 
    }
    // 
    public function on_leave()
    {
        $date = formatDate($this->date, 'Y-m-d');
        $leave_approved = $this->employee->leave_applications()->where(function($q) use($date){
            return $q->whereDate('start_date', '<=' , $date)
                        ->whereDate('end_date', '>=' , $date);
        })->where('status', 1)->first();
        if($leave_approved){
            return true;
        }
        return false;
    }
    // is off day
    public function status_color()
    {
        $output = '';
        if($this->is_off()) {
            $output .='<span class="label label-status label-default" title="Holiday">&nbsp;</span> ';
        } elseif($this->on_leave()){
            return '<i class="fa fa-envelope text-success" title="on Leave"></i>';
        } elseif($this->is_absent()){
            return '<span class="label label-status label-danger" title="Absent">&nbsp;</span>';
        }
        if($this->is_half_day()) {
            $output .= '<span class="label label-status label-warning" title="Half-day">&nbsp;</span> ';
        } 
        if($this->check_in_status == 'late') {
            $output .= '<span class="label label-status label-danger-light" title="Late in">&nbsp;</span> ';
        } 
        if($this->check_in_status == 'early') {
            $output .= '<span class="label label-status label-success" title="Early in">&nbsp;</span> ';
        } 
        if($this->check_out_status == 'early') {
            $output .= '<span class="label label-status label-primary" title="Early out">&nbsp;</span> ';
        }
        if($this->check_out_status == 'late') {
            $output .= '<span class="label label-status label-info" title="Late out">&nbsp;</span> ';
        }
        if(!$output){
            $output .= '<span class="label label-status label-blank" title="Normal">&nbsp;</span> ';
        }
        return $output;
    }

    /**
     * actual status
     */
    public function actual_status()
    {
        $actual_status = "normal";
        if($this->is_off() && ($this->check_in)){
            $worked_hours = (explode(':', $this->working_hours))
                            ? explode(':', $this->working_hours)[0]
                            : 0;
            if($worked_hours >= 7 ){
                $actual_status = "extra day";
            } elseif($worked_hours >= 4) {
                $actual_status = "extra half day";
            }
        }elseif($this->on_leave()){
            $actual_status = "on leave";
        } elseif($this->is_off()) {
            if(request('is_admin')){
                switch (carbon()->parse($this->date)->format('l')) {
                    case "Saturday":
                        $friday = carbon()->parse($this->date)->subDay();
                        $monday = carbon()->parse($this->date)->addDays(2);
                        break;
                    case "Sunday":
                        $friday = carbon()->parse($this->date)->subDays(2);
                        $monday = carbon()->parse($this->date)->addDay();
                        break;
                }
                $friday_attendance = new Attendance($this->employee, $friday->format('d-m-Y'));
                $monday_attendance = new Attendance($this->employee, $monday->format('d-m-Y'));
                if($friday_attendance->actual_status() == 'absent' && $monday_attendance->actual_status() == 'absent'){
                    $actual_status = 'absent';
                } else {
                    $actual_status = 'holiday';
                }
            } else {
                $actual_status = "holiday";
            }
        } elseif($this->is_absent()) {
            $actual_status = "absent"; 
        } elseif($this->is_half_day()) {
            $actual_status = "half day";
        } elseif($this->check_in_status() == 'late') {
            $actual_status = "late in";
        } elseif($this->check_out_status() == 'early') {
            $actual_status = "early out";
        }
        return $actual_status;
    }
    // is editable
    public function is_editable()
    {
        $previous_month = carbon()->now()->subMonth()->format('m');
        $current_month = carbon()->now()->format('m');
        $date = carbon()->parse($this->date);
        return (($date->format('m') == $previous_month && $date->format('d') >= 26) && (date('d') <= 26 && date('m') == $current_month)) || (($date->format('m') == $current_month && $date->format('d') <= 25) && (date('d') <= 26 && date('m') == $current_month)) || (($date->format('m') == $current_month && $date->format('d') >= 26) && (date('d') >= 26 && date('m') == $current_month ));
    }
    // is edited
    public function check_in_edited()
    {
        $logs_count = EmployeeAttendanceLog::where('employee_attendance_id', $this->check_in_id)->get()->count();
        return $logs_count;
    }
    // is edited
    public function check_out_edited()
    {
        $logs_count = EmployeeAttendanceLog::where('employee_attendance_id', $this->check_out_id)->get()->count();
        return $logs_count;
    }
    // check if discrepancy added
    public function discrepancy_added()
    {
        $discrepancy = EmployeeAttendanceDiscrepancy::where('employee_id', $this->employee->id)->whereDate('attendance_date', '=', formatDate($this->date, 'Y-m-d'))->first();
        if($discrepancy){
            return true;
        }
        return false;
    }
}
