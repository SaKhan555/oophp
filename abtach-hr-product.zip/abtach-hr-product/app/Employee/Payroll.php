<?php

namespace App\Employee;

use App\Employee;
use App\Employee\Attendance;
use App\Employee\FlexibleAttendance;
use Carbon\Carbon;

class Payroll
{
    private $employee;
    private $month;
    private $year;
    private $total_year_salary;
    public $additions;
    public $deductions;
    public $deduction_days_amounts;
    public $actual_salary;
    public $gross_salary;
    public $net_salary;
    public $extra_days_salary;
    public $per_day_salary;
    public $deduction_days;
    public $earning_days;
    private $salary_data;

    public function __construct(Employee $employee, $month)
    {
        $this->employee = $employee;
        $this->month = explode('-', $month)[0];      
        $this->year = explode('-', $month)[1];      
        $this->total_days = $this->total_month_days();
        $salary_data = $employee->salary_object_for_month($this->month, $this->year);
        $this->salary_data = $salary_data;
        $this->actual_salary = $this->calculate_actual_salary();
        $this->net_salary = 0;
        $this->gross_salary = $this->actual_salary;
        $this->init();
    }

    // initialize
    private function init()
    {
        $this->calculate_days();
        // per day salary
        $this->per_day_salary = ($this->actual_salary / $this->total_days);
        // calculate additions and deductions
        $this->calculate_additions();
        $this->calculate_deductions();
        $this->calculate_deduction_amounts();
        // calculate yearly taxable salary 
        $this->total_taxable_salary = $this->yearly_taxable_salary();
        // calculate tax
        $this->calculate_income_tax();
        // calculate salary
        $this->calculate_salary();
    }
    // total month days
    public function total_month_days($month='', $year='')
    {
        $month = ($month) ? $month : $this->month;
        $year = ($year) ? $year : $this->year;

        $month = carbon()->parse("01-{$month}-{$year}");
        // if($month->format('d') > 25){
        //     $month = $month->addMonth();
        // }
        $total_days = cal_days_in_month(CAL_GREGORIAN, $month->format('m'), $month->format('Y'));
        return $total_days;
    }
    // calculate actual salary
    public function calculate_actual_salary($month='', $year='')
    {
        $month = ($month) ? $month : $this->month;
        $year = ($year) ? $year : $this->year;
        $salary_date = carbon()->parse("01-$month-$year");
        $actual_salary = 0;
        $total_days = $this->total_month_days($month, $year);
        for ($i = 0; $i < $total_days; $i++) {
            $salary_by_date = $this->employee->employee_salaries()->whereDate('created_at', '<=', $salary_date->format('Y-m-d'))->orderBy('created_at', 'desc')->first();
            if($salary_by_date){
                $per_day_salary = ($salary_by_date->amount / $total_days);
            } else {
                $per_day_salary = ($this->employee->salary / $total_days);
            }
            $actual_salary += $per_day_salary;
            $salary_date = $salary_date->addDay();
        }
        return round($actual_salary);
    }
    // calculate per day salary
    public function calculate_per_day_salary($month='', $year='')
    {
        $month = ($month) ? $month : $this->month;
        $year = ($year) ? $year : $this->year;

        $total_days = $this->total_month_days($month, $year);
        return ($this->calculate_actual_salary($month, $year) / $total_days);
    }
    // calculate days
    private function calculate_days()
    {
        $month = $this->month;
        $year = $this->year;
        $checkinouts = period_interval(carbon()->parse("26-$month-$year")->subMonths(1));
        $this->days = [];
        foreach($checkinouts as $day) {
            $this->days[] = formatDate($day, 'd-m-Y');
        }
    }
    // calculate additions
    private function calculate_additions()
    {
        $actual_salary = $this->actual_salary;
        $calculated_salary = (($actual_salary - 775));
        $salary_percent = ($calculated_salary / 155);
        $this->additions['house_rent'] = ($this->salary_data && (!empty($this->salary_data->breakups['house_rent']))) ? $this->salary_data->breakups['house_rent'] : floor(($salary_percent * 45));
        $this->additions['medical'] = ($this->salary_data && !empty($this->salary_data->breakups['medical'])) ? $this->salary_data->breakups['medical'] : floor(($salary_percent * 10));
        $this->additions['basic'] = ($this->salary_data && !empty($this->salary_data->breakups['basic'])) ? $this->salary_data->breakups['basic'] : floor(($calculated_salary - $this->additions['house_rent'] - $this->additions['medical']));
        $this->additions['cola'] = ($this->salary_data && !empty($this->salary_data->breakups['cola'])) ? $this->salary_data->breakups['cola'] : 475;
        $this->additions['special'] = ($this->salary_data && !empty($this->salary_data->breakups['special'])) ? $this->salary_data->breakups['special'] : 300;
        $this->additions['arrears'] = $this->calculate_arrears();
        // count arrears for new joining who have joined after 25 of previous month
        $previous_date = carbon()->parse("25-{$this->month}-{$this->year}")->subMonth();
        if($this->employee->join_date->greaterThan($previous_date) && $this->employee->join_date->format('d') > 25){
            $previous_last_day = carbon()->parse('last day of last month');
            $new_joining_arrears = (carbon()->parse(formatDate($this->employee->join_date, 'd-m-Y'))->diffInDays($previous_last_day)+1);
            $per_day_salary = ($this->actual_salary / $this->total_month_days($previous_date->format('m'), $previous_date->format('Y')));
            $this->additions['arrears'] += ($new_joining_arrears * $per_day_salary);
        }
    }
    // calculate arrears
    public function calculate_arrears()
    {
        $year = ($this->year) ? $this->year : carbon()->now()->format('Y'); 
        $month = ($this->month) ? ($this->month - 1) : carbon()->now()->subMonth()->format('m');
        $parsed_month = carbon()->parse("01-$month-$year");
        $prev_month = ($month) ? ($month - 1) : carbon()->now()->subMonth()->format('m');
        $date = "1-$month-$year";
        $approved_leaves = $this->employee->leave_applications()
                        ->whereDate('start_date', '>=', "$year-$prev_month-26")
                        ->whereDate('end_date', '>=', "$year-$prev_month-26")
                        ->whereDate('start_date', '<=' , "$year-$month-25")
                        ->whereDate('end_date', '<=' , "$year-$month-25")
                        ->where('status', 1)
                        ->whereHas('approvals', function($q) use($month, $year) {
                            return $q->where('status', 1)->whereDate('created_at', '>', "$year-$month-27");
                        })->pluck('total_leave')->toArray();
        $perday_salary = $this->calculate_per_day_salary($month, $parsed_month->format('Y'));
        $arrears = array_map(function($approved_leave_application) use($perday_salary) {
            return $perday_salary*$approved_leave_application;
        }, $approved_leaves);
        $arrears = floor(array_sum($arrears));
        // verify arrears
        // $date = carbon()->parse($date)->subMonth();
        // $prev_month = $date->format('m');
        // $prev_year = $date->format('Y');
        $prev_payslip = $this->employee->new_salary_slips()->whereMonth('month',"=",$month)->whereYear("month","=",$year)->first();
        if($prev_payslip) {
            $total_prev_deductions = ($prev_payslip->per_day_salary * $prev_payslip->deductions['absents']);
            if($arrears > $total_prev_deductions){
                return $total_prev_deductions;
            } else {
                return $arrears;
            }
        } else {
            return $arrears;
        }
    }
    // calculate deductions
    private function calculate_deductions()
    {
        $days = $this->days;
        $employee = $this->employee;
        $month_attendance_data = array_map(function($day) use($employee){
            if($employee->hour_based){
                $current_attendance = new FlexibleAttendance($employee, $day);
            } else {
                $current_attendance = new Attendance($employee, $day);
            }
            $sandwitch = false;
            if(formatDate($day, 'l') == 'Friday'){
                $friday_date = carbon()->parse($day);
                $monday_date = carbon()->parse($day)->addDays(3);
                if($employee->hour_based){
                    $monday_attendance = new FlexibleAttendance($employee, $monday_date->format('d-m-Y'));
                } else {
                    $monday_attendance = new Attendance($employee, $monday_date->format('d-m-Y'));
                }
                if(($current_attendance->actual_status() == 'absent' && $monday_attendance->actual_status() == 'absent') && ($employee->join_date->lessThan($friday_date))){
                    $sandwitch = true;
                }
            }
            return [
                'late_in' => ($current_attendance->actual_status() == 'late in'),
                'early_out' => ($current_attendance->actual_status() == 'early out'),
                'absent' => ($current_attendance->actual_status() == 'absent'),
                'half_day' => ($current_attendance->actual_status() == 'half day'),
                'extra_day' => (($employee->allowed_extra_days || $employee->department_id == 2) && $current_attendance->actual_status() == 'extra day'),
                'extra_half_day' => (($employee->allowed_extra_days || $employee->department_id == 2) && $current_attendance->actual_status() == 'extra half day'),
                'sandwitch' => $sandwitch
            ];
        }, $days);
        $this->deductions['late_ins'] = count(array_filter($month_attendance_data, function($i){
            return $i['late_in'] == 1;
        }));
        $this->deductions['early_outs'] = count(array_filter($month_attendance_data, function($i){
            return $i['early_out'] == 1;
        }));
        $this->deductions['absents'] = count(array_filter($month_attendance_data, function($i){
            return $i['absent'] == 1;
        }));
        // calculate for
        $start_month = carbon()->parse("01-{$this->month}-{$this->year}")->subMonth()->format('m');
        $att_start_date = carbon()->parse("26-$start_month-{$this->year}");
        if($this->employee->join_date->greaterThan($att_start_date)){
            if($this->employee->join_date->format('d') > 26){
                $diff_in_days = $att_start_date->diffInDays($this->employee->join_date);
                $this->deductions['absents'] -= $diff_in_days;
            } else {
                $total_days_in_prev_month = $total_days = cal_days_in_month(CAL_GREGORIAN, "$start_month", $this->year);
                if($total_days_in_prev_month == 31){
                    $this->deductions['absents'] -= 6;
                } elseif($total_days_in_prev_month == 28){
                    $this->deductions['absents'] -= 3;
                } elseif($total_days_in_prev_month == 29){
                    $this->deductions['absents'] -= 4;
                } else {
                    $this->deductions['absents'] -= 5;
                }
            }
        }

        $this->deductions['sandwitches'] = count(array_filter($month_attendance_data, function($i){
            return $i['sandwitch'] == 1;
        }));
        $this->deductions['half_days'] = count(array_filter($month_attendance_data, function($i){
            return $i['half_day'] == 1;
        }));
        $this->additions['extra_days'] = count(array_filter($month_attendance_data, function($i){
            return $i['extra_day'] == 1;
        })) + (count(array_filter($month_attendance_data, function($i){
            return $i['extra_half_day'] == 1;
        })) / 2);
        $this->deductions['eobi'] = $this->eobi();
        $this->deductions['loan'] = $this->loan();
    }
    // calculate deduction amounts
    private function calculate_deduction_amounts()
    {
        $employee = $this->employee;
        $deductions = $this->deductions;
        $per_day_salary = $this->per_day_salary;
        $this->deduction_days_amounts = [];
        // $deduction_days = (((floor(($deductions['late_ins'] + $deductions['early_outs']) / 3) / 2)) + ($deductions['half_days'] / 2)) + $deductions['absents'];
        if(strtolower($employee->sex) == 'female' && in_array(strtolower($employee->current_status), ['probation', 'permanent','notice period'])){
            $late_ins = 0;
        } else {
            $late_ins = $deductions['late_ins'];
        }
        $latein_earlyout_days = (floor(($late_ins + $deductions['early_outs']) / 3) / 2);
        $this->deduction_days_amounts['latein_earlyout'] = ($latein_earlyout_days * $per_day_salary);
        $half_days = ($deductions['half_days'] / 2);
        $this->deduction_days_amounts['half_day'] = ($half_days * $per_day_salary);
        $sandwitches = $this->deductions['sandwitches'];
        $absents_and_sandwitches = (($this->deductions['absents'] - ($sandwitches * 2)) + ($sandwitches * 4));
        $this->deduction_days_amounts['absent'] = round($absents_and_sandwitches * $per_day_salary);
    }
    // income tax
    private function calculate_income_tax()
    {
        $prev_year = carbon()->now()->subYear()->format('Y');
        $current_year = carbon()->now()->format('Y');
        $current_month = carbon()->now()->format('m');
        $paid_taxes = $this->employee->paid_taxes();
        if(carbon()->now()->format('m') > 06){
            $paid_taxes = $paid_taxes->whereYear('month', '=', $current_year)
                                        ->whereMonth('month', '>=', '07');
        } else {
            $paid_taxes = $paid_taxes->where(function($q){
                return $q->whereYear('month', '=', $prev_year)
                            ->whereMonth('month', '>=', '07');
            })->orWhere(function($q){
                return $q->whereYear('month', '=', $current_year)
                        ->whereMonth('month', '<', $current_month);
            });
        }
        $total_year_salary = $this->total_taxable_salary+$this->calculate_incentives();
        $paid_taxes = $paid_taxes->pluck('amount')->toArray();
        $tax_deduction_months = $this->deducted_tax_months_for_new_joining();
        $total_paid_tax = array_sum($paid_taxes);
        $total_months_to_pay = (($this->month >= 07) ? carbon()->parse("01-{$this->month}-{$this->year}")->diffInMonths(carbon()->parse('01-06-2019')) : carbon()->parse("01-{$this->month}-{$this->year}")->diffInMonths(carbon()->parse("01-06-{$this->year}"))) + 1;
        // $total_months_to_pay = ($total_months_to_pay - count($paid_taxes));
        if($total_year_salary > 400000 && $total_year_salary <= 800000){
            // if salary exceeds 4 lac but does'nt exceeds 8 lac
            $total_tax = 1000;
            $per_month_tax = ($total_tax / 12);
            $total_tax = ($total_tax - ($per_month_tax * $tax_deduction_months));
            if($tax_deduction_months){
                $total_paid_tax = 0;
            }
        } elseif($total_year_salary > 800000 && $total_year_salary <= 1200000) {
            // if salary exceeds 8 lac but does'nt exceeds 12 lac
            $total_tax = 2000;
            $per_month_tax = ($total_tax / 12);
            $total_tax = ($total_tax - ($per_month_tax * $tax_deduction_months));
            if($tax_deduction_months){
                $total_paid_tax = 0;
            }
        } elseif($total_year_salary > 1200000 && $total_year_salary <= 2500000) {
            // if salary exceeds 12 lac but does'nt exceeds 24 lac
            // 5% of amount exceeds 12 lac or 2000 the greater one
            $tax_amount = ((($total_year_salary - 1200000) * 5) / 100);
            $total_tax = ($tax_amount < 2000) ? 2000 : $tax_amount;
            // $total_tax = $tax_amount + 3000;
        } elseif($total_year_salary > 2500000 && $total_year_salary <= 4000000) {
            // if salary exceeds 24 lac but does'nt exceeds 48 lac
            // 60 thousand + 10% of amount exceeds 24 lac
            $total_tax = (65000 + ( (($total_year_salary - 2500000) * 15) / 100 ) );
        } elseif($total_year_salary > 4000000 && $total_year_salary <= 8000000) {
            // if salary exceeds 2400000 lac
            // 30 thousand + 15% of amount exceeds 48 lac
            $total_tax = (290000 + ( (($total_year_salary - 4000000) * 20) / 100 ) );
        } elseif($total_year_salary > 8000000) {
            // if salary exeeds 80 lacs
            $total_tax = (1090000 + ( ($total_year_salary - 8000000) * 25) / 100);
        } else {
            $total_tax = 0;
        }
        $income_tax = round((($total_tax - $total_paid_tax))/$total_months_to_pay);
        $this->deductions['income_tax'] = ($income_tax > 0) ? $income_tax : 0;
    }
    // deducted tax of new joining
    private function deducted_tax_months_for_new_joining()
    {
        $employee = $this->employee;
        $current = carbon()->now();
        $year = $current->format('Y');
        $current_month = $current->format('m');
        if($current_month <= 06){
            $year = $current->subYear()->format('Y');
        }

        $month = carbon()->parse("first day of june ".$year);
        $count = 0;
        for ($i = 1; $i <= 11; $i++) {
            $month = $month->addMonth();
            if( ($employee->join_date->format('Y') > $month->format('Y')) || ($employee->join_date->format('Y') == $month->format('Y') && $employee->join_date->format('m') > $month->format('m')) || ( ($employee->join_date->format('Y') == $month->format('Y')) && ($employee->join_date->format('m') == $month->format('m') && $employee->join_date->format('d') > 25)) ){
                $count++;
            }
        }
        return $count;
    }
    // last incentive
    private function calculate_incentives()
    {
        $employee = $this->employee;
        $current = carbon()->now();
        $year = $current->format('Y');
        $current_month = $current->format('m');
        if($current_month <= 06){
            $year = $current->subYear()->format('Y');
        }
        $month = carbon()->parse("first day of june ".$year);
        $incentive_amount = 0;
        $latest_incentive = $employee->incentives()->whereYear('date', '=', $year)->orderBy('date', 'desc')->pluck('amount')->first();
        for ($i = 0; $i < 12; $i++) {
            $month = $month->addMonth();
            $incentive = $employee->incentives()
                                ->whereMonth('date', '=', $month->format('m'))
                                ->whereYear('date', '=', $month->format('Y'))
                                ->pluck('amount')->first();
            $incentive_amount += (!is_null($incentive)) ? $incentive : $latest_incentive;
        }
        return $incentive_amount;
    }
    // eobi
    private function eobi()
    {
        $total_month_days = $this->total_days;
        $perday_eobi = (150/$total_month_days);
        $join_date = carbon()->parse($this->employee->join_date);
        if($join_date->format('m') == carbon()->now()->format('m')
            && $join_date->format('Y') == carbon()->now()->format('Y')){
            $subtract_eobi = str_replace('0', '', $join_date->format('d'));
        } else {
            $subtract_eobi = 0;
        }
        $eobi = ($this->actual_salary >= 15000) ? ((15000/100) - ($perday_eobi * $subtract_eobi)) : 0;
        return round($eobi - ($perday_eobi * ($this->calculate_deducted_salary() / $this->per_day_salary)));
    }
    // load
    private function loan()
    {
        return 0;
    }
    // calculate salary
    private function calculate_salary()
    {
        $employee = $this->employee;
        $deductions = $this->deductions;
        $actual_salary = $this->actual_salary;
        $deducted_salary = $this->calculate_deducted_salary();
        $extra_days_salary = ($this->per_day_salary * $this->additions['extra_days']);
        $this->extra_days_salary = $extra_days_salary;
        $this->additions['extra_days_salary'] = $extra_days_salary;
        $this->gross_salary += ($extra_days_salary + $this->additions['arrears']);
        $net_salary = round($this->gross_salary - $deducted_salary);
        $this->net_salary = (($net_salary) - $this->deductions['eobi']) - $this->deductions['income_tax'];
    }
    // calculate deducted salary
    private function calculate_deducted_salary()
    {
        $employee = $this->employee;
        $per_day_salary = $this->per_day_salary;
        $deductions = $this->deductions;
        if($employee->employee_id == '1142'){
            $deduction_days = 0;
        } else {
            $absents_and_sandwitches = (($deductions['absents'] - ($deductions['sandwitches'] * 2)) 
                                        + ($deductions['sandwitches'] * 4));
            if($employee->is_flexible_timing){
                $deduction_days = $absents_and_sandwitches;
            } elseif(strtolower($employee->sex) == 'female' && in_array(strtolower($employee->current_status), ['probation', 'permanent','notice period'])){
                $deduction_days = (((floor(($deductions['early_outs']) / 3) / 2)) + ($deductions['half_days'] / 2)) + $absents_and_sandwitches;
            } else {
                $deduction_days = (((floor(($deductions['late_ins'] + $deductions['early_outs']) / 3) / 2)) + ($deductions['half_days'] / 2)) + $absents_and_sandwitches;
            }
        }
        $this->deduction_days = $deduction_days;
        $this->earning_days = ($this->total_days - $deduction_days);
        return floor($per_day_salary * $deduction_days);
    }
    // taxable salary
    private function yearly_taxable_salary()
    {
        $current_taxable_salary = ($this->actual_salary - $this->additions['medical']);
        $current_taxable_salary += ($this->per_day_salary * $this->additions['extra_days']);
        $current_taxable_salary -= $this->calculate_deducted_salary();
        return $this->employee->current_year_taxable_salary() + $current_taxable_salary + $this->additions['arrears'];
    }
}
