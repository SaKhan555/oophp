<?php

use Carbon\Carbon;

/**
 * Find a property value by giving propery collection
 *
 * @param $collection
 * @param $property
 *
 * @return null
 */
function alertMessage($type, $message, $head = null)
{
    switch ($type) {
        case 'error': //Error
            $head = $head ? $head : 'Error';
            break;
        case 'warning': //Warning
            $head = $head ? $head : 'Warning';
            break;
        case 'info': //Info
            $head = $head ? $head : 'Info';
            break;
        case 'success': //Success
            $head = $head ? $head : 'Success';
            break;
    }

    return '<div class="alert alert-' . $type . '">' . $message . '</div>';
}

function set_active($path){
    return (request()->is($path)) ? 'active' : '';
}

function get_employee_vehicle($vehicle_id){
    $employeeVehicle = \App\EmployeeVehicle::where('vehicle_id', $vehicle_id)->whereNull('car_return_date')->orderBy('id', 'DESC')->first();
    if($employeeVehicle){
        $employee = \App\Employee::find($employeeVehicle->employee_id);
        if($employee){
            return  ['name' => $employee->full_name, 'id' => $employee->id];
        }
    }

    return '';
}

/**
 * @param $route
 * @param $id
 * @param $status
 * @param null $class
 * @return string
 */
function btn_status($route, $id, $status, $parameter = [], $class = null, $disable=false)
{
    $output = "";
    $url_data = '?'.http_build_query($parameter);
    if($disable==true && $status == 0){
        return '';
    } else {
        if ($status == 1):
            $output .= Html::link(route($route, $id).$url_data, 'Active', ['class' => 'btn btn-xs btn-primary btnStatus '], null);
        else:
            $output .= Html::link(route($route, $id).$url_data, 'Deactive', ['class' => 'btn btn-xs btn-danger  btnStatus'], null);
        endif;
        return $output;
    }


}
function getCurrentStatus($status, $data){
    $statuses = collect($data)->where('status', $status)->first();
    if($statuses){
        return $statuses;
    }
    return false;
}


function getCurrencyBySymbol($name){
    if($name){
        $get = collect(app('currencies_all'))->where('name', $name)->first();
        if($get){
            return $get->symbol;
        }
        return '$';
    }
}
function hasSuperAdmin(){
    if(auth()->guard('admin_web')->check()){
        if(in_array(auth()->guard('admin_web')->id(), [1, 13, 14]))
            return true;
        return false;
    }
}
function hasAdmin(){
    if(auth()->guard('admin_web')->check()){
        if(auth()->guard('admin_web')->user()->type == 'admin')
            return true;

        return false;
    }
}
function hasAssistant(){
    if(auth()->guard('admin_web')->check()){
        $type = auth()->guard('admin_web')->user()->type;
        if(in_array($type, ['admin', 'finance', 'assistant', 'hr']))
            return true;

        return false;
    }
}

function getEmployeeCount($status){
    $count = \App\Employee::where('current_status', $status)->count();
    return $count;
}
function hasFinance(){
    if(auth()->guard('admin_web')->check()){
        if(auth()->guard('admin_web')->user()->type == 'finance')
            return true;

        return false;
    }
}
function hasExecutive(){
    if(auth()->guard('admin_web')->check()){
        if(auth()->guard('admin_web')->user()->type == 'executive')
            return true;

        return false;
    }
}
function hasMarketing(){
    if(auth()->guard('admin_web')->check()){
        if(auth()->guard('admin_web')->user()->type == 'marketing')
            return true;

        return false;
    }
}
function hasFleetManager(){
    if(auth()->guard('admin_web')->check()){
        if(auth()->guard('admin_web')->user()->type == 'fleet-manager')
            return true;

        return false;
    }
}
function convertAmount($amount)
{
    // Prep
    $amount = str_replace(',', '', $amount);

    if (is_numeric($amount)) {
        return number_format($amount, 2,'.', ',');
    }

    // Invalid input, do something about it.
    return 0.00;
}
function secToHR($seconds) {
		  $hours = floor($seconds / 3600);
		  $minutes = floor(($seconds / 60) % 60);
		  $seconds = $seconds % 60;
		  if($seconds<=9) {$seconds='0'.$seconds;}
		  if($minutes<=9) {$minutes='0'.$minutes;}
		  return "$hours:$minutes:$seconds";
	}
function getUnitsByEmpID($employee_id)
{
	$total_emp = DB::select("SELECT count(*) as total_units FROM od0_employee_units WHERE employee_id=".$employee_id);
	if($total_emp[0]){
        $total_emp = collect($total_emp[0])->get('total_units');
        return ($total_emp) ? $total_emp : 0;
    }
    return 0;
}	
// format date helper
function formatDate($date='', $format='d M Y')
{
    $output = '';
    if($date){
        $output = Carbon::parse($date)->format($format);
    }
    return $output;
}
// carbon
function carbon()
{
    return new Carbon();
}

// timeperiod interval
if(!function_exists('period_interval')){
    function period_interval($begin_date, $end_date='')
    {
        $begin = Carbon::parse($begin_date);
        $end = ($end_date) ? Carbon::parse($end_date) : Carbon::parse($begin_date)->addMonths(1);

        $interval = \DateInterval::createFromDateString('1 day');
        $period = new \DatePeriod($begin, $interval, $end);
        return $period;
    }
}

// special permission
if(!function_exists('has_special_permissions')){
    function has_special_permissions($id)
    {
        return (in_array($id, [
            46,
            47
        ]) || auth()->user()->role == 'admin');
    }  
}
// total days of month
if(!function_exists('total_days_of_month')){
    function total_days_of_month($month = '')
    {
        $month = ($month) ? $month : carbon()->now()->format('m-Y');
        $start_day = carbon()->parse("26-$month"); 
        $end_day = carbon()->parse("26-$month")->addMonth();
        $total_days = $start_day->diffInDays($end_day);
        return $total_days;
    }
}
// get countries list
if(!function_exists('countries_list')){
    function countries_list()
    {
        return \App\Country::pluck('name', 'id');
    }
}
// check features enabled
if(!function_exists('feature_enabled')){
    function feature_enabled($key='')
    {
        $feature = \App\Feature::where('feature_key', $key)->first();
        if($feature && $feature->status){
            return true;
        }
        return false;
    }
}
// all employees hierarchy
if(!function_exists('employees_hierarchy')){
    function employees_hierarchy($employee_id, $dash='', $output='')
    {
        $dash .= '--';
        $employees = \App\Employee::where('manager_id', $employee_id)->get();
        if($employees->count()){
            foreach($employees as $employee) {
                $employee_department = ($employee->employee_department) ? $employee->employee_department->name : $employee->department;
                $output .= '<tr>
                                <td><strong>'.$dash.'|</strong> '.$employee->full_name.'</td>
                                <td>'.$employee->designation.'</td>
                                <td>'.$employee_department.'</td>
                            </tr>';
                $output = employees_hierarchy($employee->id, $dash, $output);
            }
        }
        return $output;
    }
}

// who is out today
if(!function_exists('whos_out_today')){
    function whos_out_today()
    {
        $today = carbon()->now();
        $employees = \App\Employee::whereHas('leave_applications', function($q) use($today) {
            return $q->where('status', 1)->whereDate('start_date', '<=', $today->format('Y-m-d'))
                    ->whereDate('end_date', '>=', $today->format('Y-m-d'));
        })->where('id', '!=',auth()->id())->where(function($q){
            return $q->where('department_id', auth()->user()->department_id)->orWhere('manager_id', auth()->user()->id);
        })->get();
        return $employees;
    }
}
// who is out today
if(!function_exists('whos_out_tomorrow')){
    function whos_out_tomorrow()
    {
        $tomorrow = carbon()->now()->addDay(1);
        $employees = \App\Employee::whereHas('leave_applications', function($q) use($tomorrow) {
            return $q->where('status', 1)->whereDate('start_date', '<=', $tomorrow->format('Y-m-d'))
                    ->whereDate('end_date', '>=', $tomorrow->format('Y-m-d'));
        })->where('id', '!=',auth()->id())->where(function($q){
            return $q->where('department_id', auth()->user()->department_id)->where('unit_id', auth()->user()->unit_id)->orWhere('manager_id', auth()->user()->id);
        })->get();
        return $employees;
    }
}
// who is out today
if(!function_exists('whos_out_this_week')){
    function whos_out_this_week()
    {
        $start_date = carbon()->now()->format('Y-m-d');
        $end_date = carbon()->now()->endOfWeek()->format('Y-m-d');
        $employees = \App\Employee::whereHas('leave_applications', function($q) use($start_date, $end_date) {
            return $q->where('status', 1)->where(function($q) use($start_date, $end_date) {
                return $q->where(function($q) use($start_date, $end_date) {
                    return $q->whereDate('start_date', '<=', $start_date)
                        ->whereDate('end_date', '>=', $end_date);
                })->orWhere(function($q) use($start_date, $end_date) {
                    return $q->whereDate('start_date', '>', $start_date)
                        ->whereDate('end_date', '<', $end_date);
                })->orWhere(function($q) use($start_date, $end_date) {
                    return $q->whereDate('start_date', '<=', $start_date)
                            ->whereDate('end_date', '>=', $start_date)
                            ->whereDate('end_date', '<=', $end_date);
                });
            });
        })->where('id', '!=',auth()->id())->where(function($q){
            return $q->where('department_id', auth()->user()->department_id)->where('unit_id', auth()->user()->unit_id)->orWhere('manager_id', auth()->user()->id);
        })->get();
        return $employees;
    }
}
// who is out today
if(!function_exists('whos_out_next_week')){
    function whos_out_next_week()
    {
        $start_date = carbon()->now()->format('Y-m-d');
        $end_date = carbon()->now()->endOfWeek()->addWeek()->format('Y-m-d');
        $employees = \App\Employee::whereHas('leave_applications', function($q) use($start_date, $end_date) {
            return $q->where('status', 1)->where(function($q) use($start_date, $end_date){
                return $q->where(function($q) use($start_date, $end_date) {
                    return $q->whereDate('start_date', '<=', $start_date)
                        ->whereDate('end_date', '>=', $end_date);
                })->orWhere(function($q) use($start_date, $end_date) {
                    return $q->whereDate('start_date', '>', $start_date)
                        ->whereDate('end_date', '<', $end_date);
                })->orWhere(function($q) use($start_date, $end_date) {
                    return $q->whereDate('start_date', '<=', $start_date)
                            ->whereDate('end_date', '>=', $start_date)
                            ->whereDate('end_date', '<=', $end_date);
                });
            });
        })->where('id', '!=',auth()->id())->where(function($q){
            return $q->where('department_id', auth()->user()->department_id)->where('unit_id', auth()->user()->unit_id)->orWhere('manager_id', auth()->user()->id);
        })->get();
        return $employees;
    }
}
    /**
     * get theme option
     */
    if(!function_exists('get_setting')){
        function get_setting($key)
        {
            $portal_setting = \App\PortalSetting::where('setting_key', $key)->pluck('setting_value')->first();
            return $portal_setting;
        }
    }
    /**
     * get theme option
     */
    if(!function_exists('get_employee_default')){
        function get_employee_default($key)
        {
            $employee_default = \App\EmployeeDefault::where('name', $key)->pluck('value')->first();
            return $employee_default;
        }
    }

if(!function_exists('employee_birthday')){
    function employee_birthday()
    {
        $today = carbon()->now();
        $employees = \App\Employee::whereMonth('birth_date', '=', $today->format('m'))->whereDay('birth_date', '=', $today->format('d'))->get();
        return $employees;
    }
}
if(!function_exists('employees_anniversary')){
    function employees_anniversary()
    {
        $date = carbon()->now();
        $employees_anniversary = \App\Employee::whereYear('join_date','<',$date->format('Y'))->whereMonth('join_date', '=', $date->format('m'))->whereDay('join_date', '=', $date->format('d'))->get();
        return $employees_anniversary;
    }
}

if(!function_exists('documents')){
    function documents(){
        return \App\Document::get();
    }
}

if(!function_exists('admin_emails')){
    function admin_emails()
    {
        return \App\User::where('type', 'admin')->pluck('email')->toArray();
    }
}
if(!function_exists('hr_person')){
    function hr_person()
    {
        return \App\User::where('type', 'hr')->first();
    }
}