<?php

namespace App\Libraries;


use App\SMSLogs;
use GuzzleHttp\Client;

class SMSService
{


    private $host = 'http://sms.its.com.pk:80/api/?';
    private $username = 'Abtach';
    private $password = 'ABq2w3e4';
    private $enable = 1;


    /**
     * SMS_Service constructor.
     */
    public function __construct()
    {

    }

    /**
     * @param $receiver
     * @param $msg
     * @param $action
     */
    public function execute($receiver, $msg, $action)
    {
        if($this->enable == 1)
        {
            $smsurl = $this->host; // change smsdomain.com to your provided
            $receiver = '92'.ltrim(preg_replace('/\D+/', '', $receiver), 0);
            $url  = 'username='.$this->username;
            $url  .= '&password='.$this->password;
            $url  .= '&receiver='.urlencode($receiver);
            $url  .= '&msgdata='.urlencode($msg);
            $urltouse =  $smsurl.$url;
            $xml = simplexml_load_file($urltouse);
            $response = json_decode(json_encode((array)$xml), TRUE);
            if($response['errorno'] == 0){

                $data = [
                    'action' => $action,
                    'activity' => 'message',
                    'sender' => $response['sender'],
                    'content' => $response['msgdata'],
                    'receiver' => json_encode($response['receivers']['receiver']),
                    'status' => $response['status'],

                ];
                SMSLogs::create([
                    'number' => $receiver,
                    'message'=> $msg,
                    'action'=> $action,
                    'status' => 'send',
                ]);

            }
        }
    }


}