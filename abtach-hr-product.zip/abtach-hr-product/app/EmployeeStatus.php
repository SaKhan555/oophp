<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class EmployeeStatus extends Model
{
   protected $guarded = ['id'];
   protected $casts = [
       'status_at' => 'date',
       'end_at' => 'date',
   ];
}
