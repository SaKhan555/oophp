<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use App\Traits\RecordActivity;

class CompanyVehicle extends Model
{
    use RecordActivity, SoftDeletes;

    protected $guarded = ['id'];

    // employee vehicles
    public function employees()
    {
        return $this->hasMany(EmployeeVehicle::class,'vehicle_id');
    }
    // has a rent
    public function rents()
    {
        return $this->hasMany(CompanyVehicleRent::class);
    }
    // has many meter readings
    public function meter_readings()
    {
        return $this->hasMany(VehicleMeterReading::class, 'vehicle_id', 'id')->orderBy('date', 'desc');
    }
    // scope search
    public function scopeSearch($query)
    {
        $s = trim(request('s'));
        if($s) {
            $query = $query->where('car_make', 'LIKE', '%' . $s . '%')
                ->orWhere('car_model', 'LIKE', '%' . $s . '%')
                ->orWhere('car_color', 'LIKE', '%' . $s . '%')
                ->orWhere('car_registration_no', 'LIKE', '%' . $s . '%');
        }
        if(!is_null(request('status'))) {
            $query = $query->where('assigned', request('status'));
        }
        if(request('car_status')){
            $query = $query->where('car_status', request('car_status'));
        }
        if(request('car_type')){
            $query = $query->where('car_type', request('car_type'));
        }

        return $query;

    }
    // total rent
    public function total_rent()
    {
        // $rents = $this->rents()->orderBy('id','desc')->get();
        // $total_rent = 0;
        // $i = 0;
        // $days = 0;
        // foreach($rents as $rent){
        //     $current_date = new \Carbon\Carbon($rent->created_at);
        //     if(isset($rents[$i+1])){
        //         $next_date = $rents[$i+1]->created_at;
        //         $current_days = ($current_date->diff($next_date)->days)+1;
        //     } else {
        //         $next_date = \Carbon\Carbon::now();
        //         $current_days = (($next_date > $current_date) ? ($current_date->diff($next_date)->days) : 0)+1;
        //     }
        //     $total_rent += ($rent->rent_per_day * $current_days);
        //     $i++;
        // }
        // return $total_rent;
    }

    // current rent date
    public function current_rent_date()
    {
        $rent = $this->rents()->latest()->first();
        if($rent)
            return $rent->created_at;
    }
    // current meter reading
    public function current_meter_reading()
    {
        $meter_reading = $this->meter_readings()->first();
        return ($meter_reading) ? $meter_reading->reading : ''; 
    }
    // current due on
    public function current_due_on()
    {
        $meter_reading = $this->meter_readings()->first();
        return ($meter_reading) ? $meter_reading->maintenance_due_on : ''; 
    }
    // current meter reading date
    public function current_meter_reading_date()
    {
        $meter_reading = $this->meter_readings()->first();
        return ($meter_reading) ? $meter_reading->date->format('d M Y') : ''; 
    }
}
