<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class EmployeeReview extends Model
{
	protected $fillable = ['submit_by', 'submit_to', 'review', 'review_type_id'];

	/**
	 * from employee
	 */
	public function by_employee()
	{
		return $this->belongsTo(Employee::class, 'submit_by');
	}
	/**
	 * to employee
	 */
	public function to_employee()
	{
		return $this->belongsTo(Employee::class, 'submit_to');
	}
	/**
	 * review type
	 */
	public function type()
	{
		return $this->belongsTo(EmployeeReviewType::class, 'review_type_id');
	}
}
