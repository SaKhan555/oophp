<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class EmployeeAttendanceDiscrepancy extends Model
{
    protected $guarded = ['id'];
    protected $dates = [
        'attendance_time',
        'attendance_date'
    ];
    // belongs to an employee
    public function employee()
    {
    	return $this->belongsTo(Employee::class, 'employee_id');
    }
    // belongs to attendance
    public function attendance()
    {
    	return $this->belongsTo(EmployeeAttendance::class, 'attendance_id');
    }
    // has many comments
    public function comments()
    {
        return $this->hasMany(EmployeeAttendanceDiscrepancyComment::class, 'discrepancy_id');
    }
    // actual status
    public function approval_status()
    {
        $comments_count = $this->comments()->count();
        if(!$comments_count){
            return 'pending';
        } elseif($this->status) {
            return 'approved';
        } else {
            return 'disapproved';
        }

    }
    /**
     * search scope
     */
    
    public function scopeSearch($query)
    {
        $employee_id = request('employee_id');
        // $date = request('date');
        $attendance_type = request('attendance_type');
        $status = request('status');
        if($employee_id){
            $query = $query->where('employee_id', $employee_id);
        }
        // if($date){
        //     $date = carbon()->createFromFormat('d/m/Y', $date)->format('Y-m-d');
        //     $query = $query->whereDate('start_date', '<=' ,$date)->whereDate('end_date','>=', $date);
        // }
        if($attendance_type){
            $query = $query->where('attendance_type', $attendance_type);
        }
        if(!is_null($status)){
            if($status == 2){
                $query = $query->whereDoesntHave('comments');
            } else {
                $query = $query->where('status', $status)->whereHas('comments');
            }
        }
        return $query;
    }
    /**
     * Restrict manager to fetch leave applications
     */
    public function scopeRestrictManager($query) 
    {
        $role = strtolower(auth()->guard('web')->user()->role);
        if($role == 'admin') {
            if(request('manager_id')){
                return $query->whereHas('employee', function($q) {
                    return $q->where('manager_id', request('manager_id'));
                });
            }
            return $query;
        } else {
            $manager_ids = array_merge([
                auth()->id()
            ], auth()->user()->reporting_managers());
            return $query->whereHas('employee', function($q) use($manager_ids) {
                        return $q->whereIn('manager_id', $manager_ids);
                    });
        }
    }
}
