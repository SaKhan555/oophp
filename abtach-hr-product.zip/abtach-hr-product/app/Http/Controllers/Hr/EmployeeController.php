<?php

namespace App\Http\Controllers\Hr;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Employee;
use App\EmployeeSalary;
use App\EmployeeRelation;
use App\EmployeeStatus;
use Carbon\Carbon;
use Illuminate\Support\Facades\Mail;
use App\Mail\NotifyInsuranceEmployee;
use App\Mail\HrEmployeeAddressEmail;


class EmployeeController extends Controller
{

    /**
     * @var Employee
     */
    private $employee;
    /**
     * @var EmployeeStatus
     */
    private $employeeStatus;
    /**
     * @var EmployeeSalary
     */
    private $employeeRelation;
    /**
     * @var EmployeeSalary
     */
    private $employeeSalary;
    /**
     * EmployeeController constructor.
     * @param Employee $employee
     * @param EmployeeStatus $employeeStatus
     * @param EmployeeSalary $employeeSalary
     */
    public function __construct(Employee $employee, EmployeeStatus $employeeStatus, EmployeeSalary $employeeSalary, EmployeeRelation $employeeRelation)
    {
        $this->employee = $employee;
        $this->employeeStatus = $employeeStatus;
        $this->employeeRelation = $employeeRelation;
        $this->employeeSalary = $employeeSalary;
    }



    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('hr.employee.information');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {


    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
      
        \DB::beginTransaction();

        try{

		$email = request('email');
        $employee = $this->employee->query();
		if(request('email')){
			$employee = $employee->where('email', $email);
		} elseif(request('employee_id')){
			$employee = $employee->where('employee_id', request('employee_id'));
		}
		$employee = $employee->first();
        if($employee){
            $data = [];
            if(request('date_of_birth')){
                $edob = Carbon::parse(request('date_of_birth'))->toDateTimeString();
                $data =  ['birth_date' => $edob];
            }

            $data =  array_merge($data, [
				'national_identity_2' => request('national_identity_2'), 
				'marital_status' => request('marital_status')
			]);
            $updated = $employee->update($data);
            $this->employeeRelation->where('employee_id', $employee->id)->delete();
            foreach (request('employee') as $key => $member){
                if($member){
                    $dobe = (isset($member['dob'])) ? Carbon::parse($member['dob'])->toDateTimeString() : null;
                    $family = [
                        'employee_id' => $employee->id,
                        'full_name' =>  (isset($member['family_member'])) ? $member['family_member'] : null,
                        'relation' =>  (isset($member['relation'])) ? $member['relation'] : null,
                        'date_of_birth' =>  ($dobe) ? $dobe : null,
                    ];

                    $this->employeeRelation->create($family);
                }
            }
            $updated = $employee->update(['information' => 1]);
			Mail::to('umema.ali@abtach.org')->cc('saad.iqbal@abtach.org')->send(new NotifyInsuranceEmployee($employee));

        }
        \DB::commit();
        return redirect()->route('hr.employee.show', 'thankyou');
        } catch (\Exception $e) {
            \DB::rollback();
			return $e->getMessage();
            return redirect()->back()->with(['error'=>$e->getMessage()]);
        } catch (\Throwable $e) {
            \DB::rollback();
						return $e->getMessage();

            return redirect()->back()->with(['error'=>$e->getMessage()]);
        }


    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        if($id == 'thankyou'){
            return view('hr.employee.thankyou');

        }
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        if(request()->ajax()){
			
				$relation = $this->employeeRelation->find($id);
				$relation->update([request('name') => request('value')]);
				return response()->json(['success'=>true]);
			
		}
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
    /**
     * show employee address form
     */
    public function address()
    {
        return view('hr.employee.address');
    }
    /**
     * submit employee address form
     */
    public function updateAddress(Request $request)
    {
        $this->validate($request, [
            'email' => 'required_without:employee_id',
            'employee_id' => 'required_without:email',
            'address' => 'required'
        ]);

        $employee = $this->employee->query();
        if($request->email){
            $employee = $employee->where('email', $request->email);
        }
        // if($request->employee_id){
        //     $employee = $employee->where('employee_id', $request->employee_id);
        // }
        $employee = $employee->first();
        if($employee) {
            $employee->update(['address' => $request->address]);
            Mail::to(config('app.hr_email'))->cc(config('general.emails.cc_default'))->send(new HrEmployeeAddressEmail($employee));
            return redirect()->route('hr.employee.show', 'thankyou');
        } else {
            return redirect()->route('hr.employee.address')->with('error','Please Enter Correct Email Address');
        }
    }
}
