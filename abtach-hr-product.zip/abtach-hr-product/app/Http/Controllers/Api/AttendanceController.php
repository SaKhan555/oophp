<?php

namespace App\Http\Controllers\Api;
use App\EmployeeAttendance;
use App\EmployeeMachineAttendance;
use App\Employee;
use App\EmployeeSetting;
use Carbon\Carbon;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;




class AttendanceController extends Controller
{
	/**
     * @var EmployeeMachineAttendance
     */
    private $employeeMachineAttendance;
	/**
     * @var EmployeeAttendance
     */
    private $employeeAttendance;
    /**
     * @var EmployeeSetting
     */
    private $employeeSetting;
    /**
     * @var Employee
     */
    private $employee;

    public function __construct(EmployeeMachineAttendance $employeeMachineAttendance, EmployeeAttendance $employeeAttendance ,EmployeeSetting $employeeSetting, Employee $employee)
    {
        $this->employeeMachineAttendance = $employeeAttendance;
		$this->employeeAttendance = $employeeAttendance;
        $this->employeeSetting = $employeeSetting;
        $this->employee = $employee;
    }

	/**
	* Store a newly created resource in storage.
	*
	* @param  \Illuminate\Http\Request  $request
	* @return \Illuminate\Http\Response
	* @return \Illuminate\Http\Response
	*/
    public function storeData(Request $request)
    {
		\Log::info($request->all());

		$data = $request->all();
		$data = str_replace("[","{",$data);
		$data = str_replace("]","}",$data);
		
		$my_array_data = json_decode($data['value'], TRUE);

		$check_datetime = Carbon::parse($my_array_data['Date'].' '.$my_array_data['Time']);
		$this->employeeAttendance->create([
                    'employee_id' => $my_array_data['EmployeeId'],
                    'checked_at' => $check_datetime,
                    'status' => $my_array_data['Status'],
                    'created_at' => $check_datetime,
                ]); 
				
		return response()->json(['success'=>true]);
		
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $data = $request->toArray();

        foreach ($data as $key => $value) {
            $user_id = $value['user_id'];
            $check_time = $value['CHECKTIME'];
            $check_type = $value['CHECKTYPE'];
            $this->employeeAttendance->create([
                'employee_id' => $user_id,
                'check_in_time' => $check_time,
                'check_type' => $check_type,

            ]);
            //$sql = "INSERT INTO od0_employee_attendances2 (employee_id,check_time,check_type) VALUES ('$user_id','$check_time','$check_type')";
            //\DB::insert($sql);
       }
        \Log::info(json_encode($request->all()));
       return response()->json(['status'=>'true']);

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
