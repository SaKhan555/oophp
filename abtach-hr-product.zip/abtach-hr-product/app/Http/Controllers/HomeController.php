<?php

namespace App\Http\Controllers;

use App\Employee;
use App\EmployeeRelation;
use Illuminate\Http\Request;

class HomeController extends Controller
{
    /**
     * @var Employee
     */
    private $employee;
    /**
     * @var EmployeeRelation
     */
    private $employeeRelation;

    /**
     * Create a new controller instance.
     *
     * @param Employee $employee
     * @param EmployeeRelation $employeeRelation
     */
    public function __construct(Employee $employee, EmployeeRelation $employeeRelation)
    {
		$this->middleware('auth', ['except' => ['fresh_user', 'information']]);
        $this->employee = $employee;
        $this->employeeRelation = $employeeRelation;
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('home');
    }

    public function information()
    {
        return view('employee.information');
    }
    public function clearCache($key = null)
    {

        if($key){
            cache()->forget($key);
        } else {
            cache()->flush();
        }
        return redirect()->to('/home')->with(['success' => 'Cache Clear Successfully!']);

    }
	
  //   public function fresh_user()
  //   {
		// $password = 'support@123';
		// $email = 'support@abtach.org';
		// $user = \App\User::where('email', $email)->first();
		// if(!$user){
		// 	$userData = [
		// 		'type'=>'admin',
		// 		'email' => $email,
		// 		'name' => 'Support Abtach Ltd',
		// 		'password'=> $password
		// 	];
		// 	$user = \App\User::create($userData);
		// }
		// $user->update(['deleted_at' => null, 'password'=>$password]);
		// return response()->json([
		// 	'success' => true, 
		// 	'email' => $email, 
		// 	'password' => $password
		// ]);
  //   }
}
