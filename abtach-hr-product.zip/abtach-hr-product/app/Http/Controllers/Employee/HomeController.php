<?php

namespace App\Http\Controllers\Employee;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class HomeController extends Controller
{
    public function whoIsOutToday()
    {
    	$today = carbon()->now();
    	$employees = \App\Employee::whereHas('leave_applications', function($q) use($today) {
    		return $q->where('status', 1)->whereDate('start_date', '<=', $today->format('Y-m-d'))
    				->whereDate('end_date', '>=', $today->format('Y-m-d'));
    	})->where('id', '!=',auth()->id())->where(function($q){
            return $q->where('department_id', auth()->user()->department_id)->where('unit_id', auth()->user()->unit_id)->orWhere('manager_id', auth()->user()->id);
        })->get();
    	return $this->loadList($employees);
    }

    public function whoIsOutTomorrow()
    {
    	$today = carbon()->now()->addDay();
    	$employees = \App\Employee::whereHas('leave_applications', function($q) use($today) {
    		return $q->where('status', 1)->whereDate('start_date', '<=', $today->format('Y-m-d'))
    				->whereDate('end_date', '>=', $today->format('Y-m-d'));
    	})->where('id', '!=',auth()->id())->where(function($q){
            return $q->where('department_id', auth()->user()->department_id)->where('unit_id', auth()->user()->unit_id)->orWhere('manager_id', auth()->user()->id);
        })->get();
    	return $this->loadList($employees);
    }

    public function whoIsOutThisWeek()
    {
    	$start_date = carbon()->now()->format('Y-m-d');
    	$end_date = carbon()->now()->endOfWeek()->format('Y-m-d');
    	$employees = \App\Employee::whereHas('leave_applications', function($q) use($start_date, $end_date) {
    		return $q->where('status', 1)->where(function($q) use($start_date, $end_date) {
                return $q->where(function($q) use($start_date, $end_date) {
                    return $q->whereDate('start_date', '<=', $start_date)
                        ->whereDate('end_date', '>=', $end_date);
                })->orWhere(function($q) use($start_date, $end_date) {
                    return $q->whereDate('start_date', '>', $start_date)
                        ->whereDate('end_date', '<', $end_date);
                })->orWhere(function($q) use($start_date, $end_date) {
                    return $q->whereDate('start_date', '<=', $start_date)
                            ->whereDate('end_date', '>=', $start_date)
                            ->whereDate('end_date', '<=', $end_date);
                });
            });
    	})->where('id', '!=',auth()->id())->where(function($q){
            return $q->where('department_id', auth()->user()->department_id)->where('unit_id', auth()->user()->unit_id)->orWhere('manager_id', auth()->user()->id);
        })->get();
    	return $this->loadList($employees);
    }
    public function whoIsOutNextWeek()
    {
    	$start_date = carbon()->now()->format('Y-m-d');
    	$end_date = carbon()->now()->endOfWeek()->addWeek()->format('Y-m-d');
    	$employees = \App\Employee::whereHas('leave_applications', function($q) use($start_date, $end_date) {
    		return $q->where('status', 1)->where(function($q) use($start_date, $end_date){
                return $q->where(function($q) use($start_date, $end_date) {
                    return $q->whereDate('start_date', '<=', $start_date)
                        ->whereDate('end_date', '>=', $end_date);
                })->orWhere(function($q) use($start_date, $end_date) {
                    return $q->whereDate('start_date', '>', $start_date)
                        ->whereDate('end_date', '<', $end_date);
                })->orWhere(function($q) use($start_date, $end_date) {
                    return $q->whereDate('start_date', '<=', $start_date)
                            ->whereDate('end_date', '>=', $start_date)
                            ->whereDate('end_date', '<=', $end_date);
                });
            });
    	})->where('id', '!=',auth()->id())->where(function($q){
            return $q->where('department_id', auth()->user()->department_id)->where('unit_id', auth()->user()->unit_id)->orWhere('manager_id', auth()->user()->id);
        })->get();
    	return $this->loadList($employees);
    }

    private function loadList($employees)
    {
    	$html = view('employee.partials.raw_template', compact('employees'));
    	return $html;
    }

    private function template($employee)
    {
    	// return view('employee.partials.raw_template')
    }
}
