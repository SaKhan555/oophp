<?php

namespace App\Http\Controllers\Employee;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\EmployeeTicket;
use App\EmployeeTicketCategory;
use App\EmployeeTicketComment;

class TicketController extends Controller
{
    /**
     * @var EmployeeTicketCategory
     */
    private $ticket_category;
    /**
     * @var EmployeeTicket
     */
    private $ticket;
    /**
     * @var EmployeeTicketComment
     */
    private $ticket_comment;
    /**
     * Constructor
     * @var Employee $employee
     */
    public function __construct(EmployeeTicketCategory $ticket_category, EmployeeTicket $ticket, EmployeeTicketComment $ticket_comment)
    {
        $this->ticket_category = $ticket_category;
        $this->ticket = $ticket;
        $this->ticket_comment = $ticket_comment;
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $tickets = $this->employee_tickets()->paginate(20);
        $title = 'My Tickets';
        return view('employee.tickets.index', compact('tickets', 'title'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $title = 'Add New Ticket';
        $categories = EmployeeTicketCategory::pluck('name', 'id')->toArray();
        return view('employee.tickets.create', compact('title', 'categories'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate_rules($request);
        $data = [
            'employee_id' => auth()->id(),
            'status_id' => 1,
            'category_id' => $request->category_id,
            'subject' => $request->subject,
            'description' => $request->description
        ];
        EmployeeTicket::create($data);
        return redirect()->back()->with('success', 'Your Ticket has been submitted successfully!');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $ticket = $this->employee_tickets()->find($id);
        if($ticket){
            $title = 'Ticket Details';
            return view('employee.tickets.show', compact('ticket','title'));
        } else {
            return redirect()->back()->with('error', 'Ticket not found!');
        }
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
    /**
     * reopen ticket
     */
    public function reopen(Request $request, $id)
    {
        $ticket = $this->employee_tickets()->find($id);
        if($ticket){
            $ticket_comment_data = [
                'employee_id' => auth()->id(),
                'ticket_id' => $ticket->id,
                'status_id' => 5,
                'comment' => $request->value,
            ];
            $this->ticket_comment->create($ticket_comment_data);
            \Session::flash('success', 'Ticket re-opened');
            return response()->json(['status' => true]);
        } else {
            \Session::flash('error', 'Ticket not found');
            return response()->json(['status' => false]);
        }
    }
    /**
     * validate rules
     */
    private function validate_rules($request, $rules = [])
    {
        return $this->validate($request, array_merge([
            'category_id' => 'required',
            'subject' => 'required',
            'description' => 'required'
        ], $rules));
    }
    /**
     * get tickets
     */
    private function employee_tickets()
    {
        return $this->ticket->where('employee_id', auth()->id());
    }
}
