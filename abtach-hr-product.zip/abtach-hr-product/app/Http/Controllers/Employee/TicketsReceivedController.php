<?php

namespace App\Http\Controllers\Employee;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\EmployeeTicket;
use App\EmployeeTicketCategory;
use App\EmployeeTicketStatus;
use App\EmployeeTicketTransfer;

class TicketsReceivedController extends Controller
{
    /**
     * @var EmployeeTicketCategory
     */
    private $ticket_category;
    /**
     * @var EmployeeTicket
     */
    private $ticket;
    /**
     * @var EmployeeTicketStatus
     */
    private $ticket_status;
    /**
     * @var EmployeeTicketTransfer
     */
    private $ticket_transfer;
    /**
     * Constructor
     * @var Employee $employee
     */
    public function __construct(EmployeeTicketCategory $ticket_category, EmployeeTicket $ticket,EmployeeTicketStatus $ticket_status, EmployeeTicketTransfer $ticket_transfer)
    {
        $this->middleware('verify_employee_ticket_receiver');
        $this->ticket_category = $ticket_category;
        $this->ticket = $ticket;
        $this->ticket_status = $ticket_status;
        $this->ticket_transfer = $ticket_transfer;
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $title = 'Recieved Tickets';
        $ticket_categories = $this->ticket_category->accessable()->pluck('name','id')->toArray();
        $ticket_statuses = $this->ticket_status->pluck('name','id')->toArray();
        $tickets = $this->employee_tickets_received()->search()->paginate(20);
        return view('employee.tickets_received.index', compact('title', 'tickets','ticket_categories', 'ticket_statuses'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $ticket = $this->employee_tickets_received()->find($id);
        if($ticket){
            $title = 'Ticket - '.$ticket->subject;
            $ticket_statuses = $this->ticket_status->get_filtered_list($ticket);
            $ticket_categories = $this->ticket_category->where('id', '!=', $ticket->category_id)->namesAndIds()->toArray();
            return view('employee.tickets_received.show', compact('title','ticket','ticket_statuses', 'ticket_categories'));
        } else {
            return redirect()->back()->with('error', 'Ticket Not Found!');
        }
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $this->validate($request, [
            'category_id' => 'required'
        ]);
        $ticket = $this->employee_tickets_received()->find($id);
        if($ticket){
            $data = [
                'employee_id' => auth()->id(),
                'transfer_from' => $ticket->category_id,
                'transfer_to' => $request->category_id,
                'ticket_id' => $ticket->id,
                'comment' => $request->comment
            ];
            $this->ticket_transfer->create($data);
            return redirect()->route('portal.tickets_received.index')->with('success', 'Ticket Transfered!');
        } else {
            return back()->with('error', 'No Ticket Found!');
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
    /**
     * get tickets received
     */
    private function employee_tickets_received()
    { 
        return $this->ticket->receivable_tickets();
    }
}
