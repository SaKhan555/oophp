<?php

namespace App\Http\Controllers\Employee;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Employee;
use App\EmployeeDepartment;

class AllEmployeeController extends Controller
{
    /**
     * @var Employee
     */
    private $employee;
    /**
     * @var EmployeeDepartment
     */
    private $department;

    /**
     * EmployeeController constructor.
     * @param Employee $employee
     */
    public function __construct(Employee $employee, EmployeeDepartment $department)
    {
        $this->employee = $employee;
        $this->department = $department;
        $this->middleware('verify_employee_manager');
    }
    /**
     * show all employees
     */
    public function index()
    {
    	if(!has_special_permissions(auth()->id())){
        	return redirect('/home')->with('error', 'No Access');
        } else {
	    	$title = 'All Employees';
	    	$employees = $this->employee->query();
	    	$role = auth()->user()->role;

	    	if($role != 'admin'){
		        $managers = array_merge([
		            auth()->id()
		        ], auth()->user()->reporting_managers());
		        $employees = $employees->whereIn('manager_id', $managers);
	    	}

	        $employees = $employees->active()->search()->paginate(20);
	        $departments = $this->department->pluck('name', 'id')->toArray();
	        return view('employee.all_employees.index', compact('employees', 'title', 'departments'));

        }
    }
    /**
     * show specific employee
     */
    public function show($id)
    {
    	if(!has_special_permissions(auth()->id())){
        	return redirect('/home')->with('error', 'No Access');
        } else {
	        $employee = $this->employee->find($id);
	        $role = auth()->user()->role;
	        $managers = array_merge([
	            auth()->id()
	        ], auth()->user()->reporting_managers());
	        if($employee && (in_array($employee->manager_id, $managers) || $role == 'admin')){
		    	$title = $employee->full_name.' - Details';
		        return view('employee.all_employees.show', compact('employee', 'title'));
	        } else {
	        	return redirect()->back()->with('error', 'No Access');
	        }
        }
    }
}
