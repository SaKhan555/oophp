<?php

namespace App\Http\Controllers\Employee\Attendance\Discrepancy;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\EmployeeAttendance;
use App\EmployeeAttendanceDiscrepancy;

class DiscrepancyController extends Controller
{
    /**
     * @var EmployeeAttendance
     */
    private $attendance;
    /**
     * @var EmployeeAttendanceDiscrepancy
     */
    private $discrepancy;
    /**
     * Constructor
     * @var Employee $employee
     */
    public function __construct(EmployeeAttendance $attendance, EmployeeAttendanceDiscrepancy $discrepancy)
    {
        $this->attendance = $attendance;
        $this->discrepancy = $discrepancy;
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $discrepancies = $this->employee_discrepancies()->paginate(20);
        $title = 'Attendance Discrepancies';
        return view('employee.attendance_discrepancy.index', compact('discrepancies', 'title'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {

    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate_rules($request);
        $attendance = $this->employee_attendances()->find($request->attendance_id);
        $attendance_date = carbon()->parse($request->attendance_date);
        if($attendance_date->format('d') <= 25){
            $start_from = carbon()->parse($attendance_date)->subMonth()->format('Y-m-25');
            $end_to = carbon()->parse($attendance_date)->format('Y-m-25');
        } else {
            $start_from = carbon()->parse($attendance_date)->format('Y-m-25');
            $end_to = carbon()->parse($attendance_date)->addMonth()->format('Y-m-25');
        }
        if(auth()->user()->has_discrepancies($start_from, $end_to)){
            if($attendance && !$attendance->discrepancy){
                $data = [
                    'employee_id' => auth()->id(),
                    'comment' => $request->comment,
                    'attendance_time' => $attendance->checked_at,
                    'attendance_type' => $attendance->status,
                    'attendance_date' => $attendance->checked_at->format('Y-m-d'),
                ];
                $attendance->discrepancy()->create($data);
            } elseif(!$attendance) {
                $data = [
                    'employee_id' => auth()->id(),
                    'comment' => $request->comment,
                    'attendance_type' => ($request->attendance_type == 'check in') ? '01' : '02',
                    'attendance_date' => formatDate($request->attendance_date, 'Y-m-d')
                ];
                $this->discrepancy->create($data);
            } else {
                return response()->json(['status' => false, 'message' => 'Discrepancy already added']);
                // return back()->with('error', 'Something went wrong or The discrepancy already added');
            }
            return response()->json(['status' => true, 'message' => 'Discrepancy Added']);
        } else {
            return response()->json(['status' => false, 'message' => '6 discrepancies allowed per month which you have already submitted.']);
        }
        // return back()->with('success', 'Added Discrepancy');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $discrepancy = $this->employee_discrepancies()->find($id);
        if($discrepancy){
            $title = 'View Discrepancy';
            return view('employee.attendance_discrepancy.show', compact('title', 'discrepancy'));
        } else {
            if(auth()->user()->is_manager()){
                return redirect()->route('portal.reporting_employee.discrepancy.show', $id);
            } 
            return back()->with('error', 'Discrepancy Not Found');
        }
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
    /**
     * validate rules
     */
    public function validate_rules($request, $rules = [])
    {
        return $this->validate($request, [
            'comment' => 'required',
        ]);
    }
    /**
     * get employee discrepancies
     */
    private function employee_discrepancies()
    {
        return $this->discrepancy->where('employee_id', auth()->id());
    }
    /**
     * get employee attendances
     */
    private function employee_attendances()
    {
        return auth()->user()->employee_attendance();
    }
}
