<?php

namespace App\Http\Controllers\Employee\Attendance\Discrepancy;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\EmployeeAttendance;
use App\EmployeeAttendanceDiscrepancy;
use App\EmployeeAttendanceDiscrepancyComment;

class DiscrepancyCommentController extends Controller
{
    /**
     * @var EmployeeAttendance
     */
    private $attendance;
    /**
     * @var EmployeeAttendanceDiscrepancy
     */
    private $discrepancy;
    /**
     * @var EmployeeDiscrepancyComment
     */
    private $discrepancy_comment;
    /**
     * Constructor
     * @var Employee $employee
     */
    public function __construct(EmployeeAttendance $attendance, EmployeeAttendanceDiscrepancy $discrepancy, EmployeeAttendanceDiscrepancyComment $discrepancy_comment)
    {
        $this->attendance = $attendance;
        $this->discrepancy = $discrepancy;
        $this->discrepancy_comment = $discrepancy_comment;
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request, $discrepancy_id)
    {
        $this->validate_rules($request);
        $discrepancy = $this->discrepancy->restrictManager()->find($discrepancy_id);
        if($discrepancy){
            $data = [
                'discrepancy_id' => $discrepancy->id,
                'attendance_id' => $discrepancy->attendance_id,
                'manager_id' => auth()->id(),
                'status' => request('status'),
                'comment' => request('comment')
            ];
            $this->discrepancy_comment->create($data);
            return back()->with('success', 'Comment Added');
        } else {
            return back()->with('error', 'Something went wrong');
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    /**
     * validate inputs
     */
    public function validate_rules($request, $rules = [])
    {
        return $this->validate($request, array_merge([
            'status' => 'required|numeric',
        ], $rules));
    }
}
