<?php

namespace App\Http\Controllers\Employee;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Employee;

class TeamHierarchyController extends Controller
{
    protected $employee;

	public function __construct(Employee $employee)
	{
		$this->employee = $employee;
	}
	/**
	 * Company Hierarchy list
	 */
	public function index()
	{
		$employees = $this->employee->where('manager_id', auth()->id())->where('id', '!=', auth()->id())->get();
		$title = 'Team List';
		return view('employee.team.hierarchy.index', compact('employees', 'title'));
	}
}
