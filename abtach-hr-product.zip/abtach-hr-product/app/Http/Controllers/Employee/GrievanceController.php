<?php

namespace App\Http\Controllers\Employee;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\EmployeeGrievance;
use App\Employee;

class GrievanceController extends Controller
{
    protected $grievance;
    protected $employee;

    /**
     * constructor
     */
    public function __construct(EmployeeGrievance $grievance, Employee $employee) 
    {
        $this->grievance = $grievance;
        $this->employee = $employee;
    }
    /**
     * retrivance employe grievances
     */
    private function employee_grievances()
    {
        return $this->grievance->where('employee_id', auth()->id());
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $title = 'Grievances';
        $grievances = $this->employee_grievances()->search()->paginate(20);
        return view('employee.grievance.index', compact('title', 'grievances'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $title = 'Create Grievance';
        $employees = $this->employee->active()->select('id', \DB::raw("CONCAT(full_name,' --- ',designation) as full_name"))->pluck('full_name', 'id')->toArray();
        return view('employee.grievance.create', compact('title', 'employees'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate_rules($request);
        $data = [
            'employee_id' => auth()->id(),
            'description' => $request->description,
            'against' => $request->against
        ];
        $this->grievance->create($data);
        return redirect()->route('portal.grievance.index')->with('success', 'Grievance Submitted!');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $grievance = $this->employee_grievances()->find($id);
        if($grievance){
            $title = 'View Girevance';
            return view('employee.grievance.show', compact('title', 'grievance'));
        } else {
            return back()->with('error', 'Grievance not found!');
        }
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {

    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
    /**
     * validate input rules 
     */
    public function validate_rules($request)
    {
        return $this->validate($request, [
            'against' => 'required',
            'description' => 'required',
        ]);
    }
}
