<?php

namespace App\Http\Controllers\Employee;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\EmployeeLeaveType;
use App\EmployeeLeaveApplication;
use App\EmployeeLeaveApproval;
use Carbon\Carbon;
use Illuminate\Support\Facades\Mail;
use App\Mail\EmployeeLeaveApplicationEmail;
use App\Mail\EmployeeLeaveStatus;
use App\User;
use App\Employee;

class LeaveApplicationController extends Controller
{
    /**
     * @var EmployeeLeaveApplication
     */
    private $employee_leave_application;
    /**
     * @var EmployeeLeaveApproval
     */
    private $employee_leave_approval;
    /**
     * @var EmployeeLeaveType
     */
    private $employee_leave_type;
    /**
     * @var Employee
     */
    private $employee;
    /**
     * ExpenseController constructor.
     * @param EmployeeLeaveApplication $employee_leave_application
     */
    public function __construct(EmployeeLeaveApplication $employee_leave_application,EmployeeLeaveApproval $employee_leave_approval, Employee $employee, EmployeeLeaveType $employee_leave_type)
    {
        $this->middleware('verify_employee_active')->only(['create', 'store']);
        $this->employee_leave_application = $employee_leave_application;
        $this->employee_leave_approval = $employee_leave_approval;
        $this->employee_leave_type = $employee_leave_type;
        $this->employee = $employee;
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $title = 'Applied for Time Off';
        $employee_id = auth()->guard('web')->user()->id;
        $query = $this->employee_leave_application->where('employee_id', $employee_id);
        if(request('current')){
            $query = $query->where('status', 0)->orWhere(function($q){
                return $q->whereDate('end_date', '>=', carbon()->now()->format('Y-m-d'));
            });
        }
        $leave_applies = $query->paginate(20);
        return view('employee.leave.index', compact('title', 'leave_applies'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $title = 'Apply For Time Off';
        $leave_types = EmployeeLeaveType::pluck('title','id')->toArray();
        return view('employee.leave.create', compact('title','leave_types'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $employee_id = auth()->guard('web')->user()->id;
        // validate
        $start_date = carbon()->createFromFormat('d/m/Y', request('start_date'));
        $end_date = carbon()->createFromFormat('d/m/Y', request('end_date'));
        if($start_date->greaterThan($end_date)){
            return redirect()->back()->with('error', 'Start Date must be a date before End Date');
        }
        $this->validate($request,$this->validation_rules());
        // create
        $start_date = carbon()->createFromFormat('d/m/Y', $request->input('start_date'));
        $end_date = ($request->input('end_date')) ? carbon()->createFromFormat('d/m/Y', $request->input('end_date')) : $start_date;

        $start_date_compare = $start_date->format('Y-m-d');
        $end_date_compare = $end_date->format('Y-m-d');
        $applied = $this->employee_leave_application->where('employee_id', $employee_id)
                        ->where(function($q) use($start_date_compare, $end_date_compare){
                            return $q->whereDate('start_date', '<=' ,$start_date_compare)
                                    ->whereDate('end_date', '>=' ,$end_date_compare);
                        })->first();
        // if($applied) {
        //     return redirect()->back()->with('error', 'Already applied for this date');
        // } else {
            if($request->leave_type == 5) {
                $total_leaves = .5;
            } else {
                $total_leaves = $start_date->diffInDays($end_date) + 1;
            }
            $data = [
                'employee_id' => $employee_id,
                'leave_type_id' => $request->leave_type,
                // 'contact_number' => $request->contact_number,
                'start_date' => $start_date,
                'end_date' => $end_date,
                // 'reason' => $request->reason,
                'total_leave' => $total_leaves
            ];
            $leave_application = $this->employee_leave_application->create($data);
            // email setup
            $email = $leave_application->employee->manager_employee->email;
            $cc_emails = [];
            $users_emails = User::where('email_notify', 1)->pluck('email');
            foreach($users_emails as $user_email) {
                if($user_email != $email){
                    $cc_emails[] = $user_email;
                }
            }
            // send email
            Mail::to($email)->cc(array_unique($cc_emails))->send(new EmployeeLeaveApplicationEmail($leave_application));
            return redirect()->route('portal.leave.index')->with('success', 'Your application has been submitted successfully');
        // }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
    /**
     * Leave Applications
     */
    public function applications() 
    {
        $title = 'Time Off Requests';
        $role = strtolower(auth()->guard('web')->user()->role);
        $employees_list = $this->employee->active();
        if(auth()->user()->role != 'admin'){
            $employees_list = $employees_list->whereIn('manager_id', 
                array_merge([auth()->id()], auth()->user()->reporting_managers())
            );
        }
        $employees_list = $employees_list->pluck('full_name','id')->toArray();
        $leave_applications = $this->employee_leave_application->restrictManager()->search()->paginate(20);
        $leave_types = $this->employee_leave_type->pluck('title', 'id')->toArray();
        return view('employee.leave_applications.index', compact('title','leave_applications', 'employees_list','leave_types'));
    }
    /**
     * Approve application
     */
    public function approve(Request $request)
    {
        $this->validate($request, [
            'comments' => 'required',
            'status' => 'required'
        ]);
        $leave_application = $this->employee_leave_application->find($request->leave_id);
        $employee = $leave_application->employee;

        $role = strtolower(auth()->guard('web')->user()->role);
        $managers = array_merge([
                auth()->id()
            ], auth()->user()->reporting_managers());
        if($employee && (in_array($employee->manager_id, $managers) || $role == 'admin')){
            if($role != 'admin' && ($request->status == 1 && ($employee->leaves_in_balance() < $leave_application->total_leave))) {
                return redirect()->back()->with('error', 'This employee has '.$employee->leaves_in_balance().' leaves in balance');
            } else {
                $manager_id = auth()->guard('web')->user()->id;
                $data = [
                    'leave_id' => $request->leave_id,
                    'manager_id' => $manager_id,
                    'comments' => $request->comments,
                    'status' => $request->status,
                ];
                $leave_approval = $this->employee_leave_approval->create($data);
                // email setup
                $employee = Employee::find($manager_id);
                $email = $leave_application->employee->email;
                $cc_emails = [];
                $users = User::where('email_notify', 1)->pluck('email');
                foreach($users as $user) {
                    $cc_emails[] = $user;
                }
                // if($employee->role != 'admin') {
                //     $cc_emails[] = $employee->manager_employee->email;
                // }
                // send email
                Mail::to($email)->cc(array_unique($cc_emails))->send(new EmployeeLeaveStatus($leave_application,$leave_approval, $employee));
                return back()->with('success','Updated Successfully');
            }
        } else {
            return redirect()->back()->with('error', 'No Access');
        }

    }
    /**
     * Show Application
     */
    public function showApplication($id) 
    {
        $title = 'View Time Off Request';
        $leave_application = $this->employee_leave_application->find($id);
        $employee = $leave_application->employee;
        $role = strtolower(auth()->guard('web')->user()->role);
        $managers = array_merge([
                auth()->id()
            ],auth()->user()->reporting_managers());
        if($employee && ($employee->id == auth()->id()) || (in_array($employee->manager_id, $managers) || $role == 'admin')){
            return view('employee.leave_applications.show', compact('title', 'leave_application'));
        } else {
            return redirect()->back()->with('error', 'No Access');
        }
    }
    /**
     * Update Status
     */
    public function approveStatus(Request $request, $id)
    {
        $leave_application = $this->employee_leave_approval->find($id);
        $newStatus = ($leave_application->status == 1) ? 0 : 1;

        $leave_application->update(['status'=>$newStatus]);

        if($request->ajax()){
            return response()->json(['updated' => true, 'status' => $newStatus]);
        }

        return redirect()->back();
    }
    
    /**
     * Validation rules
     */
    public function validation_rules($rules=[])
    {
        // $start_date = carbon()->createFromFormat('d/m/Y',request('start_date'))->format('d-m-Y');
        // $end_date = carbon()->createFromFormat('d/m/Y',request('end_date'))->format('d-m-Y');
        return array_merge([
            // 'contact_number' => 'required',
            'leave_type' => 'required',
            'start_date' => "required",
            'end_date' => "required",
            // 'reason' => 'required',
        ], $rules);
    }
}
