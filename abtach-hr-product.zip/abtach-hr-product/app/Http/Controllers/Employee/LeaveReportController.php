<?php

namespace App\Http\Controllers\Employee;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class LeaveReportController extends Controller
{
    /**
     * Show report
     */
    public function index()
    {
    	$type = request('type');
		$employee = auth()->guard('web')->user();

    	switch ($type) {
    		case 'monthly':
    			return view('employee.leave_report.monthly', compact('employee'));
    		break;

    		case 'account' :
    			return view('employee.leave_report.account', compact('employee'));
    		break;

    		default:
    			return view('employee.leave_report.yearly', compact('employee'));
    		break;
    	}
    }
}
