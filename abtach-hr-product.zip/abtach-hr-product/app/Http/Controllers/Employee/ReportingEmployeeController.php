<?php

namespace App\Http\Controllers\Employee;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Employee;
use App\EmployeeAttendance;
use App\EmployeeAttendanceLog;
use Carbon\Carbon;

class ReportingEmployeeController extends Controller
{
    /**
     * @var Employee
     */
    private $employee;

    /**
     * EmployeeController constructor.
     * @param Employee $employee
     */
    public function __construct(Employee $employee)
    {
        $this->employee = $employee;
        $this->middleware('verify_employee_manager');
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $employees = $this->employee->query();
        $role = strtolower(auth()->guard('web')->user()->role);
        if($role != 'admin') {
            $managers = array_merge([
                auth()->id()
            ], auth()->user()->reporting_managers());
            $employees = $employees->whereIn('manager_id', $managers);
        }
        $employees = $employees->active()->search()->paginate(20);
        $title = 'Employees';
        return view('employee.reporting_employees.index', compact('title', 'employees'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        // 
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    /**
     * show employee attendance
     */
    public function attendance($id)
    {
        $employee = $this->employee->find($id);
        $role = strtolower(auth()->guard('web')->user()->role);
        $managers = array_merge([
                auth()->id()
            ], auth()->user()->reporting_managers());
        if($employee && (in_array($employee->manager_id, $managers) || $role == 'admin')){
            $title = $employee->full_name.' - Attendance';
            $attendance_months = $employee->monthly_attendance();
            // return $attendance_months_data;
            return view('employee.reporting_employees.attendance', compact('employee','attendance_months','title'));
        } else {
            return redirect()->route('portal.reporting-employee.index')->with('error','Access denied!');
        }
    }
    /**
     * show employee attendance summary
     */
    public function attendanceSummary($id)
    {
        $employee = $this->employee->find($id);
        $role = strtolower(auth()->guard('web')->user()->role);
        $managers = array_merge([
                auth()->id()
            ], auth()->user()->reporting_managers());
        if($employee && (in_array($employee->manager_id ,$managers) || $role == 'admin')){
            $title = $employee->full_name.' - Attendance Summary';
            $month = (request('month')) ? request('month') : carbon()->now()->format('m-Y');
            $period_interval = period_interval(carbon()->parse('26-'.$month)->subMonths(1));
            return view('employee.reporting_employees.attendance_summary', compact('employee','title','period_interval'));
        } else {
            return redirect()->route('portal.reporting-employee.index')->with('error','Access denied!');
        }
    }
    /**
     * attend on behalf of emloyee
     */
    public function attend(Request $request, $id)
    {
        $employee = $this->employee->find($id);
        $role = strtolower(auth()->guard('web')->user()->role);
        $managers = array_merge([
                auth()->id()
            ], auth()->user()->reporting_managers());
        if($employee && (in_array($employee->manager_id ,$managers) || $role == 'admin')){
            $date = str_replace('/', '-', $request->date).' '.$request->checked_at;
            $timestamp = Carbon::parse($date)->format('Y-m-d H:i:s');
            $data = [
                'employee_id' => $employee->employee_id,
                'status' => $request->status,
                'type' => 'manual',
                'checked_at' => $timestamp,
                'created_at' => $timestamp
            ];
            $employee_attendance = EmployeeAttendance::create($data);
            if($employee_attendance) {
                // create log
                EmployeeAttendanceLog::create([
                    'employee_attendance_id' => $employee_attendance->id,
                    'employee_id' => auth()->id(),
                    'action' => 'created attendance',
                    'new_time' => $timestamp,
                ]);
            }
            if(request()->ajax()){
                return response()->json(['status' => true]);
            } else {
                return redirect()->back()->with('success','updated successfully');
            }
        } else {
            return redirect()->back()->with('error', 'Not Allowed');
        }
    }
    /**
     * update time for specific attendance
     */
    public function updateAttendanceTime(Request $request, $id)
    {
        $employee_attendance = EmployeeAttendance::find($id);
        $employee = $employee_attendance->employee;
        $role = strtolower(auth()->guard('web')->user()->role);
        $managers = array_merge([
                auth()->id()
            ], auth()->user()->reporting_managers());
        if($employee_attendance && (in_array($employee->manager_id ,$managers) || $role == 'admin')) {
            $prev_timestamp = $employee_attendance->checked_at;
            $timestamp = $employee_attendance->checked_at->format('Y-m-d').' '.$request->value;
            $timestamp = formatDate($timestamp, 'Y-m-d H:i:s');
            $employee_attendance->update([
                'checked_at' => $timestamp,
                'created_at' => $timestamp,
            ]);
            // create log
            EmployeeAttendanceLog::create([
                'employee_attendance_id' => $employee_attendance->id,
                'employee_id' => auth()->id(),
                'action' => 'update attendance time',
                'previous_time' => $prev_timestamp,
                'new_time' => $timestamp,
            ]);
            return response()->json(['status' => true]);
        }
        return response()->json(['status' => false]);
    }
    /**
     * leave applications
     */
    public function leaveApplications($id)
    {
        $employee = $this->employee->find($id);
        if($employee) {
            $title = $employee->full_name.' - Leave Applications';
            $leave_applications = $employee->leave_applications;
            return view('employee.reporting_employees.leave_applications',compact('leave_applications', 'employee'));
        } else {
            return redirect()->back()->with('error', 'No Access');
        }
    }
}
