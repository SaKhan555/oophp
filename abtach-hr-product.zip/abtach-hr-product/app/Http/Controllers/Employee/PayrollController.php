<?php

namespace App\Http\Controllers\Employee;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Barryvdh\DomPDF\PDF;

class PayrollController extends Controller
{
    // pdf
    protected $pdf;

    public function __construct(PDF $pdf)
    {
        $this->pdf = $pdf;
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $employee = auth()->user();
        $requested_month = request('month');
        $month = ($requested_month) ? carbon()->parse("1-$requested_month") : carbon()->now();
        // if(($month->format('m') == '09' && $month->format('Y') == '2018' && !request('is_admin'))){
        //     return back()->with('error', 'Not Found');
        // } else {
            $title = 'Payslip - '.$month->format('F Y');
            $current_payroll = \App\EmployeeSalarySlip::where('employee_id', auth()->id())->whereMonth('month', '=', $month->format('m'))->whereYear('month', '=', $month->format('Y'))->first();
            $generated = true;
            if(!$current_payroll || request('attendance')){
                // check if requested month is before july 2018 or before joining
                if($month->format('m') < '07' && $month->format('Y') == '2018'){
                    // redirect back
                    return redirect()->back()->with('error','Salary Slip not found!');
                } else {
                    $current_payroll = new \App\Employee\Payroll($employee, $month->format('m-Y'));
                    $generated = false;
                }
            }
            return view('employee.payroll.index', compact('employee', 'title', 'month', 'current_payroll','generated'));
        // }
    }
    /**
     * generate pdf
     */
    public function generate_pdf()
    {
        // $this->pdf->setOptions(['dpi' => 150, 'defaultFont' => 'sans-serif']);
        $employee = auth()->user();
        $requested_month = request('month');
        $month = ($requested_month) ? carbon()->parse("1-$requested_month") : carbon()->now();
        // if($month->format('m') == '09' && $month->format('Y') == '2018'){
        //     return back()->with('error', 'Not Found');
        // } else {
            $title = 'Salary Slip for the month of '.$month->format('F Y');
            $current_payroll = \App\EmployeeSalarySlip::where('employee_id', auth()->id())->whereMonth('month', '=', $month->format('m'))->whereYear('month', '=', $month->format('Y'))->first();
            if($current_payroll){
                $pdf = $this->pdf->loadView('employee.payroll.pdf', ['current_payroll' => $current_payroll,'employee'=> $employee, 'title' => $title]);
                return $pdf->stream();
            } else {
                return back()->with('error', 'Not Found');
            }
        // }
    }
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
