<?php

namespace App\Http\Controllers\Employee;

use App\Employee;
use App\EmployeeAttendance;
use App\EmployeeSetting;
use Carbon\Carbon;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\EmployeeAttendanceLog;

class AttendanceController extends Controller
{
    /**
     * @var EmployeeAttendance
     */
    private $employeeAttendance;
    /**
     * @var EmployeeSetting
     */
    private $employeeSetting;
    /**
     * @var Employee
     */
    private $employee;

    public function __construct(EmployeeAttendance $employeeAttendance,EmployeeSetting $employeeSetting, Employee $employee)
    {
        $this->employeeAttendance = $employeeAttendance;
        $this->employeeSetting = $employeeSetting;
        $this->employee = $employee;
        $this->middleware('verify_employee_manager')->only(['edit','update']);
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $employee = auth()->user();
        $title = 'Employee Attendance';
        $month = (request('month')) ? carbon()->createFromFormat('m-Y',request('month')) : carbon()->now();
        $starts_from = carbon()->parse('26-'.$month->format('m-Y'))->subMonths(1);
        $period_interval = period_interval($starts_from);
        $has_discrepancies = $employee->has_discrepancies($starts_from->format('Y-m-25'), $month->format('Y-m-26'));
        return view('employee.attendance.index', compact('period_interval','employee','title', 'has_discrepancies'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $employeeAttendance = $this->employeeAttendance->where('employee_id', auth()->id())->whereNull('check_out')->orderBy('id','DESC')->first();
        return view('employee.attendance', compact('employeeAttendance'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
		
        $created_at_date = Carbon::now('Asia/Karachi');
        $employeeSetting = $this->employeeSetting->where('employee_id', auth()->id())->first();
        if(request('type')=='checkin'){
            $employeeAttendance = $this->employeeAttendance->where('employee_id', auth()->id())->whereDate('created_at', '=', Carbon::today()->toDateString())->first();


           // return $employeeSetting;

            if($employeeAttendance)
            {
                return redirect()->back()->with('error', 'Already Checked In');
            }
            $startTime = ($created_at_date->format('g:i:s A'));
            $startTime = Carbon::parse($startTime);
            $finishTime = Carbon::parse($employeeSetting->check_in);
            if($startTime>$finishTime)
            {
                $totalDuration = $finishTime->diffInSeconds($startTime);
                $lateToday = ($totalDuration/60);
                if($lateToday>30) {$todayLate=1;} else {$todayLate=0;}
                if($lateToday>=120) {$halfDay=1;} else {$halfDay=0;}
                if($lateToday>=300) {$present=0;} else {$present=1;}
                $late =secToHR($totalDuration);
            }
            else
            {
                $late = '';
                $todayLate=0;
                $halfDay=0;
                $present=1;
            }
            $this->employeeAttendance->create([
                    'employee_id' => auth()->id(),
                    'check_in' => $startTime,
                    'date' => $created_at_date->format('d/m/Y'),
                    'late_hour' => $late,
                    'present' => $present,
                    'late' => $todayLate,
                    'half_day' => $halfDay,

                ]);
                return redirect()->back()->with('success', 'Checked In Successfully');

        }
        elseif(request('type')=='checkout')
        {
            $employeeAttendance = $this->employeeAttendance->where('employee_id', auth()->id())->whereNull('check_out')->orderBy('id','DESC')->first();
            $workingHours = $employeeSetting->total_work_hour;
            $startTime = Carbon::parse($employeeAttendance->check_in);
			
            $finishTime = $created_at_date->format('g:i:s A');
            $finishTime = Carbon::parse($finishTime);
			
            $totalDuration = $finishTime->diffInSeconds($startTime);
           // $workHours = gmdate('H:i:s', $totalDuration);
		    $workHours = ($totalDuration/3600);
            $halfDay=0;
            if($workHours<$workingHours)
            {
               $totalHoursWorked = $workingHours-$workHours;
			   if($totalHoursWorked>=2)
               {
                   $halfDay=1;
               }
            }
            $employeeAttendance->update([
                'check_out' => $finishTime,
                'working_hour' => secToHR($totalDuration),
                'half_day' => $halfDay,
            ]);
            return redirect()->back()->with('success', 'Checked Out Successfully');
        }

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        return view('employee.index');
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        return back()->with('error', 'Not Found');
        // $attendance = $this->employeeAttendance->find($id);
        // $role = auth()->user()->role;
        // if($attendance->employee && (($role == 'admin') || ($attendance->employee->manager_id == auth()->id()))){
        //     $title = $attendance->details();
        //     return view('employee.attendance.edit', compact('attendance','title'));
        // } else {
        //     return redirect()->route('portal.reporting-employee.index')->with('error','Access denied');
        // }
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $this->validate_rules($request);
        $attendance = $this->employeeAttendance->find($id);
        if($attendance) {
            $prev_timestamp = $attendance->checked_at;
            // update attendance
            $timestamp = Carbon::parse($request->date.' '.$request->time);
            $data = [
                'checked_at' => $timestamp,
                // 'status' => $request->status
            ];
            $attendance->update($data);
            // create log
            EmployeeAttendanceLog::create([
                'employee_attendance_id' => $id,
                'employee_id' => auth()->id(),
                'action' => 'updated attendance',
                'previous_time' => $prev_timestamp,
                'new_time' => $timestamp,
            ]);
        }

        return redirect()->route('portal.reporting-employee.attendance', $attendance->employee->id)->with('success' ,'Updated Successfully');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
    /**
     * validate rules
     */
    public function validate_rules(Request $request, $rules=[])
    {
        return $this->validate($request, array_merge([
            'date' => 'required',
            'time' => 'required',
        ], $rules));
    }
}
