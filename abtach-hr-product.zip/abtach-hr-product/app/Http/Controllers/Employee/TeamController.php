<?php

namespace App\Http\Controllers\Employee;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Employee;

class TeamController extends Controller
{
    protected $employee;

	public function __construct(Employee $employee)
	{
		$this->employee = $employee;
	}
	/**
	 * Company Hierarchy list
	 */
	public function index()
	{
		$employees = $this->employee->where('manager_id', auth()->id())->orWhere('department_id', auth()->user()->department_id)->where('id', '!=', auth()->id())->get();
		$title = 'Team List';
		return view('employee.team.index', compact('employees', 'title'));
	}
}
