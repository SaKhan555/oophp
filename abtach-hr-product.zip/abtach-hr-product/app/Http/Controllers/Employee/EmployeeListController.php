<?php

namespace App\Http\Controllers\Employee;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Employee;

class EmployeeListController extends Controller
{
    public function index()
    {
    	$title = 'Employees List';
    	$query = Employee::active();
    	if(request('department')){
    		$query = $query->where('department_id', auth()->user()->department_id);
    	}
    	$employees = $query->orderBy('full_name', 'asc')->paginate(30);
    	return view('employee.employees_list.index', compact('title', 'employees'));
    }
}
