<?php

namespace App\Http\Controllers\Employee;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\EmployeeGrievanceComment;

class GrievanceCommentController extends Controller
{
    protected $grievance_comment;
    /**
     * cosntructor
     */
    public function __construct(EmployeeGrievanceComment $grievance_comment)
    {
        $this->grievance_comment = $grievance_comment;
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request, $grievance_id)
    {
        $this->validate_rules($request);
        $data = [
            'employee_id' => auth()->user()->id,
            'grievance_id' => $grievance_id,
            'comment' => $request->comment,
            'status' => $request->status,
        ];
        $this->grievance_comment->create($data);
        return redirect()->route('portal.all_grievance.show', $grievance_id)->with('success', 'Comment Added Successfully');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
    /**
     * validate rules
     */
    public function validate_rules($request)
    {
        return $this->validate($request, [
            'status' => 'required|numeric',
            'comment' => 'required'
        ]);
    }
}
