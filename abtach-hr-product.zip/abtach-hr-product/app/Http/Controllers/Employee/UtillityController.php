<?php

namespace App\Http\Controllers\Employee;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Employee;
use Carbon\Carbon;

class UtillityController extends Controller
{
	
   public function whosOut(){
    $date = carbon()->now();
    if (request()->type == 'tomorrow') {
      $date = carbon()->now()->addDay(1);
    } 
        $employee = \App\Employee::whereHas('leave_applications', function($q) use($date) {
            $q->where('status', 1)->whereDate('start_date', '<=', $date->format('Y-m-d'))
                    ->whereDate('end_date', '>=', $date->format('Y-m-d'));
        })->where('id', '!=',auth()->id())->where(function($q){
            $q->where('department_id', auth()->user()->department_id)->orWhere('manager_id', auth()->user()->id);
        })->get();
        return view('employee.utillities.whosout',compact('employee'));
    }   

    public function emp_birthday_tomorrow(){
   	$date = carbon()->now();
   	if (request()->type == 'tomorrow') {
   		$date = carbon()->now()->addDay(1);
   	} 
        $employees = \App\Employee::whereMonth('birth_date', '=', $date->format('m'))->whereDay('birth_date', '=', $date->format('d'))->get();
        $employees_anniversary = \App\Employee::whereYear('join_date','<',$date->format('Y'))->whereMonth('join_date', '=', $date->format('m'))->whereDay('join_date', '=', $date->format('d'))->get();
         return view('employee.utillities.birthdays',compact('employees','employees_anniversary'));
    }
}
