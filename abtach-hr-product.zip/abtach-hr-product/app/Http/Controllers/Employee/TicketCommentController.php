<?php

namespace App\Http\Controllers\Employee;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\EmployeeTicket;
use App\EmployeeTicketCategory;
use App\EmployeeTicketStatus;
use App\EmployeeTicketComment;

class TicketCommentController extends Controller
{
    /**
     * @var EmployeeTicketCategory
     */
    private $ticket_category;
    /**
     * @var EmployeeTicket
     */
    private $ticket;
    /**
     * @var EmployeeTicketStatus
     */
    private $ticket_status;
    /**
     * @var EmployeeTicketComment
     */
    private $ticket_comment;
    /**
     * Constructor
     * @var Employee $employee
     */
    public function __construct(EmployeeTicketCategory $ticket_category, EmployeeTicket $ticket,EmployeeTicketStatus $ticket_status, EmployeeTicketComment $ticket_comment)
    {
        $this->middleware('verify_employee_ticket_receiver');
        $this->ticket_category = $ticket_category;
        $this->ticket = $ticket;
        $this->ticket_status = $ticket_status;
        $this->ticket_comment = $ticket_comment;
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request, $ticket_id)
    {
        $this->validate_rules($request);
        $ticket = $this->employee_tickets_received()->find($ticket_id);
        if($ticket){
            $datetime = $request->datetime;
            $datetime = ($datetime) ? carbon()->createFromFormat('d/m/Y', $datetime)->format('Y-m-d h:i:s') : carbon()->now()->format('Y-m-d h:i:s');
            $data = [
                'ticket_id' => $ticket->id,
                'employee_id' => auth()->id(),
                'status_id' => $request->status_id,
                'comment' => $request->comment,
                'datetime' => $datetime
            ];
            $ticket_comment = $this->ticket_comment->create($data);
            return redirect()->back()->with('success', 'Comment Added!');
        } else {
            return redirect()->back()->with('error', 'Ticket Not Found!');
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
    /**
     * validate rules
     */
    private function validate_rules($request, $rules = [])
    {
        return $this->validate($request, [
            'status_id' => 'required',
            'comment' => 'required'
        ]);
    }
    /**
     * get tickets received
     */
    private function employee_tickets_received()
    { 
        return $this->ticket->receivable_tickets();
    }
}
