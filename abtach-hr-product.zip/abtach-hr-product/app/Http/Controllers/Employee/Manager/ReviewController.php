<?php

namespace App\Http\Controllers\Employee\Manager;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\EmployeeReview;
use App\Employee;
use App\EmployeeReviewType;

class ReviewController extends Controller
{
    protected $employee;
    protected $review;
    protected $review_type;
    /**
     * constructor
     */
    public function __construct(Employee $employee, EmployeeReview $review, EmployeeReviewType $review_type)
    {
        $this->employee = $employee;
        $this->review = $review;
        $this->review_type = $review_type;
    }
    /**
     * employee reviews
     */
    private function employee_reviews()
    {
        return $this->review->where('submit_by', auth()->id())->where('review_type_id', 3);
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $title = 'Manager Reviews';
        $reviews = $this->employee_reviews()->get();
        return view('employee.manager.review.index', compact('reviews', 'title'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $title = 'Year End Review';
        return view('employee.manager.review.create', compact('title', 'review_types'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate_rules($request);
        $data = [
            'submit_by' => auth()->id(),
            'submit_to' => (auth()->user()->manager_id) ? auth()->user()->manager_id : 0,
            'review' => htmlspecialchars($request->review),
            'review_type_id' => 3
        ];
        $this->review->create($data);
        return redirect()->route('portal.manager.review.index')->with('success', 'Review Submitted Successfully');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $review = $this->employee_reviews()->find($id);
        if($review){
            $title = 'View Review';
            return view('employee.manager.review.show', compact('title', 'review'));
        } else {
            return redirect()->route('employee.manager.review.index')->with('error', 'Review not found');
        }
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
    /**
     * validate rules
     */
    public function validate_rules($request)
    {
        return $this->validate($request, [
            'review' => 'required',
        ]);
    }
}
