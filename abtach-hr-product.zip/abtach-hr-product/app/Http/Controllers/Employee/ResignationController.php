<?php

namespace App\Http\Controllers\Employee;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\EmployeeResignation;
use App\EmployeeResignationReason;
use App\EmployeeResignationComment;

class ResignationController extends Controller
{
    /**
     * @var EmployeeResignation
     */
    private $resignation;
    /**
     * @var EmployeeResignation
     */
    private $resignation_comment;
    /**
     * @var EmployeeResignationReason
     */
    private $reason;
    /**
     * ExpenseController constructor.
     * @param EmployeeResignation $resignation
     */
    public function __construct(EmployeeResignation $resignation, EmployeeResignationReason $reason, EmployeeResignationComment $resignation_comment)
    {
        $this->resignation = $resignation;
        $this->reason = $reason;
        $this->resignation_comment = $resignation_comment;
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $title = 'Apply For Resignation';
        $employee = auth()->user();
        $reasons = $this->reason->pluck('name', 'id')->toArray();
        $resignations = $employee->resignations;
        return view('employee.resignations.create', compact('title','employee', 'reasons','resignations'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        if(auth()->user()->current_status == 'Notice Period'){
            return back()->with('error', 'Already Applied!');
        } else {
            $this->validate_rules($request);
            $effective_date = carbon()->createFromFormat('d/m/Y',$request->effective_date)->format('Y-m-d');
            if(auth()->user()->current_status == 'Probation'){
                $end_date = carbon()->createFromFormat('d/m/Y',$request->effective_date)->addWeek()->subDay()->format('Y-m-d');
            } else {
                $end_date = carbon()->createFromFormat('d/m/Y',$request->effective_date)->addMonth()->subDay()->format('Y-m-d');
            }
            $data = [
                'employee_id' => auth()->id(),
                'reason_id' => $request->reason_id,
                'effective_date' => $effective_date,
                'end_date' => $end_date,
                'comments' => $request->comments
            ];
            $this->resignation->create($data);
            return redirect()->back()->with('success', 'Successfully applied for resignation');
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $resignation = $this->resignation->find($id);
        if($resignation){
            $title = $resignation->employee->full_name.' - Resignation';
            return view('employee.resignations.show', compact('title', 'resignation'));
        } else {
            return redirect()->back('error', 'Not Found');
        }
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    // validte rules
    private function validate_rules(Request $request, $rules = [])
    {
        return $this->validate($request, array_merge([
            'effective_date' => 'required',
            'reason_id' => 'required|numeric',
            'comments' => 'required'
        ], $rules));
    }
}
