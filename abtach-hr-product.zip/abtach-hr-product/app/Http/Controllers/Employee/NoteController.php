<?php

namespace App\Http\Controllers\Employee;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\EmployeeNote;

class NoteController extends Controller
{
	/**
	 * EmployeeNote $employee_note
	 */
	private $employee_note;
	/**
	 * constructor
	 */
	public function __construct(EmployeeNote $employee_note)
	{
		$this->employee_note = $employee_note;
	}
    /**
     * list notes
     */
    public function index()
    {
    	$notes = auth()->user()->notes;
    	$title = 'Notice Board';
    	return view('employee.notes.index', compact('title', 'notes'));
    }
    /**
     * mark latest note seen
     */
    public function markSeen()
    {
    	$note = auth()->user()->notes()->first();
    	$note->update([
    		'seen' => 1
    	]);
    	return json_encode([
    		'status' => true
    	]);
    }
}
