<?php

namespace App\Http\Controllers\Employee;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Employee;
use Illuminate\Support\Facades\Mail;
use App\Mail\EmployeeDesignationChanged;

class ProfileController extends Controller
{
    private $employee;
    /**
     * constructor
     */
    public function __construct(Employee $employee)
    {
        $this->employee = $employee;
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        // $title = 'Edit Profile';
        // $user = $this->employee->find(auth()->id());
        // return view('employee.profile', compact('title', 'user'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {
        // $this->validate_rules($request);
        $user = $this->employee->find(auth()->id());
        if($request->value){
            $data = [
                $request->name => $request->value,
            ];
            $user->update($data);
        }
        // send email if designation changed
        if($request->name == 'designation'){
            $user->employee_designation()->create([
                'name' => $request->value
            ]);
            Mail::to(admin_emails())->send(new EmployeeDesignationChanged($user));
        } 
        return response()->json(['status' => true]);
    }
    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function updatePicture(Request $request)
    {
        $this->validate_rules($request);
        $user = $this->employee->find(auth()->id());
        $file_name = $user->photo;
        if($request->hasFile('photo')){
            $old_file_path = public_path().'/uploads/employee/avatars/'.$file_name;
            if($file_name && file_exists($old_file_path)){
                unlink($old_file_path);
            }
            $file = $request->file('photo');
            $file_name = $user->employee_id.'.'.$file->getClientOriginalExtension();
            $file->move('uploads/employee/avatars' , $file_name);  
            $user->update([
                'photo' => $file_name
            ]);
        }
        return redirect()->back()->with('success', 'Profile Picture Updated!');
    }
    /**
     * complete profile
     */
    public function complete(Request $request)
    {
        $this->validate($request, [
            // 'reference' => 'required',
            // 'birth_date' => 'required',
            // 'address' => 'required',
            'bank_details.*' => 'required',
            'emergenc_contact.*' => 'required'
        ]);
        // update employee data
        $data = [
            // 'reference' => $request->reference,
            // 'birth_date' => carbon()->createFromFormat('d/m/Y', $request->birth_date)->format('Y-m-d'),
            // 'address' => $request->address,
            'bank_details' => $request->bank_details,
            'profile_completed' => 1
        ];
        auth()->user()->update($data);
        // add emergency contacts
        if($request->emergency_contacts){
            foreach ($request->emergency_contacts as $emergency_contact) {
                if($emergency_contact['name'] && $emergency_contact['phone']){
                    auth()->user()->emergency_contacts()->create($emergency_contact);
                }
            }
        }
        return redirect()->route('home')->with('success', 'Profile Updated');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
    /**
     * validate rules
     */
    public function validate_rules($request)
    {
        return $this->validate($request, [
            // 'personal_email' => 'required',
            // 'mobile_number' => 'required',
            // 'emergency_number' => 'required',
            // 'address' => 'required',
            'photo' => 'required|dimensions:min_width=100,min_height=100|mimes:png,jpeg,jpg,gif'
        ]);
    }
}
