<?php

namespace App\Http\Controllers\Employee;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Employee;

class EmployeeHierarchyController extends Controller
{
	protected $employee;

	public function __construct(Employee $employee)
	{
		$this->employee = $employee;
	}
	/**
	 * Company Hierarchy list
	 */
	public function index()
	{
		$employees = $this->employee->whereHas('employees')->get();
		$title = 'Employees Hierarchy';
		return view('employee.employee_hierarchy.index', compact('employees', 'title'));
	}
}
