<?php

namespace App\Http\Controllers\Employee\ReportingEmployee\Attendance;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\EmployeeAttendanceDiscrepancy;
use App\Employee;

class DiscrepancyController extends Controller
{
    /**
     * @var EmployeeAttendanceDiscrepancy
     */
    private $discrepancy;
    /**
     * @var Employee
     */
    private $employee;
    /**
     * Constructor
     * @var Employee $employee
     */
    public function __construct(EmployeeAttendanceDiscrepancy $discrepancy, Employee $employee)
    {
        $this->discrepancy = $discrepancy;
        $this->employee = $employee;
        $this->middleware('verify_employee_manager');
    }
    /**
     * view path
     */
    private function view($filename='index', $data=[])
    {
        return view("employee.reporting_employees.attendance.discrepancy.$filename", $data);
    }
    /**
     * employee discrepancies
     */
    private function employee_discrepancies()
    {
        return $this->discrepancy->whereIn('employee_id', auth()->user()->function());
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $employees_list = $this->employee->active();
        if(auth()->user()->role != 'admin'){
            $employees_list = $employees_list->restrictManager();
        }
        $employees_list = $employees_list->pluck('full_name','id')->toArray();
        $discrepancies = $this->discrepancy->restrictManager()->search()->paginate(30);
        $title = 'Employees Attendance Discrepancies';
        return $this->view('index', compact('title', 'discrepancies', 'employees_list'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $discrepancy = $this->discrepancy->restrictManager()->find($id);
        if($discrepancy){
            $title = 'View Discrepancy';
            return $this->view('show', compact('title', 'discrepancy'));
        } else {
            return redirect()->route('portal.reporting_employee.discrepancy.index')->with('error', 'Something went wrong');
        }
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
