<?php

namespace App\Http\Controllers\Employee;

use App\Employee;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class EmployeeController extends Controller
{
    /**
     * @var Employee
     */
    private $employee;

    /**
     * EmployeeController constructor.
     * @param Employee $employee
     */
    public function __construct(Employee $employee)
    {
        $this->employee = $employee;
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        try {
            $employee = $this->employee->with(['employee_status', 'employee_setting', 'employee_shifts', 'employee_salaries', 'employee_relation', 'employee_designation', 'salary_slips'])->findOrFail(auth()->id());
            $title = 'Employee Detail - '.$employee->full_name;
            return view('employee.profile.dashboard', compact('title', 'employee'));
        } catch (\Exception $e) {
            return redirect()->to('/home')->with('error', $e->getMessage());
        }
    }
    
      public function info()
    {
        try {
            $note = auth()->user()->notes()->first();
            $employee = $this->employee->with(['employee_status', 'employee_setting', 'employee_shifts', 'employee_salaries', 'employee_relation', 'employee_designation', 'salary_slips'])->findOrFail(auth()->id());
            $title = 'Employee Detail - '.$employee->full_name;
            return view('employee.profile.info', compact('title', 'employee', 'note'));
        } catch (\Exception $e) {
            return redirect()->route('home')->with('error', $e->getMessage());
        }
    }
    
    public function notes()
    {
        try {
            $note = auth()->user()->notes()->first();
            $employee = $this->employee->with(['employee_status', 'employee_setting', 'employee_shifts', 'employee_salaries', 'employee_relation', 'employee_designation', 'salary_slips'])->findOrFail(auth()->id());
            $title = 'Employee Detail - '.$employee->full_name;
            return view('employee.profile.notes', compact('title', 'employee', 'note'));
        } catch (\Exception $e) {
            return redirect()->route('home')->with('error', $e->getMessage());
        }
    }
    
    /**
     * Display salary history
     *
     * @return \Illuminate\Http\Response
     */
    public function salary()
    {
        try {
            $employee = $this->employee->with(['employee_status', 'employee_setting', 'employee_shifts', 'employee_salaries', 'employee_relation', 'employee_designation', 'salary_slips'])->findOrFail(auth()->id());
            $title = 'Employee Salary History - '.$employee->full_name;
            return view('employee.salary', compact('title', 'employee'));

        } catch (\Exception $e) {
            return redirect()->to('/home')->with('error', $e->getMessage());
        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        try {

            if(request('type') == 'password'){
                $title = 'Change Password';
            }

            return view('employee.edit', compact('title'));

        } catch (\Exception $e) {
            return redirect()->back()->with('error', $e->getMessage());
        }
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        try {
            $user = $this->employee->findOrFail(auth()->id());
            if(request()->has('password')){
                request()->merge(['password' => bcrypt(request('password'))]);
                $user->update(request()->except('_token','c_password'));
                return redirect()->to('/home')->with('success', 'Password Update Successfully!');
            }
        } catch (\Exception $e) {
            return redirect()->back()->with('error', $e->getMessage());
        }
    }
    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function updatePassword(Request $request, $id)
    {
        try {
            $user = $this->employee->findOrFail(auth()->id());
            if(request()->has('password')){
                request()->merge(['password' => bcrypt(request('password'))]);
                $user->update(request()->except('_token','c_password'));
                return redirect()->to('/home')->with('success', 'Password Update Successfully!');
            }
        } catch (\Exception $e) {
            return redirect()->back()->with('error', $e->getMessage());
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
