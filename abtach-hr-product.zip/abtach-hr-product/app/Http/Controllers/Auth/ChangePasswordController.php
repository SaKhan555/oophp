<?php

namespace App\Http\Controllers\Auth;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Employee;
use Illuminate\Support\Facades\Mail;
use App\Mail\EmployeeCredentialsEmail;

class ChangePasswordController extends Controller
{
    /**
     * Show change password form
     */
    public function showForm($employee_id)
    {
    	return view('auth.passwords.change', compact('employee_id'));
    }
    /**
     * submit change password form
     */
    public function save($employee_id, Request $request)
    {
    	$this->validate_rules($request);
    	$employee = Employee::find($employee_id);
    	$data = [
    		'password' => bcrypt($request->password)
    	];
        $employee->update($data);
    	Mail::to($employee->email)->send(new EmployeeCredentialsEmail($employee, $request->password));
    	return redirect('/login')->with('success', 'Password updated');
    }
    /**
     * validate rules
     */
    public function validate_rules(Request $request)
    {
    	return $this->validate($request,[
    		'password' => 'required|confirmed|min:4',
    		'password_confirmation' => 'required'
    	]);
    }
}
