<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Employee;
use App\EmployeeFinalSettlement;
use App\EmployeeFinalSettlementStatus;
use Maatwebsite\Excel\Facades\Excel;

class EmployeeFinalSettlementController extends Controller
{
    /**
     * @var Employee
     */
    private $employee;
    /**
     * @var EmployeeFinalSettlement
     */
    private $final_settlement;
    /**
     * @var EmployeeFinalSettlement
     */
    private $final_settlement_status;
    /**
     * Constructor
     * @var Employee $employee
     */
    public function __construct(Employee $employee, EmployeeFinalSettlement $final_settlement,EmployeeFinalSettlementStatus $final_settlement_status)
    {
        $this->employee = $employee;
        $this->final_settlement = $final_settlement;
        $this->final_settlement_status = $final_settlement_status;
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $final_settlements = $this->final_settlement->search();
        if(request('export')){
            $final_settlements = $final_settlements->get();
            Excel::create('abtach-final-settlements-report', function($excel) use($final_settlements){
                    $excel->sheet('Report', function($sheet) use($final_settlements){
                         $sheet->loadView('admin.employee_final_settlement.partials.export_table', array('final_settlements' => $final_settlements));
                        });
                })->export('xls');
        }
        $statuses = $this->final_settlement_status->pluck('name', 'id')->toArray();
        $final_settlements = $final_settlements->paginate(30);
        return view('admin.employee_final_settlement.index', compact('final_settlements', 'statuses'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request, $employee_id)
    {
        $data = [
            'employee_id' => $employee_id,
            'date' => formatDate($request->value, 'Y-m-d'), 
        ];
        $this->final_settlement->create($data);
        return response()->json(['status' => true]);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $final_settlement = $this->final_settlement->find($id);
        if($final_settlement){
            $column = $request->name;
            $value = ($column == 'date') ? formatDate($request->value, 'Y-m-d') : $request->value; 
            $final_settlement->update([
                $column => $value
            ]);
            return response()->json(['status' => true]);
        } else {
            return response()->json(['status' => false]);
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
