<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\VehicleMeterReading;
use App\CompanyVehicle;

class VehicleMeterReadingController extends Controller
{
    /**
     * @var VehicleMeterReading
     */
    private $meter_reading;
    /**
     * @var CompanyVehicle
     */
    private $vehicle;
    /**
     * Constructor
     * @var Employee $employee
     */
    public function __construct(VehicleMeterReading $meter_reading, CompanyVehicle $vehicle)
    {
        $this->meter_reading = $meter_reading;
        $this->vehicle = $vehicle;
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $vehicles = $this->vehicle->search()->paginate(20);
        $title = 'Vehicles - Meter Readings';
        return view('admin.vehicle_meter_reading.index', compact('title','vehicles'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request, $vehicle_id)
    {
        $this->validate($request, [
            'date' => 'required',
            'reading' => 'required'
        ]);
        $data = [
            'vehicle_id' => $vehicle_id,
            'date' => carbon()->createFromFormat('d/m/Y', $request->date)->format('Y-m-d'),
            'reading' => $request->reading,
            'maintenance_due_on' => $request->maintenance_due_on
        ];
        $this->meter_reading->create($data);
        return redirect()->back()->with('success', 'Meter reading created.');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($vehicle_id)
    {
        $vehicle = $this->vehicle->find($vehicle_id);
        if($vehicle) {
            $title = $vehicle->car_model.' - '.$vehicle->car_registration_no.' - Meter Readings';
            return view('admin.vehicle_meter_reading.show', compact('title','vehicle'));
        } else {
            return redirect()->back()->with('error' ,'Vehicle not found');
        }
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $meter_reading = $this->meter_reading->find($id);
        if($meter_reading){
            $name = $request->name;
            $value = $request->value;
            $meter_reading->update([$name => $value]);
            return response()->json(['status' => true]);
        }
         return response()->json(['status' => false]);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $this->meter_reading->find($id)->delete();
        if (request()->ajax()) {
            return response()->json(['success' => true]);
        }
        return redirect()->back()->withSuccess('Deleted Successfully');
    }
}
