<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Employee;
use App\EmployeeAttendance;
use Maatwebsite\Excel\Facades\Excel;

class EmployeeAttendanceReportController extends Controller
{
    /**
     * @var Employee
     */
    private $employee;
    /**
     * @var EmployeeAttendance
     */
    private $employee_attendance;
    /**
     * EmployeeController constructor.
     * @param $employee Employee
     * @param $employee_attendance EmployeeAttendance
    */
    public function __construct(Employee $employee, EmployeeAttendance $employee_attendance)
    {
        $this->employee = $employee;
        $this->employee_attendance = $employee_attendance;
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index($employee_id)
    {
        $employee = $this->employee->find($employee_id);
        $title = $employee->full_name.' - Attendance Report';
        $month = (request('month')) ? request('month') : carbon()->now()->format('m-Y');
        $employee_checkinouts = period_interval(carbon()->parse('26-'.$month)->subMonths(1));
        if(request('export_excel')) {
            $this->export_excel($employee, $employee_checkinouts, $month);
        }
        if(request('all_export_excel')) {
            $this->export_excel($employee, $employee->checkInOuts(), $month);
        }
        return view('admin.employee_attendance_report.index', compact('employee_checkinouts','title','employee'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
    // export excel
    public function export_excel($employee, $employee_attendance_data)
    {
        if($employee_attendance_data) {
            return Excel::create($employee->full_name.'-attendance-report', function($excel) use ($employee, $employee_attendance_data) {
                foreach($employee_attendance_data as $month_year => $days){
                    $excel->sheet($month_year, function($sheet) use ($employee, $days)
                    {
                        // style headers
                        $sheet->cells('A1:F1', function($cells) {
                            $cells->setBackground('#000');
                            $cells->setFontColor('#ffffff');
                            $cells->setFontWeight('bold');
                        });
                        $sheet->cells('A3:F3', function($cells) {
                            $cells->setBackground('#000');
                            $cells->setFontColor('#ffffff');
                            $cells->setFontWeight('bold');
                        });
                        // set employee details headers
                        $sheet->setCellValue('A1', 'Employee Name:');
                        $sheet->setCellValue('B1', $employee->full_name);
                        $sheet->setCellValue('C1', 'Employee Code:');
                        $sheet->setCellValue('D1', $employee->employee_id);
                        $sheet->setCellValue('E1', 'Employee Manager:');
                        $sheet->setCellValue('F1', ($employee->manager_employee) ? $employee->manager_employee->full_name : '');
                        // set headers
                        $sheet->setCellValue('A3', 'Date');
                        $sheet->setCellValue('B3', 'Shift Time');
                        $sheet->setCellValue('C3', 'Check In');
                        $sheet->setCellValue('D3', 'Check Out');
                        $sheet->setCellValue('E3', 'Working Hours');
                        $sheet->setCellValue('F3', 'Late Hours');
                        if ($days) {
                            $i = 3;
                            foreach ($days as $day) {
                                $i= $i+1;
                                $sheet->cell('A'.$i, $day);  
                                if($employee->shift()) {
                                    $sheet->cell('B'.$i, $employee->shift_time($day)); 
                                } else {
                                    $sheet->cell('B'.$i, ''); 
                                }
                                $sheet->cell('C'.$i, $employee->check_in_for($day)); 
                                $sheet->cell('D'.$i, $employee->check_out_for($day)); 
                                $sheet->cell('E'.$i, $employee->working_hours_for($day));
                                $sheet->cell('F'.$i, $employee->late_hours_for($day)); 
                            }
                        }
                        // $sheet->fromArray($excel_data);
                    });
                }
            })->download('xls');
        }
    }
}
