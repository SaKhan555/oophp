<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Maatwebsite\Excel\Facades\Excel;
use App\Employee;

class SalaryDeductionReportController extends Controller
{
	/**
     * @var Employee
     */
    private $employee;
    /**
     * ExpenseController constructor.
     * @param EmployeeLeaveApplication $employee_leave_application
     */
    public function __construct(Employee $employee)
    {
        $this->employee = $employee;
    }
    /**
     * list report
     */
    public function index()
    {
        $month = (request('month')) 
                    ? carbon()->createFromFormat('m-Y', request('month')) 
                    : carbon()->now();
        $salary_slips = \App\EmployeeSalarySlip::whereMonth('month', $month->format('m'))->whereYear('month', $month->format('Y'));
        if(request('export')){
            $salary_slips = $salary_slips->get();
            Excel::create('Salary-Deduction-report', function($excel) use($month, $salary_slips){
                    $excel->sheet('Month Report', function($sheet) use($month, $salary_slips){
                         $sheet->loadView('admin.salary_deduction_report.partials.newtable', array('month' => $month,'salary_slips' => $salary_slips));
                        });
                })->export('xls');
        }
        if(request('s')){
            $salary_slips = $salary_slips->whereHas('employee', function($q){
                return $q->search();
            });
        }
        $salary_slips = $salary_slips->paginate(20);
        $title = 'Salary Deduction Report';
        return view('admin.salary_deduction_report.index', compact('title', 'salary_slips', 'month'));
    }

    /**
     * show the specific employee month report
     */
    public function show($employee_id)
    {
        return response()->json(['status' => true]);
    }
}
