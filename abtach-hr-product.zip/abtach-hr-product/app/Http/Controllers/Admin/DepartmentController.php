<?php

namespace App\Http\Controllers\Admin;

use App\EmployeeDepartment;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class DepartmentController extends Controller
{
    /**
     * @var EmployeeDepartment
     */
    private $department;


    /**
     * DepartmentController constructor.
     * @param Department $department
     */
    public function __construct(EmployeeDepartment $department)
    {
        $this->department = $department;
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $title = 'Department';
        $departments = $this->department->where('status', '1');

        if(request('type') == 'trashed'){
            $departments = $departments->onlyTrashed();
        }
        $departments = $departments->orderBy('id', 'ASC')->paginate(20);
        return view('admin.department.index',compact('title', 'departments'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $title = 'Add New Department';
        return view('admin.department.create', compact('title'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $departmentData = [
            'name' => request('name'),
        ];
        $this->department->create($departmentData);
        return redirect()->route('admin.departments.index')->with('success', 'Department Created Successfully!');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Letter  $letter
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $department = $this->department->where('status', '1')->orderBy('id', 'ASC')->get();
        return view('admin.department.show',compact('id','department'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Letter  $letter
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $department =  $this->department->find($id);
        $title = 'Edit '.ucwords($department->name);
        return view('admin.department.edit',compact('department' ,'title'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Letter  $letter
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $data = [
            'name' => request('name')
        ];
        $department =  $this->department->find($id);
        $department->update($data);
        return redirect()->route('admin.departments.index')->with('success', 'Department Template Updated');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Letter  $letter
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        if (request('type') == 'restore') {
            $this->department->onlyTrashed()->find($id)->restore();
        } elseif (request('type') == 'forceDelete') {
            $this->department->onlyTrashed()->find($id)->forceDelete();
        } else{
            $this->department->find($id)->delete();
        }
     return redirect()->route('admin.departments.index')->with('success', 'Department Template Deleted');
    }
}
