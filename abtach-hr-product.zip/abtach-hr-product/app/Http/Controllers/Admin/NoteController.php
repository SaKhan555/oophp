<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Employee;
use App\EmployeeDepartment;
use App\Note;
use App\EmployeeNote;
use App\Mail\NoteEmail;
use Illuminate\Support\Facades\Mail;

class NoteController extends Controller
{
    /**
     * @var Employee
     */
    private $employee;
    /**
     * @var Note
     */
    private $note;
    /**
     * @var EmployeeNote
     */
    private $employee_note;
    /**
     * Constructor
     * @var Employee $employee
     */
    public function __construct(Employee $employee, Note $note, EmployeeNote $employee_note)
    {
        $this->employee = $employee;
        $this->note = $note;
        $this->employee_note = $employee_note;
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $notes = $this->note->latest()->paginate(20);
        $title = 'Employee Notes';
        return view('admin.employee_note.index', compact('title', 'notes'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $title = 'Create a note';
        $employees = $this->employee->active()->pluck('full_name', 'id')->toArray();
        $departments = EmployeeDepartment::pluck('name', 'id')->toArray();
        return view('admin.employee_note.create', compact('title', 'employees', 'departments'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate_rules($request);
        $employees = [];
        $department_employees = [];
        if(!$request->send_to_all) {
            if($request->employee_ids){
                $employees = $this->employee->active()->whereIn('id', $request->employee_ids)->pluck('email','id')->toArray();
            }
            if($request->department_ids){
                $department_employees = $this->employee->active()->whereIn('department_id', $request->department_ids)
                                                        ->pluck('email','id')
                                                        ->toArray();
            }
        } else {
            $employees = $this->employee->active()->pluck('email','id')->toArray();
        }
        $employee_ids = array_unique(
            array_merge(array_keys($employees), array_keys($department_employees))
        );
        // create note
        $note = $this->note->create([
            'user_id' => auth()->guard('admin_web')->id(),
            'title' => $request->title,
            'content' => htmlspecialchars($request->content),
            'employee_ids' => json_encode($employee_ids),
            'department_ids' => json_encode($request->department_ids),
            'email_enabled' => 1
        ]);
        // redirect
        return redirect()->route('admin.note.index')->with('success', 'Note added successfuly!');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $note = $this->note->find($id);
        if($note){
            $title = 'Note - '.$note->title;
            return view('admin.employee_note.show', compact('title', 'note'));
        } else {
            return redirect()->back()->with('error', 'Not Found!');
        }
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $note = $this->note->find($id);
        if($note){
            $note->employees()->delete();
            $note->delete();
            if (request()->ajax()) {
                return response()->json(['success' => true]);
            }
        } else {
            return response()->json(['success' => false]);
        }
    }
    /**
     * validate rules
     */
    public function validate_rules($request, $rules = [])
    {
        return $this->validate($request, [
            'title' => 'required',
            'content' => 'required',
            'employee_ids' => 'required_withoutall:department_ids,send_to_all',
            'department_ids' => 'required_withoutall:employee_ids,send_to_all',
            'send_to_all' => 'required_withoutall:department_ids,employee_ids'
        ]);
    }
}
