<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Employee;
use App\EmployeeDepartmentAssign;
use Illuminate\Support\Facades\Mail;
use App\Mail\NotifyEmployeeDepartment;

class EmployeeDepartmentController extends Controller
{
    /**
     * @var Employee
     */
    private $employee;
    /**
     * @var EmployeeDepartmentAssign
     */
    private $employee_department_assign;
    /**
     * Constructor
     * @var Employee $employee
     */
    public function __construct(Employee $employee, EmployeeDepartmentAssign $employee_department_assign)
    {
        $this->employee = $employee;
        $this->employee_department_assign = $employee_department_assign;
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index($employee_id)
    {
        $employee = $this->employee->find($employee_id);
        if($employee){
            $title = 'Assign Department - '.$employee->full_name;
            $employee_departments = $employee->departments()->orderBy('id','desc')->get();
            return view('admin.employee.department',compact('title','employee','employee_departments'));
        } else {
            return back();
        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store($employee_id, Request $request)
    {
        $employee = $this->employee->find($employee_id);
        if($employee){
            $previous_employee_department = $this->employee_department_assign->first();
            if(!$previous_employee_department) {
                // create old assignment if not exist
                $old_assignment_data = [
                    'department_id' => $employee->department_id,
                    'employee_id' => $employee_id,
                    'created_at' => $employee->created_at
                ];
                $this->employee_department_assign->create($old_assignment_data);
            }
            // create new assignment
            $effective_date = \Carbon\Carbon::createFromFormat('d/m/Y',request('created_at'))->toDateTimeString();
            $new_assignment_data = [
                'department_id' => $request->department_id,
                'employee_id' => $employee_id,
                'created_at' => $effective_date
            ];
            $employee_department = $this->employee_department_assign->create($new_assignment_data);
            // update employee
            $employee->department_id = $employee_department->department_id;
            $employee->save();
            // notify employee if requested
            if(request('notify_employee') && $employee->email){
                Mail::to($employee->email)->cc(config('general.emails.cc_default'))->send(new NotifyEmployeeDepartment($employee, $employee_department));
            }

            return redirect()->back()->with('success', 'Department Assigned Successfully!');
        } else {
            return back();
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
