<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\InsurancePlan;

class InsurancePlanController extends Controller
{
    protected $insurance_plan;
    /**
     * constructor
     */
    public function __construct(InsurancePlan $insurance_plan)
    {
        $this->insurance_plan = $insurance_plan;
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $title = 'Insurance Plans';
        $insurance_plans = $this->insurance_plan->paginate(20);
        return view('admin.insurance_plan.index', compact('title', 'insurance_plans'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $title = 'Create Insurance Plan';
        return view('admin.insurance_plan.create', compact('title'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate_rules($request);
        $data = [
            'name' => $request->name
        ];
        $this->insurance_plan->create($data);
        return redirect()->route('admin.insurance_plan.index')->with('success', 'Insurance Plan Added');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $insurance_plan = $this->insurance_plan->find($id);
        $title = "Edit Insurance Plan - {$insurance_plan->name}";
        return view('admin.insurance_plan.edit', compact('title', 'insurance_plan'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $this->validate_rules($request, $id);
        $insurance_plan = $this->insurance_plan->find($id);
        $data = [
            'name' => $request->name
        ];
        $insurance_plan->update($data);
        return redirect()->route('admin.insurance_plan.index')->with('success', 'Insurance Plan Updated');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
    /**
     * validate rules
     */
    private function validate_rules($request, $id=null)
    {
        return $this->validate($request, [
            'name' => 'required|unique:insurance_plans,name' . ($id ? ",$id" : ''),
        ]);
    }
}
