<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class ProfileController extends Controller
{
    /**
     * Show the form to update profile.
     *
     * @return \Illuminate\Http\Response
     */
    public function showForm()
    {
        $title = 'Edit Profile';
        $user = auth()->guard('admin_web')->user();
        return view('admin.profile.index', compact('title', 'user'));
    }

    /**
     * Submit the form to update profile
     *
     * @return \Illuminate\Http\Response
     */
    public function save(Request $request)
    {
        $this->validate($request, [
            'name' => 'required',
            'picture' => 'dimensions:min_width=100,min_height=100|mimes:png,jpeg,jpg,gif'
        ]);
        $user = auth()->guard('admin_web')->user();
        $user->update([
            'name' => $request->name,
            'recovery_email' => $request->recovery_email
        ]);
        $file_name = $user->picture;
        if($request->hasFile('picture')){
            $old_file_path = public_path().'/uploads/user/avatars/'.$file_name;
            if($file_name && file_exists($old_file_path)){
                unlink($old_file_path);
            }
            $file = $request->file('picture');
            $file_name = $user->id.'.'.$file->getClientOriginalExtension();
            $file->move('uploads/user/avatars' , $file_name);  
            $user->update([
                'picture' => $file_name
            ]);
        }
        return redirect()->back()->with('success', 'Profile Updated!');
    }
}
