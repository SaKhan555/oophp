<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\EmployeeTicket;
use App\EmployeeTicketCategory;
use App\EmployeeTicketStatus;
use Maatwebsite\Excel\Facades\Excel;

class EmployeeTicketController extends Controller
{
    /**
     * @var EmployeeTicketCategory
     */
    private $ticket_category;
    /**
     * @var EmployeeTicket
     */
    private $ticket;
    /**
     * @var EmployeeTicketStatus
     */
    private $ticket_status;
    /**
     * Constructor
     * @var Employee $employee
     */
    public function __construct(EmployeeTicketCategory $ticket_category, EmployeeTicket $ticket, EmployeeTicketStatus $ticket_status)
    {
        $this->ticket_category = $ticket_category;
        $this->ticket = $ticket;
        $this->ticket_status = $ticket_status;
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $tickets = $this->ticket->search()->latest();
        // export if requested
        if(request('export')){
            $tickets = $tickets->get();
            Excel::create('abtach-final-settlements-report', function($excel) use($tickets){
                    $excel->sheet('Report', function($sheet) use($tickets){
                         $sheet->loadView('admin.employee_tickets.partials.export_table', array('tickets' => $tickets));
                        });
                })->export('xls');
        } else {
            $title = 'Employee Tickets';
            $tickets = $tickets->paginate(20);
            $ticket_categories = $this->ticket_category->pluck('name', 'id')->toArray();
            $ticket_statuses = $this->ticket_status->pluck('name', 'id')->toArray();
            return view('admin.employee_tickets.index', compact('title','tickets','ticket_categories','ticket_statuses'));
        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $ticket = $this->ticket->find($id);
        $title = 'Ticket - '.$ticket->subject;
        return view('admin.employee_tickets.show', compact('title', 'ticket'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $ticket = $this->ticket->find($id);
        $title = 'Ticket - '.$ticket->subject;
        return view('admin.employee_tickets.edit', compact('title', 'ticket'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $ticket = $this->ticket->find($id);
        if($ticket){
            $name = $request->name;
            $value = $request->value;
            $data = [
                $name => $value
            ];
            $ticket->update($data);
            return json_encode(['status' => true]);
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
