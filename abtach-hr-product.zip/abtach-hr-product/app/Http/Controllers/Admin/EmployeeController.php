<?php
 
namespace App\Http\Controllers\Admin;

use App\CompanyVehicle;
use App\Employee;
use App\EmployeeDepartment;
use App\EmployeeSalary;
use App\EmployeeSetting;
use App\EmployeeShiftTiming;
use App\EmployeeStatus;
use App\EmployeeVehicle;
use App\EmployeeDesignation;
use App\EmployeeRelation;
use App\Letter;
use App\Unit;
use App\EmployeeLetter;
use Barryvdh\DomPDF\PDF;
use Illuminate\Http\Request;
use Maatwebsite\Excel\Facades\Excel;
use Carbon\Carbon;
use App\Http\Controllers\Controller;
use Riskihajar\Terbilang\Facades\Terbilang;
use Illuminate\Support\Facades\Mail;
use App\Mail\NotifyEmployeeShift;
use App\Mail\NotifyEmployeeOffered;
use App\Mail\NotifyEmployeePermenant;
use App\Mail\NotifyEmployeeConfirmed;
use App\Mail\NotifyEmployeeNoticePeriod;
use App\Mail\NotifyEmployeeSeparation;
use App\Mail\ForeignEmployeeAccountEmail;
use App\EmployeeDepartmentAssign;
use App\EmployeeManager;
use App\EmployeeFinalSettlement;
use App\Brand;
use App\InsurancePlan;
use App\Mail\NotifyEmployeeDepartment;
use App\Mail\NotifyEmployeeReporting;
use App\Mail\WelcomeEmployeeEmail;
use App\Mail\EmployeeSetPasswordEmail;
use Storage;

class EmployeeController extends Controller
{
    /**
     * @var Employee
     */
    private $employee;
    /**
     * @var EmployeeStatus
     */
    private $employeeStatus;
	  /**
     * @var EmployeeVehicle
     */
    private $employeeVehicle;
    /**
     * @var EmployeeSalary
     */
    private $employeeSalary;
	
	private $employeeRelation;
	private $employeeDesignation;
    /**
     * @var EmployeeSetting
     */
    private $employeeSetting;
    /**
     * @var EmployeeShiftTiming
     */
    private $employeeShiftTiming;
    /**
     * @var PDF
     */
    private $PDF;
    /**
     * @var letter
     */
    private $letter;
    /**
     * @var EmployeeDepartment
     */
    private $employeeDepartment;
    /**
     * @var CompanyVehicle
     */
    private $companyVehicle;

    /**
     * EmployeeController constructor.
     * @param letter $letter
     * @param PDF $PDF
     * @param Employee $employee
     * @param Unit $unit
     * @param EmployeeDepartment $employeeDepartment
     * @param EmployeeDesignation $employeeDesignation
     * @param EmployeeVehicle $employeeVehicle
     * @param EmployeeStatus $employeeStatus
     * @param EmployeeSalary $employeeSalary
     * @param EmployeeRelation $employeeRelation
     * @param EmployeeSetting $employeeSetting
     * @param EmployeeShiftTiming $employeeShiftTiming
     * @param CompanyVehicle $companyVehicle
     */
    public function __construct(letter $letter, PDF $PDF, Employee $employee, Unit $unit, EmployeeDepartment $employeeDepartment, EmployeeDesignation $employeeDesignation, EmployeeVehicle $employeeVehicle, EmployeeStatus $employeeStatus, EmployeeSalary $employeeSalary, EmployeeRelation $employeeRelation, EmployeeSetting $employeeSetting, EmployeeShiftTiming $employeeShiftTiming, CompanyVehicle $companyVehicle)
    {
        $this->employee = $employee;
        $this->employeeStatus = $employeeStatus;
        $this->employeeSalary = $employeeSalary;
		$this->employeeVehicle = $employeeVehicle;
		$this->employeeRelation = $employeeRelation;
		$this->employeeDesignation = $employeeDesignation;
        $this->employeeSetting = $employeeSetting;
        $this->employeeShiftTiming = $employeeShiftTiming;
        $this->PDF = $PDF;
        $this->letter = $letter;
		$this->unit = $unit;
        $this->employeeDepartment = $employeeDepartment;
        $this->companyVehicle = $companyVehicle;
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $title = request('current_status'). ' Employees';
		
	
        $employees = $this->employee->query();

   /*     $employeedata = $employees->get();
        foreach ($employeedata as $employee) {
            $department = $this->employeeDepartment->where('name', $employee->department)->first();
            if($department){
                $employee->update(['department_id'=>$department->id]);
            }
        }*/

        if(request('type') == 'export'){
			$employees = $employees->with(['employee_salaries', 'employee_shifts', 'employee_department', 'unit_employee', 'units_employee'])->search()->orderBy('id', 'ASC')->get();
			$count_increment = \DB::select("select count(*) as header from od0_employee_salaries group by employee_id order by count(*) desc limit 1");
			
			$totalIncrement = (isset($count_increment[0]->header)) ? $count_increment[0]->header : 5;
			$dataheader = [
                        'Employee Code',
                        'Full Name',
                        'Father Name',
                        'Designation',
                        'Department',
                        'Unit',
                        'Reporting Authority',
                        'Email',
                        'Phone',
                        'Mobile',
                        'NIC No.',
                        'NIC Expiry Date',
                        'Gender',
                        'Date Of Birth',
                        'Status',
						'Status End Date',
                        'Currency',
                        'Current Salary',
                        'Marital Status',
                        'Join Date',
                        'Separation Date',
						'Clearance Date',
                        'Shift Timing',
                        'Personal Email',
                        'Address',
                        'ID Card Issue',
						'ID Card Issue Date',
						'Insurance Card Issue',
						'Insurance Card Issue Date',
                        'Insurance Plan',
				];
			$dataheader_count = count($dataheader)-1;
			$increment_headers = [];
				for ($x = 1; $x <= $totalIncrement; $x++) {
				$increment_headers[$dataheader_count] = 'Increment Date '.$x;
				$dataheader_count++;
				$increment_headers[$dataheader_count] = 'Increment Amount '.$x;
				$dataheader_count++;
			}
			$headers = array_merge($dataheader, $increment_headers);
			
		
            Excel::create('Employee -- '.date('d-m-Y'), function($excel) use($employees, $headers) {

                $excel->sheet('Employee --'.date('d-m-Y'), function($sheet) use($employees, $headers) {
					
					
                    $sheet->row(1, $headers);
                    $sheet->row(1, function($row) {
                        $row->setBackground('#000');
                        $row->setFontColor('#ffffff');
                        $row->setFontWeight('bold');
                    });

                    $i = 2; 
                    foreach ($employees as $employee) {
						$employee_status = $this->employeeStatus
											->where('employee_id', $employee->id)
											->where('status', $employee->current_status)
											->first();
					
						$unit_names = (isset($employee->units_employee)) ? collect($employee->units_employee)->pluck('name')->toArray() : [];
						$unit_names = array_unique($unit_names);
						$unit_name = (isset($employee->unit_employee->name)) ? $employee->unit_employee->name : '';						
						$units_show = ($unit_names && is_array($unit_names) && (count($unit_names) > 0)) ? implode(', ', $unit_names) : $unit_name;

                        $s_start = (isset($employee->employee_shifts[0]->check_in)) ? $employee->employee_shifts[0]->check_in : '';
                        $e_start = (isset($employee->employee_shifts[0]->check_out)) ? $employee->employee_shifts[0]->check_out : '';

						$data_employee_excel = array(
                            $employee->employee_id,
                            $employee->full_name,
                            $employee->father_name,
                            $employee->designation,
                            (isset($employee->employee_department->name)) ? $employee->employee_department->name : $employee->department,
                            $units_show,
                            ($employee->manager_employee) ? $employee->manager_employee->full_name : '',
                            $employee->email,
                            $employee->phone_number,
                            $employee->mobile_number,
                            $employee->national_identity,
							$employee->date_of_expiry,
							//(!empty($employee->date_of_expiry) ? Carbon::parse($employee->date_of_expiry)->format('F, d Y') : ''),
                            ucwords($employee->sex),
                            (!empty($employee->birth_date) ? Carbon::parse($employee->birth_date)->format('F, d Y') : ''),
                            $employee->current_status,
							(!empty($employee_status->end_at) ? Carbon::parse($employee_status->end_at)->format('F, d Y') : ''),
                            $employee->currency,
                            number_format($employee->salary),
                            ucwords($employee->marital_status),
                            (!empty($employee->join_date) ? Carbon::parse($employee->join_date)->format('F, d Y') : ''),
							(!empty($employee->status_at) ? Carbon::parse($employee->status_at)->format('F, d Y') : ''),
							(!empty($employee->clearance_date) ? Carbon::parse($employee->clearance_date)->format('F, d Y') : ''),
                            $s_start . ' - ' . $e_start,
                            $employee->other_email,
                            $employee->address,
                            $employee->id_card_issue,
							(!empty($employee['insurance_card_issue_date']) ? Carbon::parse($employee->id_card_issue_date)->format('F, d Y') : ''),
                            $employee->insurance_card_issue,
							(!empty($employee->insurance_card_issue_date) ? Carbon::parse($employee->insurance_card_issue_date)->format('F, d Y'): ''),
                            $employee->insurance_plan,
                        );
						if($employee->employee_salaries){
							foreach($employee->employee_salaries as $salary){
								$data_employee_excel[] = $salary->created_at->format('F, d Y');	
								$data_employee_excel[] = $salary->amount;
							}
						}
						
                        $sheet->row($i, $data_employee_excel);
						$data_employee_excel = null;
                        $i++;
                    }
                });
            })->export('xls');
					
        } elseif(request('type') == 'export_relation'){
			$employees = $employees->with('employee_relation')->where('current_status', 'Permanent')->orderBy('employee_id', 'ASC')->get();
			//return $employees;
			Excel::create('Employee -- '.date('d-m-Y'), function($excel) use($employees) {
						$excel->sheet('Employee --'.date('d-m-Y'), function($sheet) use($employees) {

							$sheet->row(1, [
								'Employee Code',
								'Employee Name',
								'Gender',
								'Designation',
								'Department',
								'Date Of Birth',
								'CNIC',
								'Employee Status',
								'Relation',
							]);
							$sheet->row(1, function($row) {
								$row->setBackground('#000');
								$row->setFontColor('#ffffff');
								$row->setFontWeight('bold');
							});

							$i = 2;
							foreach ($employees as $employee) {

								$sheet->row($i, array(
									$employee->employee_id,
									$employee->full_name,
									ucwords($employee->sex),
									$employee->designation,
									$employee->department,
									Carbon::parse($employee->birth_date)->format('d-m-Y'),
									$employee->national_identity,
									$employee->current_status,
									ucwords($employee->marital_status),
								));

								$sheet->row($i, function($row) {
								$row->setFontWeight('bold');
							});
									$i++;


								if($employee->marital_status == 'married' && (count($employee->employee_relation) > 0)){
										foreach ($employee->employee_relation as $relation) {
											if($relation){

													$sheet->row($i, array(
														'',
														$relation->full_name,
														'',
														'',
														'',
														Carbon::parse($relation->date_of_birth)->format('d-m-Y'),
														'',
														'',
														$relation->relation,
													));

											}
											$i++;
										}
									}
							}


						});
					})->export('xls');
		}


        $employees = $employees->with([
            'employee_status', 'employee_setting'
        ])->search()->orderBy('employee_id', 'ASC');
		
		if(request('show') == 'deleted'){
			$title = 'Deleted Employees';
			 $employees = $employees->onlyTrashed();
		}
		$employees = $employees->paginate((request('per_page')) ? request('per_page') : 30 );
		$departments = $this->employeeDepartment->pluck('name', 'id')->toArray();
		$units = $this->unit->pluck('name', 'id')->toArray();
        return view('admin.employee.index',  compact('title', 'employees', 'departments', 'units'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $title = 'Add New Employee';
        $managers = $this->employee->active()->orderBy('employee_id', 'ASC')->pluck('full_name', 'id')->toArray();
        // $managers = $this->employee->where('is_manager', 1)->orderBy('employee_id', 'ASC')->pluck('full_name', 'id')->toArray();
		$units = \App\Unit::where('status', 1)->orWhere('name', 'Neutral')->pluck('name', 'id')->toArray();
		$brands = Brand::pluck('name', 'id');
		$insurance_plans = InsurancePlan::pluck('name', 'id');
		$latest_employee_id = ($this->employee->orderBy('id', 'desc')->withTrashed()->first()->id + 1);
		$new_employee_code = str_pad($latest_employee_id, 7, "0", STR_PAD_LEFT);
        return view('admin.employee.create', compact('title', 'managers', 'units', 'brands', 'new_employee_code', 'insurance_plans'));
		
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
		if(request('employee_id')){
			 $this->validate($request, $this->employee->rules(null,[
			 	'other_email'=>'unique:employees',
			 	'email'=>'unique:employees',
			 ]));
			$employee = $this->employee->where('employee_id', request('employee_id'))->first();
			if($employee){
				return redirect()->back()->with('error', 'Employee Code Already Taken!');
			}
		}
       
		\DB::beginTransaction();

		try{
			$join_date = Carbon::createFromFormat('d/m/Y', request('date_of_join'))->toDateTimeString();
			$birth_date = (request('birth_date')) ? Carbon::createFromFormat('d/m/Y', request('birth_date'))->format('Y-m-d') : null ;
			request()->merge([
				'join_date' => $join_date,
				'birth_date' => $birth_date,
				'password' => bcrypt(request('password'))
			]);
			$employee_created = $this->employee->create($request->except('_token', 'type', 'employee', 'unit_ids', 'check_in', 'end_at', 'check_out', 'current_status', 'status_date', 'date_of_join', 'brand_id', 'emergency_contact', 'void_cheque', 'leave_days', 'probation_period'));
			// create leaves
			$employee_created->leave_days()->create(array_merge($request->leave_days, [
				'leaves_year' => date('Y'),
			]));
			// upload void cheque if requested
			if($request->hasFile('void_cheque')){
				$cheque_filename = uniqid(time()).'.'.$request->void_cheque->getClientOriginalExtension();
				$request->void_cheque->storeAs('void_cheques', $cheque_filename);
				$employee_created->update([
					'bank_details' => array_merge($request->bank_details, ['void_cheque' => $cheque_filename])
				]);
			}
			// create emergency contacts
			if($request->emergency_contact){
				foreach ($request->emergency_contact as $emergency_contact) {
					// if($emergency_contact['name'] && $emergency_contact['phone']){
						$employee_created->emergency_contacts()->create($emergency_contact);
					// }
				}
			}
			
			$id = $employee_created->id;
			
			// save employee department
			if($id && request('department_id')){
				EmployeeDepartmentAssign::create([
					'employee_id' => $id,
					'department_id' => request('department_id')
				]);
			}
			// save employee manager
			if($id && request('manger_id')){
				EmployeeManager::create([
					'employee_id' => $id,
					'manager_id' => request('manager_id')
				]);
			}
			
            if(request('password')) {
                $request->merge(['password'=>bcrypt(request('password'))]);
            }
			$units = (request('unit_id')) ? [request('unit_id')] : [];

			if($units) {
				$units_array = (request('unit_ids')) ? request('unit_ids') : [];
				$other_units = array_merge($units_array, $units);
				$units_insert = $employee_created->units_employee()->sync($other_units);
			}

            if(request('current_status')) {
				$status = request('current_status');
				$checkStatus = $this->employeeStatus->where('employee_id', $id)->where('status', $status)->first();
				if (!$checkStatus) {
					$updated1 = $employee_created->update(['current_status' => $status]);
					// $status_date = Carbon::createFromFormat('d/m/Y', request('status_date'))->toDateTimeString();
					if(($status == 'Permanent') && (request('probation_period'))){
						$end_date = carbon()->parse($join_date)->addMonths(request('probation_period'))->subDay()->toDateTimeString();
						$status_date = carbon()->parse($end_date)->addDay();
						$this->employeeStatus->create([
							'employee_id' => $id,
							'status' => 'Probation',
							'comments' => '',
							'status_at' => $join_date,
	                        'end_at' => $end_date,
	                    ]);
					}
                    // $end_date = ($request->get('end_at')) ? Carbon::createFromFormat('d/m/Y', request('end_at'))->toDateTimeString() : null;

                    $this->employeeStatus->create([
						'employee_id' => $id,
						'status' => $status,
						'comments' => request('comments'),
						'status_at' => (!empty($status_date)) ? $status_date : $join_date,
                        'end_at' => null,
                    ]);
				}
			} 
			if(request('salary')){
				$amount = request('salary');
				$checkSalary = $this->employeeSalary->where('employee_id', $id)->where('amount', $amount)->first();
				if (!$checkSalary) {
					$updated2 = $employee_created->update(['salary' => $amount]);
					// $updated_date = Carbon::createFromFormat('d/m/Y', request('join_date'))->toDateTimeString();
					$this->employeeSalary->create([
						'employee_id' => $id,
						'amount' => $amount,
						'comments' => request('comments'),
					]);
				}
			}
			if(request('family'))
			{
				$this->employeeRelation->where('employee_id', $id)->delete();
				
				foreach (request('employee') as $key => $member){
					return $member;
					if($member){
						$dobe = (isset($member['dob'])) ? Carbon::createFromFormat('d/m/Y', $member['dob'])->toDateTimeString() : null;
						$family = [
							'employee_id' => $id,
							'full_name' =>  (isset($member['family_member'])) ? $member['family_member'] : null,
							'relation' =>  (isset($member['relation'])) ? $member['relation'] : null,
							'date_of_birth' =>  ($dobe) ? $dobe : null,
						];

						$this->employeeRelation->create($family);
					}
				}
			}

			$created_at_date = Carbon::now()->toDateTimeString();
			$this->employeeDesignation->create([
				'employee_id' => $id,
				'name' => request('designation'),
				'created_at' => $created_at_date,
			]);
         
			$check_in = ($request->get('check_in')) ? Carbon::parse($request->get('check_in'))->format('h:i A') : '8:00 AM';
			$check_out = ($request->get('check_out')) ? Carbon::parse($request->get('check_out'))->format('h:i A') : '5:00 PM';
				
            $setting = $this->employeeSetting->where('employee_id', $id)->first();
			$setting_data = [
                'employee_id' => $id,
                'total_work_hour' => config('app.working_hours'),
                'check_in' => $check_in,
                'check_out' => $check_out,
                'timezone' => config('app.timezone'),
            ];

			if(!$setting){
                $setting = $this->employeeSetting->create($setting_data);
                $setting = $this->employeeShiftTiming->create([
                    'check_in' => $check_in,
                    'employee_id' => $id,
                    'total_work_hour' => config('app.working_hours'),
                    'check_out' => $check_out,
                ]);

            } else {
                $setting->update($setting_data);
                $setting = $this->employeeShiftTiming->create([
                    'check_in' =>  $check_in,
                    'employee_id' => $id,
                    'total_work_hour' => config('app.working_hours'),
                    'check_out' => $check_out,
                ]);
            }


            \DB::commit();
            $emp = $employee_created;
            \Mail::to(request('email'))->send(new WelcomeEmployeeEmail($emp));
			return redirect()->route('admin.employee.index')->with('success', 'Employee Created Successfully!');
			
	    } catch (\Exception $e) {
			\DB::rollback();
			return redirect()->back()->with(['error'=> 'Line Number: '.$e->getLine().' Message: '.$e->getMessage()]);
		} catch (\Throwable $e) {
			\DB::rollback();
			return redirect()->back()->with(['error'=>$e->getMessage()]);
		}
					

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        try {
            $employee = $this->employee->with(['employee_status', 'manager_employee', 'employee_department', 'unit_employee', 'employee_setting', 'employee_shifts', 'employee_salaries', 'employee_relation', 'employee_designation', 'salary_slips'])->findOrFail($id);
            $title = 'Employee History - '.$employee->full_name;
            return view('admin.employee.show', compact('title', 'employee'));

        } catch (\Exception $e) {
            return redirect()->back()->with('error', $e->getMessage());
        }
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
//        try {
            $employee = $this->employee->with(['employee_status', 'employee_setting', 'employee_relation', 'employee_shifts', 'units_employee', 'employee_salaries', 'employee_designation','employee_vehicle'])->findOrFail($id);
			//return $employee;
            $vehicles = $this->companyVehicle->where('status',1)->where('assigned',0)->get();
			$units_ids = ($employee->units_employee) ? collect($employee->units_employee)->where('id', '!=', $employee->unit_id)->pluck('id')->toArray() : null;
            $type = request('type') ? ucwords(request('type')) : null;
            $managers = $this->employee->active()->orderBy('employee_id', 'ASC')->pluck('full_name', 'id')->toArray();
            // $managers = $this->employee->where('is_manager', 1)->orderBy('employee_id', 'ASC')->pluck('full_name', 'id')->toArray();
			$units = \App\Unit::where('status', 1)->orWhere('name', 'Neutral')->pluck('name', 'id')->toArray();
			$insurance_plans = InsurancePlan::pluck('name', 'id');
            $title = 'Update Employee - '.$employee->full_name;
            if($type){
                $title = 'Employee '.str_replace(['-','_'], ' ', $type).' - '.$employee->full_name;
            }
            $letters = $this->letter->where('status', 1)->pluck('name','id')->toArray();
            return view('admin.employee.edit', compact('title', 'employee', 'managers', 'units_ids', 'units','vehicles','letters', 'insurance_plans'));

      /*  } catch (\Exception $e) {
            return redirect()->back()->with('error', $e->getMessage());
        }*/
    }


    public function uploadExcel()
    {
        $title =  'Upload Employee';
        return view('admin.employee.upload', compact('title'));
    }

    public function uploadExcelSave(Request $request)
    {
		/*if (request()->hasFile('excel_file'))
        {
            $path = request()->file('excel_file')->getRealPath();

            $data = Excel::load($path)->get();
            foreach ($data as $vehicle){
				
			
				$checkVehicle = $this->companyVehicle->where('car_registration_no', trim($vehicle->no))->first();
				$employee = $this->employee->where('employee_id', trim($vehicle->id))->first();

				if($checkVehicle && $employee){
					
					$vehicle = [
						'employee_id' => $employee->id,
						'vehicle_id' =>  $checkVehicle->id,
					];
					
					
					$this->employeeVehicle->create($vehicle);

					$checkVehicle->update(['assigned' => 1]);

				}
				
			}
		}*/
		
		return 'Done';
		
		/*$employees = $this->employee->where('department', 'Information Technology')->get();
		foreach($employees as $employee){
			//return $employee;
			$updated = $employee->update(['department_id' => 11]);
		}
		
		return ''; */


      /*  if (request()->hasFile('excel_file'))
        {
            $path = request()->file('excel_file')->getRealPath();

            $data = Excel::load($path)->get();
            foreach ($data as $employee){


                $check = $this->employee->where('employee_id', $employee['code'])->first();
                if($check){
                    $start = Carbon::parse($employee['start'])->format('h:i A');
                    $end = Carbon::parse($employee['end'])->format('h:i A');
                    $id = $check->id;
                    $setting = $this->employeeSetting->where('employee_id', $id)->first();
                    $setting_data = [
                        'employee_id' => $id,
                        'total_work_hour' => config('app.working_hours'),
                        'check_in' => $start,
                        'check_out' => $end,
                        'timezone' => config('app.timezone'),
                    ];

                    if(!$setting){

                        $setting = $this->employeeSetting->create($setting_data);
                        $setting = $this->employeeShiftTiming->create([
                            'check_in' => $start,
                            'check_out' => $end,
                            'employee_id' => $id,
                            'total_work_hour' => config('app.working_hours'),
                        ]);

                    } else {
//                        $setting->update($setting_data);
                        $setting = $this->employeeShiftTiming->create([
                            'check_in' => $start,
                            'employee_id' => $id,
                            'check_out' => $end,
                            'total_work_hour' => config('app.working_hours'),
                        ]);
                    }

                }
            }

        }*/
return '';
		   if (request()->hasFile('excel_file'))
            {
                $path = request()->file('excel_file')->getRealPath();

                $data = Excel::load($path)->get();
				//return $data;
                foreach ($data as $employee){
					$check = $this->employee->where('employee_id', $employee['employee_code'])->first();
					$unit = \App\Unit::where('name', $employee['unit'])->first();

					if($check){
						$check->update([ 'unit_id' => ($unit) ? $unit->id : null ]);
					}
				}

			}
			return '';






		   if (request()->hasFile('excel_file'))
            {
                $path = request()->file('excel_file')->getRealPath();

                $data = Excel::load($path)->get();
				//return $data;
                foreach ($data as $employee){
					$check = $this->employee->where('employee_id', $employee['employee_code'])->first();
					if($check){
						if($employee['designation']){
							$udd = $check->update([
								'designation' => $employee['designation']
							]);
						}
						$u = $check->update([
							'salary' =>	$employee['salary'],
						]);
						if($employee['salary']){
							$this->employeeSalary->create([
									'employee_id' => $check->id,
									'amount' => $employee['salary'],
									'created_at' =>  Carbon::parse($check->join_date)->toDateTimeString()
							]);
						} else {
							$this->employeeSalary->create([
									'employee_id' => $check->id,
									'amount' => $check->salary,
									'created_at' =>  Carbon::parse($check->join_date)->toDateTimeString()
							]);
						}
						$this->employeeSalary->create([
								'employee_id' => $check->id,
								'amount' => $employee['salary'],
								'created_at' =>  Carbon::parse($check->join_date)->toDateTimeString()
						]);

						if ($employee['designation']){
							$designation_date = Carbon::parse($check->join_date)->toDateTimeString();
							$this->employeeDesignation->create([
								'employee_id' => $check->id,
								'name' => $employee['designation'],
								'created_at' => $designation_date
							]);
						} else {
							$designation_date = Carbon::parse($check->join_date)->toDateTimeString();
							$this->employeeDesignation->create([
								'employee_id' => $check->id,
								'name' => $check->designation,
								'created_at' => $designation_date
							]);
						}
						if ($employee['designation'] != $employee['new_designation']){

							$designation_date = Carbon::parse('01-01-2018')->toDateTimeString();
							$this->employeeDesignation->create([
								'employee_id' => $check->id,
								'name' => $employee['new_designation'],
								'created_at' => $designation_date
							]);

							$ud = $check->update([
								'designation' => $employee['new_designation']
							]);
						}



						if ($employee['increment_1_date']){
							$salary_date = Carbon::parse($employee['increment_1_date'])->toDateTimeString();
							$this->employeeSalary->create([
								'employee_id' => $check->id,
								'amount' => $employee['increment_1_raise'],
								'created_at' => Carbon::parse($employee['increment_1_date'])->toDateTimeString()
							]);
							$u1 = $check->update(['salary'=>$employee['increment_1_raise']]);
						}



						if ($employee['increment_2_date']){
							$salary_date = Carbon::parse($employee['increment_2_date'])->toDateTimeString();
							$this->employeeSalary->create([
								'employee_id' => $check->id,
								'amount' => $employee['increment_2_raise'],
								'created_at' => Carbon::parse($employee['increment_2_date'])->toDateTimeString()
							]);
							$u2 = $check->update(['salary'=>$employee['increment_2_raise']]);
						}


						if ($employee['increment_3_date']){
							$salary_date = Carbon::parse($employee['increment_3_date'])->toDateTimeString();
							$this->employeeSalary->create([
								'employee_id' => $check->id,
								'amount' => $employee['increment_3_raise'],
								'created_at' => Carbon::parse($employee['increment_3_date'])->toDateTimeString()
							]);
							$u3 = $check->update(['salary'=>$employee['increment_3_raise']]);
						}

						if ($employee['increment_4_date']){
							$salary_date = Carbon::parse($employee['increment_4_date'])->toDateTimeString();
							$this->employeeSalary->create([
								'employee_id' => $check->id,
								'amount' => $employee['increment_4_raise'],
								'created_at' => Carbon::parse($employee['increment_4_date'])->toDateTimeString()
							]);
							$u4 = $check->update(['salary'=>$employee['increment_4_raise']]);
						}


					}



				}

			}
return '';
	       /* if (request()->hasFile('excel_file'))
            {
                $path = request()->file('excel_file')->getRealPath();

                $data = Excel::load($path)->get();
				 foreach ($data as $employee){
				    	 $employee_created = $this->employee->where('email', $employee['email_address'])->first();
                        if($employee_created){

							$data2[] = 
							
							 [
								//'Timestamp' => \Carbon\Carbon::parse($employee['timestamp'])->format('d-m-Y'),
								'Employee Code' => $employee_created->employee_id,
								'Email' => $employee_created->email,
								'Name' => $employee_created->full_name,
								'Designation' =>  $employee['designation'],
								'Department' =>  $employee['department'],
								'Unit' =>  $employee['unit'],
								'Percent' => ( strpos( $employee['percent'], "." ) !== false ) ? $employee['percent']*100  : $employee['percent'],
							];
							
						}
				 }
			}
			
			
			
			Excel::create('Employee Contribution', function($excel) use($data2) {
						$excel->sheet('Employee', function($sheet) use($data2) {

							$sheet->row(1, [
								'Employee Code', 
								'Email',
								'Full Name', 
								'Designation',
								'Depatment',
								'Unit',
								'Percent',
							]);
							$sheet->row(1, function($row) {
								$row->setBackground('#000');
								$row->setFontColor('#ffffff');
								$row->setFontWeight('bold');
							});

							$i = 2;
							foreach ($data2 as $employeeD) {

								$sheet->row($i, array(
									$employeeD['Employee Code'],
									$employeeD['Email'],
									$employeeD['Name'],
									$employeeD['Designation'],
									$employeeD['Department'],
									$employeeD['Unit'],
									$employeeD['Percent'],
								));
								$i++;
							}
						});
					})->export('xls');
					
					
					
			return '';*/
            $this->validate($request, ['excel_file' => 'required']);

            if (request()->hasFile('excel_file'))
            {
                $path = request()->file('excel_file')->getRealPath();

                $data = Excel::load($path)->get();
                foreach ($data as $employee){
					
                    $employee_data = [
                        'employee_id' => $employee['employee_code'],
                        'full_name' => $employee['name'],
                        'father_name' => $employee['father_name'],
                        'salary'=>  (isset($employee['salary_package'])) ? $employee['salary_package'] : '',
                        'designation'=>  $employee['designation'],
                        'department'=>  $employee['department'],
                        'unit'=>  $employee['unit'],
                        'email'=>  $employee['abtach_email'],
                        'other_email'=> $employee['email'],
                        'phone_number' => (isset($employee['emergency_number'])) ? $employee['emergency_number'] : '',
                        'mobile_number' => $employee['contact_number'],
                        'national_identity' => $employee['cnic'],
                        'date_of_expiry' => $employee['date_of_expiry'],
                        'address' => $employee['address'],
                        'current_status' => $employee['status'],
                        'join_date' => Carbon::parse($employee['doj'])->toDateTimeString(),
                        'birth_date' => Carbon::parse($employee['dob'])->toDateTimeString(),
                        'reporting_authority'=>  $employee['reporting_authority'],
                    ];


                    if(isset($employee['abtach_email'])){
                        $check = $this->employee->where('employee_id', $employee['employee_code'])->first();
                        if(!$check){
                            $sallary =  (isset($employee['salary_package'])) ? $employee['salary_package'] : '';
							$employee_data = [
								'employee_id' => $employee['employee_code'],
								'full_name' => $employee['name'],
								'father_name' => $employee['father_name'],
								'salary'=>  (isset($employee['salary_package'])) ? $employee['salary_package'] : '',
								'designation'=>  $employee['designation'],
								'department'=>  $employee['department'],
								'unit'=>  $employee['unit'],
								'email'=>  $employee['abtach_email'],
								'other_email'=> $employee['email'],
								'phone_number' => (isset($employee['emergency_number'])) ? $employee['emergency_number'] : '',
								'mobile_number' => $employee['contact_number'],
								'national_identity' => $employee['cnic'],
								'date_of_expiry' => $employee['date_of_expiry'],
								'address' => $employee['address'],
                                'current_status' => $employee['status'],
								'join_date' => Carbon::parse($employee['doj'])->toDateTimeString(),
								'birth_date' => Carbon::parse($employee['dob'])->toDateTimeString(),
								'reporting_authority'=>  $employee['reporting_authority'],
							];
                            $employee_created =$this->employee->create($employee_data);
                            if(isset($employee['status'])){
                                $status = $employee['status'];
                                $status_date = $employee['status_date'];
                                $checkStatus = $this->employeeStatus->where('employee_id', $employee_created->id)->where('status', $status)->first();
                                if (!$checkStatus) {
                                    $employee->update(['current_status' => $status]);
                                    $status_date = Carbon::parse($status_date)->toDateTimeString();
                                    $this->employeeStatus->create([
                                        'employee_id' => $employee_created->id,
                                        'status' => $status,
                                        'status_at' => $status_date,
                                    ]);
                                }
                                $status = null;
                                $status_date = null;
                            }

                            $checkSalary = $this->employeeSalary->where('employee_id', $employee_created->id)->where('amount', $sallary)->first();
                            if (!$checkSalary && (isset($employee['salary_package_date']))){
                                $salary_date = Carbon::parse($employee['salary_package_date'])->toDateTimeString();
                                $this->employeeSalary->create([
                                    'employee_id' => $employee_created->id,
                                    'amount' => $checkSalary,
                                ]);
                                $salary_date = null;
                            }
                        } else {
							
				/*			$employee_data = [
								'full_name' => $employee['name'],
								'father_name' => $employee['father_name'],
								'salary'=>  (isset($employee['salary_package'])) ? $employee['salary_package'] : '',
								'designation'=>  $employee['designation'],
								'department'=>  $employee['department'],
								'unit'=>  $employee['unit'],
								'other_email'=> $employee['email'],
								'phone_number' => (isset($employee['emergency_number'])) ? $employee['emergency_number'] : '',
								'mobile_number' => $employee['contact_number'],
								'national_identity' => $employee['cnic'],
								'date_of_expiry' => $employee['date_of_expiry'],
								'address' => $employee['address'],
								'join_date' => Carbon::parse($employee['doj'])->toDateTimeString(),
								'birth_date' => Carbon::parse($employee['dob'])->toDateTimeString(),
								'reporting_authority'=>  $employee['reporting_authority'],
							];
							
							$check->update($employee_data);*/

						}
                    }
                }
                return redirect()->route('admin.employee.index')->with('success', 'Employee Uploaded Successfully!');

            }
        return redirect()->route('admin.employee.index')->with('success'. 'Employee Upload Error!');


    }

    public function employee_status($employee_id, $id)
    {
        try {
            $employee = $this->employee->with(['employee_status', 'employee_salaries', 'employee_designation'])->findOrFail($employee_id);
            $status = $this->employeeStatus->findOrFail($id);
   		    $type = request('type') ? ucwords(request('type')) : null;
            $title = 'Update Employee '.$type.' - '.$employee->full_name;
            return view('admin.employee.edit_status', compact('title', 'employee', 'status'));

        } catch (\Exception $e) {
            return redirect()->route('admin.employee.index')->with('error', $e->getMessage());
        }
    }	

	 public function employee_vehicle($employee_id, $id)
    {
        try {
            $vehicle = $this->employeeVehicle->with(['employee_detail'])->findOrFail($id);
			$vehicle = $vehicle;
			$employee = $vehicle->employee_detail;

            $type = request('type') ? ucwords(request('type')) : null;
            $title = 'Update Employee '.$type.' - '.$employee->full_name;
            return view('admin.employee.edit_vehicle', compact('title', 'vehicle', 'employee'));

        } catch (\Exception $e) {
            return $e->getLine();
        }
    }
	
	
	public function employee_vehicle_update($employee_id, $id){
			$vehicle = $this->employeeVehicle->findOrFail($id);
			$car_issue_date = Carbon::createFromFormat('d/m/Y', request('car_issue_date'))->toDateTimeString();
			$vehicleData = [
				'employee_id' => $id,
				'car_provided' =>  request('car_provided'),
				'car_type' =>  request('car_type'),
				'car_make' =>  request('car_make'),
				'car_model' =>  request('car_model'),
				'car_color' =>  request('car_color'),
				'car_registration_no' =>  request('car_registration_no'),
				'car_issue_date' => $car_issue_date,
				'car_details' =>  request('car_details'),
			];

			$vehicle->update($vehicleData);
			return redirect()->back()->with('success', 'Vehicle Updated Successfully!');
	}
	
    public function employee_status_update(Request $request, $id, $status_id)
    {
        $employee = $this->employee->findOrFail($id);
		if($request->get('clearance_date')){
			$clearance_date = ($request->get('clearance_date')) ? Carbon::createFromFormat('d/m/Y', request('clearance_date'))->toDateString() : null;
			$ec_updated = $employee->update(['clearance_date' => $clearance_date]);
		}
        $status = request('current_status');
        $status_date = Carbon::createFromFormat('d/m/Y',request('created_at'))->toDateTimeString();
        $end_date = ($request->get('end_at')) ? Carbon::createFromFormat('d/m/Y',request('end_at'))->toDateTimeString() : null;
        $checkStatus = $this->employeeStatus->where('employee_id', $id)->where('status', $status)->first();
        if ($checkStatus) {
            $checkStatus->update([
                'status' => $status,
                'comments' => request('comments'),
                'status_at' => $status_date,
                'end_at' => $end_date,
            ]);
            // return redirect()->back()->with('success', 'Employee Status Updated Successfully!');
        } else {
            $employee->update(['current_status' => $status]);
            $this->employeeStatus->create([
                'employee_id' => $id,
                'status' => $status,
                'comments' => request('comments'),
                'status_at' => $status_date,
                'end_at' => $end_date,
            ]);
        }
        $latest_status = $employee->employee_status()->first();
        if($latest_status) {
	        $employee->update([
	        	'current_status' => $latest_status->status
	        ]);
        }
        return redirect()->back()->with('success', 'Employee Status Updated Successfully!');
    }


    public function employee_salary($employee_id, $id)
    {
        try {
            $employee = $this->employee->with(['employee_salaries'])->findOrFail($employee_id);
            $salary = $this->employeeSalary->findOrFail($id);
            $type = request('type') ? ucwords(request('type')) : null;
            $title = 'Update Salary '.$type.' - '.$employee->full_name;
            return view('admin.employee.edit_salary', compact('title', 'employee', 'salary'));

        } catch (\Exception $e) {
            return redirect()->route('admin.employee.index')->with('error', $e->getMessage());
        }
    }

    public function employee_salary_update(Request $request, $id, $salary_id)
    {
        $employee = $this->employee->findOrFail($id);
		
	
        $current_salary = request('amount');
        $salary_date = Carbon::createFromFormat('d/m/Y',request('created_at'))->toDateTimeString();
        $checkSalary = $this->employeeSalary->where('employee_id', $id)->where('id', $salary_id)->first();
        if ($checkSalary) {

            if($current_salary != $employee->salary){
                $employee->update(['salary' => $current_salary]);
            }
            $checkSalary->update([
                'employee_id' => $employee->id,
                'amount' => $current_salary,
                'created_at' => $salary_date,
            ]);
            return redirect()->back()->with('success', 'Employee Status Updated Successfully!');
        } else {

            $employee->update(['salary' => $current_salary]);
            $this->employeeSalary->create([
                'employee_id' => $employee->id,
                'amount' => $current_salary,
                'created_at' => $salary_date,
            ]);

        }
		
			
				
        return redirect()->back()->with('success', 'Employee Salary Updated Successfully!');

    }


    public function employee_designation($employee_id, $id)
    {
        try {
            $employee = $this->employee->with(['employee_designation'])->findOrFail($employee_id);
            $designation = $this->employeeDesignation->findOrFail($id);
            $type = request('type') ? ucwords(request('type')) : null;
            $title = 'Update '.$type.' - '.$employee->full_name;
            return view('admin.employee.edit_designation', compact('title', 'employee', 'designation'));

        } catch (\Exception $e) {
            return redirect()->route('admin.employee.index')->with('error', $e->getMessage());
        }
    }

    public function employee_designation_update(Request $request, $id, $designation_id)
    {
        $employee = $this->employee->findOrFail($id);

        $name = request('name');
        $updated_date = Carbon::createFromFormat('d/m/Y', request('created_at'))->toDateTimeString();
        $checkDesignation = $this->employeeDesignation->where('employee_id', $id)->where('id', $designation_id)->first();
        if ($checkDesignation) {

            if($name != $employee->designation){
                $employee->update(['designation' => $name]);
            }
            $checkDesignation->update([
                'employee_id' => $id,
                'name' => $name,
                'created_at' => $updated_date,
            ]);
            return redirect()->back()->with('success', 'Employee Designation Updated Successfully!');
        } else {

            $employee->update(['designation' => $name]);
            $this->employeeSalary->create([
                'employee_id' => $id,
                'name' => $name,
                'created_at' => $updated_date,
            ]);

        }
        return redirect()->back()->with('success', 'Employee Designation Updated Successfully!');

    }
    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        try {
        	$response_error = '';
            $employee = $this->employee->with('units_employee')->findOrFail($id);
            if(request('password')) {
                $request->merge(['password'=>bcrypt(request('password'))]);
            }
            if($request->get('type')  == 'status') {
				if($request->get('current_status') == 'Separation'){
					if($request->get('created_at')){
						$clearance_date = ($request->get('created_at')) ? Carbon::createFromFormat('d/m/Y', request('created_at'))->addDays(45)->toDateTimeString() : null;
					} else {
						$clearance_date = Carbon::now()->addDays(45)->toDateTimeString();
					}
					$ec_updated = $employee->update(['clearance_date' => $clearance_date]);
					// employee 
			        EmployeeFinalSettlement::updateOrCreate([
			        	'employee_id' => $employee->id
			        ], [
			        	'date' => formatDate($clearance_date, 'Y-m-d'),
			        	'status_id' => 2
			        ]);
				}

                $status = request('current_status');
				$status_date = Carbon::createFromFormat('d/m/Y',request('created_at'))->toDateTimeString();
                $end_date = ($request->get('end_at')) ? Carbon::createFromFormat('d/m/Y', request('end_at'))->toDateTimeString() : null;
                $start_format = ($request->get('created_at')) ? Carbon::createFromFormat('d/m/Y', request('created_at'))->toDateString() : null;
                $end_format = ($request->get('end_at')) ? Carbon::createFromFormat('d/m/Y', request('end_at'))->toDateString() : null;

             /*   if(request('end_at')){
                    $checkStatus = $this->employeeStatus->where('employee_id', $id)
                        ->where('status', $status)
                        ->whereDate('status_at', '=', $start_format)
                        ->whereDate('end_at', '=', $end_format)
                        ->first();
				
						
                } else {
                    $checkStatus = $this->employeeStatus->where('employee_id', $id)->where('status', $status)->first();
                }*/

                /*if ($checkStatus) {
					$updated_true = $employee->update(['current_status' => $status]);
					 $checkStatus->update([
                        'status' => $status,
                        'comments' => request('comments'),
                        'status_at' => $status_date,
                        'end_at' => $end_date,
                     ]);
                    return redirect()->back()->with('success', 'Employee Status Updated Successfully!');
                } else {*/
                	// send welcome email
                	if(strtolower($employee->current_status) == 'offered' &&  in_array(strtolower(request('current_status')), ['internship','probation','permanent','contractual'])){
                		if(empty($employee->email)){
                			return redirect()->back()->with('error','Please add employee company email');
                		} elseif(empty($employee->manager_id)){
                			return redirect()->back()->with('error','Please add employee manager');
                		} else {
                			// send welcome email
                			$cc_emails = [config('general.emails.cc_default')];
                			if($employee->manager_employee) {
	                			$cc_emails[] = $employee->manager_employee->email;
                			}
                			$unit_employees = $this->employee->active()->where('unit_id', $employee->unit_id)->pluck('email','id')->toArray();
                			$employee_ids = array_merge(
                				[$employee->manager_id],
                				$employee->all_manager_ids(),
                				array_keys($unit_employees),
                				[33]
                			);
                			$cc_emails = array_unique(array_merge($cc_emails, array_values($unit_employees)));
                			$cc_emails = array_filter($cc_emails, function($email){
                			 	return $email != null;
                			 });
                			// add welcome note
                			 $note = \App\Note::create([
					            'user_id' => auth()->guard('admin_web')->id(),
					            'title' => "Welcoming {$employee->full_name}",
					            'content' => htmlspecialchars(view('admin.emails.employee.partials.welcome')->with([
					            	'employee' => $employee
					            ])),
					            'employee_ids' => json_encode($employee_ids),
					            'email_enabled' => 0
					        ]);
                			 // send email
                			Mail::to($employee->email)->cc($cc_emails)->send(new WelcomeEmployeeEmail($employee));


                			if(!$employee->is_foreigner){
	                			// send portal account email
	                			Mail::to($employee->email)->send(new EmployeeSetPasswordEmail($employee));
	                			// send insurance email
	                			Mail::to($employee->email)->cc(config('general.emails.cc_default'))->send(new NotifyEmployeePermenant($employee));
                			}
                		}
                	}
                	// update status
                    $updated_true =  $employee->update(['current_status' => $status]);
                    $employee_new_status = $this->employeeStatus->create([
                        'employee_id' => $id,
                        'status' => $status,
                        'comments' => request('comments'),
                        'type' => (request('status_type')) ? request('status_type') : null,
                        'status_at' => $status_date,
                        'end_at' => $end_date,
                    ]);
                    if(strtolower($employee_new_status->status) == 'offered'){
                    	$cc_managers = $this->employee->whereIn('id', $employee->all_manager_ids())->pluck('email')->toArray();
                		Mail::to(array_merge(
	            			[ config('general.emails.hr') ],
	            			config('general.IT_emails')
	            		))->cc(array_unique(array_merge(
	            			[
	                			config('general.emails.cc_default'),
	                			config('general.emails.salmanyousuf'),
	                			config('general.emails.azneembilwani'),
	                		],
	                		config('general.HR_emails'),
	                		config('general.finance_emails'),
	                		config('general.admin_emails'),
	                		$cc_managers
	                	)))->send(new NotifyEmployeeOffered($employee));
                    } elseif(!$employee->is_foreigner && (strtolower($employee_new_status->status) == 'permanent')){
                    	if($employee->email){
                    		if($employee->information == 0){
	                    		Mail::to($employee->email)->cc(config('general.emails.cc_default'))->send(new NotifyEmployeePermenant($employee));
                    		}
                    		Mail::to($employee->email)->cc([config('general.emails.hr'), config('general.emails.cc_default')])->send(new NotifyEmployeeConfirmed($employee));
                    	}
                    } elseif(strtolower($employee_new_status->status) == 'notice period'){
                    	if($employee->email){
                    		Mail::to($employee->email)->cc([
                    			config('general.emails.cc_default'),
                    			config('general.emails.salmanyousuf'),
                    			config('general.emails.hr'),
                    		])->send(new NotifyEmployeeNoticePeriod($employee, $end_date));
                    	}
                    }  elseif(strtolower($employee_new_status->status) == 'separation'){
                    	$cc_managers = $this->employee->whereIn('id', $employee->all_manager_ids())->pluck('email')->toArray();
                		Mail::to(array_merge(
                			[ config('general.emails.hr') ],
                			config('general.IT_emails')
                		))->cc(array_unique(array_merge(
                			[
                    			config('general.emails.cc_default'),
                    			config('general.emails.salmanyousuf'),
                    			config('general.emails.azneembilwani'),
                    		],
                    		config('general.HR_emails'),
                    		config('general.finance_emails'),
                    		config('general.admin_emails'),
                    		$cc_managers
                    	)))->send(new NotifyEmployeeSeparation($employee, $status_date));
                    } 
               /* }*/
                return redirect()->back()->with('success', 'Employee Status Added Successfully!');
            } elseif($request->get('type')  == 'payroll'){
                $updated_date = Carbon::createFromFormat('d/m/Y', request('created_at'))->toDateTimeString();
                $amount = request('salary');
                $checkSalary = $this->employeeSalary->where('employee_id', $id)->where('amount', $amount)->whereDate('created_at', '=', carbon()->parse($updated_date)->format('Y-m-d'))->first();
                if ($checkSalary) {
                    return redirect()->back()->with('success', 'Employee Payroll Already Taken!');
                } else {
                    $employee->update(['salary' => $amount]);
                    $this->employeeSalary->create([
                        'employee_id' => $id,
                        'amount' => $amount,
                        'comments' => request('comments'),
                        'created_at' => $updated_date,
                    ]);
                }
                return redirect()->back()->with('success', 'Employee Payroll Updated Successfully!');
            }elseif($request->get('type')  == 'family'){
				
				$dobe = Carbon::createFromFormat('d/m/Y', request('dob'))->toDateTimeString() ;
						$family = [
							'employee_id' => $id,
							'full_name' =>  request('family_member'),
							'relation' =>  request('relation'),
							'date_of_birth' =>  ($dobe) ? $dobe : null,
						];

						$this->employeeRelation->create($family);
			return redirect()->back()->with('success', 'Employee Family Updated Successfully!');
            } elseif($request->get('type')  == 'vehicle'){
                $car_issue_date = Carbon::createFromFormat('d/m/Y', request('car_issue_date'))->toDateTimeString();
                $vehicle_id =  request('vehicle_id');
                $vehicle = [
                    'employee_id' => $id,
                    'vehicle_id' =>  $vehicle_id,
                    'car_issue_date' => $car_issue_date,
                ];
                $vehicleStatus = [
                    'assigned' => 1,
                ];
				$this->employeeVehicle->create($vehicle);
				$this->companyVehicle->find($vehicle_id)->update($vehicleStatus);
				return redirect()->back()->with('success', 'Employee Vehicle Created Successfully!');
            }elseif($request->get('type')  == 'designation'){
                $checkDesignation1 = $this->employeeDesignation->where('employee_id', $id)->where('name', $employee->designation)->first();
                if (!$checkDesignation1) {
                    $created_at_date = Carbon::parse($employee->created_at)->toDateTimeString();
                    $this->employeeDesignation->create([
                        'employee_id' => $id,
                        'name' => $employee->designation,
                        'created_at' => $created_at_date,
                    ]);
                }

                $name = request('name');
                $checkDesignation = $this->employeeDesignation->where('employee_id', $id)->where('name', $name)->first();
                if ($checkDesignation) {
                    return redirect()->back()->with('success', 'Employee Designation Already Taken!');
                } else {
                    $employee->update(['designation' => $name]);
                    $updated_date = Carbon::createFromFormat('d/m/Y', request('created_at'))->toDateTimeString();
                    $this->employeeDesignation->create([
                        'employee_id' => $id,
                        'name' => $name,
                        'created_at' => $updated_date,
                    ]);
                }
                return redirect()->back()->with('success', 'Employee Designation Updated Successfully!');
            } elseif($request->get('type')  == 'shift'){
				
				$check_in = Carbon::parse($request->get('check_in'))->format('h:i A');
				$check_out = Carbon::parse($request->get('check_out'))->format('h:i A');

				$shift_date = Carbon::createFromFormat('d/m/Y', request('created_at'));
                $checkShift = $this->employeeShiftTiming->where('employee_id', $id)->where('check_in', request('check_in'))->where('check_out', request('check_out'))->whereDate('created_at', '=', $shift_date->format('Y-m-d'))->first();
                if (!$checkShift) {
                    $created_at_date = $shift_date->toDateTimeString();
                    $employee_shift_timing = $this->employeeShiftTiming->create([
                        'employee_id' => $id,
                        'check_in' => $check_in,
                        'check_out' => $check_out,
                        'created_at' => $created_at_date,
                    ]);
                    if(request('notify_employee')){
                    	Mail::to($employee->email)->cc(config('general.emails.cc_default'))->send(new NotifyEmployeeShift($employee, $employee_shift_timing));
                    }
                }

                $setting = $this->employeeSetting->where('employee_id', $id)->first();
                $setting_data = [
                    'employee_id' => $id,
                    'total_work_hour' => config('app.working_hours'),
                    'check_in' => $check_in,
					'check_out' => $check_out,
                    'timezone' => config('app.timezone'),
                ];
                if(!$setting){
                    $this->employeeSetting->create($setting_data);
                } else {
                    $setting->update($setting_data);
                }
                return redirect()->back()->with('success', 'Employee Shift Updated Successfully!');
            } elseif($request->get('type') == 'unit_distribution') {
            	$total_percent = array_sum(request('percent'));
            	if($total_percent != 100){
            		return back()->with('error', 'Sum of all unit percents should be 100');
            	} else {
            		foreach(request('percent') as $unit_id => $percent){
            			\DB::table('employee_units')
            						->where(['employee_id' => $employee->id, 'unit_id' => $unit_id])
            						->update([
            							'percent' => $percent
            						]);
            		}
            		return back()->with('success', 'Successfully Updated');
            	}
            } else {
                // $setting = $this->employeeSetting->where('employee_id', $id)->first();
                // $setting_data = [
                //     'employee_id' => $id,
                //     'total_work_hour' => config('app.working_hours'),
                //     'check_in' => $request->get('check_in'),
                //     'check_out' => $request->get('check_out'),
                //     'timezone' => config('app.timezone'),
                // ];
                // if(!$setting){
                //     $setting = $this->employeeSetting->create($setting_data);
                // } else {
                //     $setting->update($setting_data);
                // }
				
				$units = (request('unit_id')) ? [request('unit_id')] : null;
				$unit_direct_id = request('unit_id');
				if(!request('unit_id')){
					$unit_direct_id = (isset(request('unit_ids')[0])) ? request('unit_ids')[0] : request('unit_id');
				}
				
				if($units) {
					$units_array = (request('unit_ids')) ? request('unit_ids') : [];
					$other_units = array_merge($units_array, $units);
					$units_insert = $employee->units_employee()->sync($other_units);
				}


				$join_date = Carbon::createFromFormat('d/m/Y', request('date_of_join'))->toDateTimeString();
				$birth_date = (request('birth_date')) ? Carbon::createFromFormat('d/m/Y', request('birth_date'))->format('Y-m-d') : null;
				$data_merge = [
					'join_date' => $join_date, 
					'unit_id' => $unit_direct_id, 
					'birth_date' => $birth_date,
					'bank_details' => ($employee->bank_details) ? array_merge($employee->bank_details, $request->bank_details) : $request->bank_details
				];
				request()->merge($data_merge);
                $employee->update(request()->except('_token', 'type', 'employee', 'unit_ids', 'check_in', 'check_out', 'current_status', 'status_date', 'end_at', 'date_of_join','password', 'brand_id', 'employee_photo', 'void_cheque', 'probation_period'));
                // update void cheque if requested
                if($request->hasFile('void_cheque')){
                	if(!empty($employee->bank_details['void_cheque']) && Storage::exists("void_cheques/{$employee->bank_details['void_cheque']}")){
                		Storage::delete("void_cheques/{$employee->bank_details['void_cheque']}");
                	}
					$cheque_filename = uniqid(time()).'.'.$request->void_cheque->getClientOriginalExtension();
					$request->void_cheque->storeAs('void_cheques', $cheque_filename);
					$employee->update([
						'bank_details' => array_merge($request->bank_details, ['void_cheque' => $cheque_filename])
					]);
				}
                // update password
                if(request('password')){
                	$employee->update(['password' => request('password')]);
                }
                // save employee department
                $employee_department_id = $employee->departments()->orderBy('id','desc')->first();
				if($employee_department_id){
					$employee_department_id = $employee_department_id->department_id;
					if($employee_department_id != request('department_id')){
						$employee_department = EmployeeDepartmentAssign::create([
							'employee_id' => $employee->id,
							'department_id' => request('department_id')
						]);
						// notify with email
						if($employee->email){
							Mail::to($employee->email)->cc(config('general.emails.cc_default'))->send(new NotifyEmployeeDepartment($employee, $employee_department));
						}
					}
				}
				
                // save employee manager
                $employee_manager_id = $employee->managers()->orderBy('id','desc')->first();
				if($employee_manager_id){
					$employee_manager_id = $employee_manager_id->manager_id;
					if($employee_manager_id != request('manager_id')){
						$employee_manager = EmployeeManager::create([
							'employee_id' => $employee->id,
							'manager_id' => request('manager_id')
						]);
						// notify with email
						// if($employee->email){
						// 	$cc_emails = [
						// 		$employee_manager->manager->email,
						// 		config('general.emails.cc_default')
						// 	];
						// 	Mail::to($employee->email)->cc(array_unique($cc_emails))->send(new NotifyEmployeeReporting($employee, $employee_manager));
						// }
					}
				} else {
					// save employee manager
					if(request('manager_id')){
						EmployeeManager::create([
							'employee_id' => $employee->id,
							'manager_id' => request('manager_id')
						]);
					}
				}

				
			
            }
			
            return redirect()->route('admin.employee.index')->with('error', 'Employee Updated Successfully!');



        } catch (\Exception $e) {
			return redirect()->back()->with('error', 'Line Number: ' .$e->getLine(). ' - Error: '.$e->getMessage());
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $type = request('type');
        if ($type == 'status') {
            $employee_status = $this->employeeStatus->find($id);
            $employee_id = $employee_status->employee_id;
            $employee_status1 = $employee_status->delete();

            $employee_status = $this->employeeStatus->where('employee_id', $employee_id)->latest('id')->first();
            $employee = $this->employee->find($employee_id);

            if($employee_status){
                $employee->update(['current_status' => $employee_status->status]);
            }

        } elseif($type == 'salary'){
            $employee_salary = $this->employeeSalary->find($id);
            $employee_salary1 = $employee_salary->delete();
            $employee_id = $employee_salary->employee_id;

            $employee_salary= $this->employeeSalary->where('employee_id', $employee_id)->latest('id')->first();
            $employee = $this->employee->find($employee_id);

            if($employee_salary){
                $employee->update(['salary' => $employee_salary->amount]);
            }
        } elseif($type == 'designation'){
            $employee_designation = $this->employeeDesignation->find($id);
            $employee_designation1 =$employee_designation->delete();
            $employee_id =$employee_designation->employee_id;

            $employee_designation= $this->employeeDesignation->where('employee_id', $employee_id)->latest('id')->first();
            $employee = $this->employee->find($employee_id);

            if($employee_designation){
                $employee->update(['designation' =>$employee_designation->name]);
            }
        } elseif($type == 'shift'){
            $employee_shift= $this->employeeShiftTiming->find($id);
            $employee_shift->delete();
        }
		elseif($type == 'family'){
            $employeeRelation= $this->employeeRelation->find($id);
			$employeeRelation->delete();
        }
		elseif($type == 'vehicle'){
            $employeeVehicle= $this->employeeVehicle->find($id);
			$employeeVehicle->delete();
        } else {
	        if (request('type') == 'restore') {
	            $this->employee->onlyTrashed()->find($id)->restore();
	        } elseif (request('type') == 'forceDelete') {
	            $this->employee->onlyTrashed()->find($id)->forceDelete();
	        } else{
	            $this->employee->find($id)->delete();
	        }
        }


        

        if (request()->ajax()) {
            return response()->json(['success' => true]);
        }

        return redirect()->back()->withSuccess('Deleted Successfully');
    }

    /**
     * @param $id
     * @param $type
     * @return \Illuminate\Http\Response
     */
    public  function letters($id)
    {
        $letters = $this->letter->where('status', '1')->orderBy('id', 'ASC')->get();
		
        $employee = $this->employee->with(['employee_status', 'employee_salaries', 'employee_designation'])->findOrFail($id);
		
		//$status = $this->employeeStatus->findOrFail($id);
		
        return view('admin.employee.letter',compact('letters','employee'));
    }
    public function generate_letter($id, $letter_id)
    {
        $employee = $this->employee->with(['manager_employee', 'employee_status', 'unit_employee', 'employee_salaries', 'employee_designation'])->findOrFail($id);
        $letter = $this->letter->find($letter_id);
		//return $employee;
		$employee_status = $employee->employee_status->where('status','Permanent');
		
		if($employee_status && !empty($employee_status[0]))
		{
			$confirmationdate =  Carbon::parse($employee_status[0]->status_at)->format('F, d Y');
		}
		else 
		{
			$confirmationdate = '';
		}
		
		
        $letterbody = $letter->content;

        $salary = $this->employeeSalary->where('employee_id', $id)->orderBy('id', 'desc')->skip(1)->take(1)->get();
		$incrementdate = $this->employeeSalary->where('employee_id', $id)->orderBy('id', 'desc')->take(1)->get();
		
       if(isset($salary[0]->amount) && ($salary[0]->amount>0))
       {
           $oldsalary = $salary[0]->amount;
           $incrementeffectfrom = Carbon::parse($incrementdate[0]->created_at)->format('F, d Y');
       }
       else
       {
           $oldsalary = 0;
           $incrementeffectfrom = '';
       }

        $current_salry = $employee->salary;
        $increment = $current_salry-$oldsalary;
        //Fields Merage
        $letterbody = str_replace('@date@',date('F d, Y'),$letterbody);
        $letterbody = str_replace('@currentdate@',date('F d, Y'),$letterbody);

        $letterbody = str_replace('@employeecode@',$employee->employee_id,$letterbody);
        $letterbody = str_replace('@cnic@',$employee->national_identity,$letterbody);
        $letterbody = str_replace('@name@',$employee->full_name,$letterbody);

        $intership_period = (request('period')) ? request('period') : '3 months';
        $letterbody = str_replace('@period@',$intership_period,$letterbody);

        $firstname = $employee->full_name;

       /* if(strpos($employee->full_name, ' ') !== false)
        {
            $firstname = substr($employee->full_name,0,strpos($employee->full_name,' '));
        }
		*/
		
		$firstname = explode(" ",$employee->full_name);
		if($firstname[0] <> "Syeda" && $firstname[0] <> "Syed"  &&  $firstname[0] <> "Muhammad")
		{
			$firstname = $firstname[0];
		}
		else {
		    $firstname = $firstname[1];
		}
		
				
        $letterbody = str_replace('@firstname@', $firstname, $letterbody);
        $letterbody = str_replace('@designation@', $employee->designation, $letterbody);
		$department_check = (isset($employee->employee_department->name)) ? $employee->employee_department->name : $employee->department;
        $letterbody = str_replace('@department@', $department_check, $letterbody);
		
		$unit_name = ($employee->unit_employee) ? $employee->unit_employee->name : $employee->unit;
        $letterbody = str_replace('@unit@', $unit_name, $letterbody);
        ($employee->sex=='female' && $employee->marital_status=='married') ? $title = 'Mrs' : $title='Ms';
        if($employee->sex=='male') { $title = 'Mr'; }
		
		if($employee->manager_employee){
				if($employee->manager_employee->sex=='male')
		{ $rtittle = 'him'; } else { $rtittle = 'her'; }
		}
	
		
        $letterbody = str_replace('@title@', $title, $letterbody);
        $letterbody = str_replace('@salary@', number_format($employee->salary), $letterbody);
        $output = Terbilang::make($employee->salary);
        $output = ucwords($output);
        $letterbody = str_replace('@salaryinwords@', $output, $letterbody);
		if(isset($employee->manager_employee->full_name)){
			$letterbody = str_replace('@managername@', $employee->manager_employee->full_name, $letterbody);
		}
        $letterbody = str_replace('@managerdesignation@', $employee->manager_employee->designation, $letterbody);
        $letterbody = str_replace('@incrementamount@', $increment, $letterbody);
        $letterbody = str_replace('@incrementeffectivedate@', $incrementeffectfrom, $letterbody);
        $letterbody = str_replace('@effectivedate@', Carbon::parse($employee->created_at)->format('F, d Y'), $letterbody);
        $letterbody = str_replace('@managerdepartment@', $employee->manager_employee->department, $letterbody);
        $letterbody = str_replace('@day@', date('l'), $letterbody);
		  $letterbody = str_replace('@validtill@', Carbon::now('Asia/Karachi')->addWeeks(1)->format('F, d Y'), $letterbody);
		  $letterbody = str_replace('@confirmationdate@', $confirmationdate, $letterbody);
		  $letterbody = str_replace('@rtittle@', $rtittle, $letterbody);
		  
		  if($letter->name == 'Appointment Letter'){
		   $employee_status = $this->employeeStatus->whereEmployeeId($id)->whereStatus('Probation')->latest()->first();
		   if($employee_status){
		    $letterbody = str_replace('@joindate@',  Carbon::parse($employee_status->status_at)->format('F d, Y'), $letterbody);
		   }
		  } else {
		   $letterbody = str_replace('@joindate@',  Carbon::parse($employee->join_date)->format('F d, Y'), $letterbody);
		  }
		
		
		
	   // return $employee;
		
        // return  $letter ;
       /*return view('admin.employee.letter.'.$type, ['employee'=>$employee]);*/
       $pdf = $this->PDF->loadView('admin.employee.letter.index', ['employee'=>$employee,'letterbody'=>$letterbody,'output'=>$output]);
       if(request('save') && request('employee_letter_id')){
	       	$employee_letter = EmployeeLetter::find(request('employee_letter_id'));
       		if (($employee_letter->employee_id == $id) && !\File::exists('uploads/letters/'.request('employee_letter_id').'.pdf')){
		       	$pdf->save( public_path('uploads/letters/'.request('employee_letter_id').'.pdf')); 
       		}
       }
       return $pdf->stream();
    }
    // shift timings
    public function shift()
    {
    	$title = request('current_status'). ' Employees';
        $employees = $this->employee->query();
        $employees = $employees->with([
            'employee_status', 'employee_setting'
        ])->search()->orderBy('employee_id', 'ASC');
        $employees = $employees->paginate((request('per_page')) ? request('per_page') : 30 );
        return view('admin.employee.shift',  compact('title', 'employees'));
    }
    public function employee_vehicle_close($employee_id, $id)
    {
        $vehicle = $this->companyVehicle->find($id);
        $employee = $this->employee->find($employee_id);
        $title = 'Vehicle';
        return view('admin.company_vehicles.vehicle_close',  compact('title', 'vehicle', 'employee'));
    }
    public function employee_vehicle_close_update($employee_id, $id)
    {
        $car_return_date = Carbon::createFromFormat('d/m/Y', request('car_return_date'))->toDateTimeString();
        $vehicleStatus = [
            'assigned' => 0,
        ];
        $employeeVehicleData = ['car_return_date' => $car_return_date];
        if(request('car_rent')){
        	$employeeVehicleData['car_rent'] = request('car_rent');
        }
        $this->employeeVehicle->where('employee_id', $employee_id)->where('vehicle_id', $id)->where('id', request('rent_history'))->update($employeeVehicleData);
        $this->companyVehicle->find($id)->update($vehicleStatus);
        return redirect()->back()->with('success', 'Employee Vehicle Close Successfully!');
    }

    // letters
    public function employee_letters($id)
    {
    	$employee = $this->employee->find($id);
    	$title = 'Letters - '.$employee->full_name;
    	$letters = $this->letter->pluck('name','id')->toArray();
    	return view('admin.employee.employee_letters',compact('employee','title','letters'));
    }

    // send portal email
    public function send_portal_email($id)
    {
    	$employee = $this->employee->find($id);
    	if($employee && $employee->email){
            Mail::to($employee->email)->send(new EmployeeSetPasswordEmail($employee));
            $data = ['set_password_email' => 1];
            Employee::where('id', $employee->id)->update($data);
            return redirect()->back()->with('success', 'Sent Email!');
        } else {
        	return redirect()->back()->with('error', 'Employee not found');
        }
    }

    public function impersonate($id)
    {
    	$user = $this->employee->find($id);
    	\Auth::guard('web')->login($user);
    	\Cookie::queue('employee_impersonate_'.$user->id, true, 120);
    	return redirect()->route('home');
    }
    // export separation employees sheet
    public function export_separated_employee_sheets()
    {
    	$employees  = $this->employee->whereHas('employee_status', function($q){
    		return $q->where('status', 'Separation');
    	})->get();
    	Excel::create('abtach-separated-employees'.date('Y-m-d'), function($excel) use($employees){
                $excel->sheet('Report', function($sheet) use($employees){
                     $sheet->loadView('admin.employee.partials.separation_table', array('employees' => $employees));
                    });
            })->export('xls');
    }
    // export separation employees sheet
    public function export_flexible_employee_sheets()
    {
    	$employees  = $this->employee->active()->where('is_flexible_timing', 1)->get();
    	Excel::create('abtach-separated-employees'.date('Y-m-d'), function($excel) use($employees){
                $excel->sheet('Flexible-Employees-Report', function($sheet) use($employees){
                     $sheet->loadView('admin.employee.partials.separation_table', array('employees' => $employees));
                    });
            })->export('xls');
    }

    // sent foreign account email
    public function send_foreign_account_email($id)
    {
    	$employee = $this->employee->active()->find($id);
    	if($employee && $employee->is_foreigner){
    		$foreign_agent = $employee->foreign_agent;
    		if($foreign_agent){
    			$foreign_agent;
	    		if($employee->foreign_agent_password){
	    			$foreign_agent_password = $foreign_agent->password_text;
	    		} else {
	    			$foreign_agent_password = $foreign_agent->password_text()->create([
	    				'employee_id' => $employee->id,
	    				'password' => uniqid(time()),
	    				'foreign_agent_id' => $employee->foreign_agent->id,
	    			]);
	    			$foreign_agent->update([
	    				'password' => bcrypt($foreign_agent_password->password)
	    			]);
	    		}
    			if($foreign_agent->email && !$foreign_agent_password->email_sent){
                    Mail::to($foreign_agent->email)->bcc($employee->manager_employee->email)->send(new ForeignEmployeeAccountEmail($foreign_agent, $foreign_agent_password->password));
                    $foreign_agent_password->update([
                    	'email_sent' => 1
                    ]);
                } else {
                	return back()->with('error', 'something went wrong');
                }
                return back()->with('success', 'Email Sent Successfully!');
    		}
    	} else {
    		return back()->with('error', 'Employee is not foreigner!');
    	}
    }
}
