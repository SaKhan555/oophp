<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Employee;
use App\EmployeeIncentive;

class EmployeeIncentiveController extends Controller
{
    /**
     * @var Employee
     */
    private $employee;
    /**
     * @var EmployeeIncentive
     */
    private $incentive;
    /**
     * Constructor
     * @var Employee $employee
     */
    public function __construct(Employee $employee, EmployeeIncentive $incentive)
    {
        $this->employee = $employee;
        $this->incentive = $incentive;
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index($employee_id)
    {
        $employee = $this->employee->find($employee_id);
        $incentives = $employee->incentives;
        $title = $employee->full_name.' - Incentives';
        return view('admin.employee_incentive.index', compact('title', 'employee', 'incentives'));    
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create($employee_id)
    {
        
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request, $employee_id)
    {
        $this->validate_rules($request);
        $employee = $this->employee->find($employee_id);
        $data = [
            'employee_id' => $employee->id,
            'amount' => $request->amount,
            'date' => carbon()->createFromFormat('d/m/Y' ,$request->date)->format('Y-m-d')
        ];
        $this->incentive->create($data);
        return back()->with('success', 'Incentive Created');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($employee_id, $id)
    {
        $employee = $this->employee->find($employee_id);
        $incentive = $this->incentive->find($id);
        $title = 'Employee Incentive - '.$incentive->date->format('M Y');
        return view('admin.employee_incentive.edit', compact('title', 'incentive', 'employee'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $this->validate_rules($request);
        $incentive = $this->incentive->find($id);
        $data = [
            'amount' => $request->amount,
            'date' => carbon()->createFromFormat('d/m/Y' ,$request->date)->format('Y-m-d')
        ];
        $incentive->update($data);
        return redirect()->route('admin.employee_incentive.index', $incentive->employee_id)->with('success', 'Incentive Updated!');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
    /**
     * validate rules
     */
    public function validate_rules($request, $rules = [])
    {
        return $this->validate($request, array_merge([
            'date' => 'required',
            'amount' => 'required'
        ], $rules));
    }
}
