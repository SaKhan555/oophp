<?php

namespace App\Http\Controllers\Admin;

use App\JobApplication;
use App\CareerJob;
use App\JobCategory;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class JobApplicationController extends Controller
{
    /**
     * @var JobApplication
     */
    private $jobApplication;

    /**
     * JobApplicationController constructor.
     * @param JobApplication $jobApplication
     */
    public function __construct(JobApplication $jobApplication)
    {
        $this->jobApplication = $jobApplication;
    }


    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $title = CareerJob::where('id', request('category'))->pluck('title')->first();
        $title = 'Job Applications - '.$title;


        $job_applications = $this->jobApplication->query();
        $job_applications = $job_applications->search()->latest()->paginate((request('per_page')) ? request('per_page') : 20 );

        $career_jobs = CareerJob::pluck('title', 'id')->toArray();
        // if(is_null(request('status'))){
        $career_jobs[null] = 'Junk';
        // }
        return view('admin.job_applications.index',  compact('title', 'job_applications', 'career_jobs'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $title = 'Add Cv';
        $career_jobs = CareerJob::pluck('title', 'id')->toArray();
        return view('admin.job_applications.create', compact('title', 'career_jobs'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate_rules($request);
        $file_name = '';
        if($request->hasFile('file')){
            $file = $request->file('file');
            $file_name = 'cv'.time().'.'.$file->getClientOriginalExtension();
            $file->move('uploads/careers' , $file_name);  
        }
        $data = [
            'career_job_id' => $request->career_job_id,
            'category' => CareerJob::find($request->career_job_id)->title,
            'name' => $request->name,
            'email' => $request->email,
            'phone' => $request->phone,
            'current_salary' => $request->current_salary,
            'designation' => $request->designation,
            'past_company' => $request->past_company,
            'file_name' => $file_name
        ];
        $this->jobApplication->create($data);
        return redirect()->route('admin.job-application.index',['category'=>$request->career_job_id])->with('success', 'CV added');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        try {
            $job_application = $this->jobApplication->findOrFail($id);

            $title = 'Job Application - '.$job_application->name;
            return view('admin.job_applications.show', compact('title', 'job_application'));

        } catch (\Exception $e) {
            return redirect()->back()->with('error', $e->getMessage());
        }
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $job_application = $this->jobApplication->find($id);
        $title = 'Edit Job Application - '.$job_application->name;
        $career_jobs = CareerJob::pluck('title', 'id')->toArray();
        return view('admin.job_applications.edit', compact('job_application', 'title', 'career_jobs'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $this->validate_rules($request);
        $job_application = $this->jobApplication->find($id);
        $file_name = $job_application->file_name;
        if($request->hasFile('file')){
            $old_file_path = public_path().'/uploads/careers/'.$file_name;
            if($file_name && file_exists($old_file_path)){
                unlink($old_file_path);
            }
            $file = $request->file('file');
            $file_name = 'cv'.time().'.'.$file->getClientOriginalExtension();
            $file->move('uploads/careers' , $file_name);  
        }
        $data = [
            'career_job_id' => $request->career_job_id,
            'category' => CareerJob::find($request->career_job_id)->title,
            'name' => $request->name,
            'email' => $request->email,
            'phone' => $request->phone,
            'current_salary' => $request->current_salary,
            'designation' => $request->designation,
            'past_company' => $request->past_company,
            'file_name' => $file_name
        ];
        $job_application->update($data);
        return redirect()->route('admin.job-application.index',['category'=>$request->career_job_id])->with('success', 'CV Updated');
    }
    /**
     * Update the specified resource category in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function updateCategory(Request $request, $id)
    {
        $career_job_id = $request->value;
        $job_application = $this->jobApplication->find($id);
        if(is_null($career_job_id)) {
            $job_application->update([
                'status' => 0
            ]);
        } else {
            $job_application->update([
                'career_job_id' => $career_job_id,
                'status' => 1
            ]);
        }
        
        \Session::flash('success', 'Job Application moved');
        return response()->json(['status' => true]);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        if (request('type') == 'restore') {
            $this->jobApplication->onlyTrashed()->find($id)->restore();
        } elseif (request('type') == 'forceDelete') {
            $this->jobApplication->onlyTrashed()->find($id)->forceDelete();
        } else{
            $this->jobApplication->find($id)->delete();
        }

        if (request()->ajax()) {
            return response()->json(['success' => true]);
        }

        return redirect()->back()->withSuccess('Deleted Successfully');
    }
    /**
     * validate rules
     */
    public function validate_rules($request)
    {
        return $this->validate($request, [
            'career_job_id' => 'required|numeric',
            'name' => 'required',
            'phone' => 'required',
            'email' => 'required',
            'past_company' => 'required',
            'current_salary' => 'required',
            'designation' => 'required',
            'file' => 'mimes:application/msword,text/plain,application/pdf,application/vnd.openxmlformats-officedocument.wordprocessingml.document,png,jpeg,jpg,gif,doc,docx,pdf'
        ]);
    }
}
