<?php

namespace App\Http\Controllers\Admin;

use App\CompanyVehicle;
use App\Employee;
use App\EmployeeVehicle;
use App\CompanyVehicleRent;
use Carbon\Carbon;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Maatwebsite\Excel\Facades\Excel;

class CompanyVehicleController extends Controller
{

    private $companyVehicle;
    /**
     * @var Employee
     */
    private $employee;
    /**
     * @var EmployeeVehicle
     */
    private $employeeVehicle;
    /**
     * @var CompanyVehicleRent
     */
    private $companyVehicleRent;

    /**
     * CompanyVehicleController constructor.
     * @param CompanyVehicle $companyVehicle
     * @param Employee $employee
     * @param EmployeeVehicle $employeeVehicle
     */
    public function __construct(CompanyVehicle $companyVehicle, Employee $employee, EmployeeVehicle $employeeVehicle,CompanyVehicleRent $companyVehicleRent)
    {
        $this->companyVehicle = $companyVehicle;
        $this->employee = $employee;
        $this->employeeVehicle = $employeeVehicle;
        $this->companyVehicleRent = $companyVehicleRent;
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $title = 'Company Vehicle';
        $vehicles = $this->companyVehicle->search()->paginate(20);
        // exoprt excel if requested
        if(request('export')){
            // export excel
            $this->exportExcel();
        }
        return view('admin.company_vehicles.index', compact('title','vehicles'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $title = 'Add New Vehicle';
        return view('admin.company_vehicles.create', compact('title'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        request()->merge([
            'car_purchase_date' => (request('car_purchase_date')) ? Carbon::createFromFormat('d/m/Y', request('car_purchase_date'))->toDateTimeString() : null,
            'car_sold_date' => (request('car_sold_date')) ? Carbon::createFromFormat('d/m/Y', request('car_sold_date'))->toDateTimeString() : null,
        ]);
        $companyVehicle = $this->companyVehicle->create(request()->except('rent_per_day','rent_effective_date'));
        // if vehicle type rent
        $this->saveCarRent($request, $companyVehicle->id);
        return redirect()->route('admin.vehicle.index')->with('success', 'Vehicle Added Successfully!');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\CompanyVehicle  $companyVehicle
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $vehicle = $this->companyVehicle->find($id);
        $title = 'View Vehicle - '.$vehicle->car_model;
        return view('admin.company_vehicles.show', compact('title','vehicle'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\CompanyVehicle  $companyVehicle
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        try {
            $vehicle = $this->companyVehicle->findOrFail($id);
            $title = 'Update Vehicle';
            return view('admin.company_vehicles.edit', compact('title', 'vehicle'));

        } catch (\Exception $e) {
            return $e->getLine();
        }
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\CompanyVehicle  $companyVehicle
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $this->validate($request, [
            'rent_effective_date' => 'required_with:rent_per_day'
        ]);
        request()->merge([
            'car_purchase_date' => (request('car_purchase_date')) ? Carbon::createFromFormat('d/m/Y', request('car_purchase_date'))->toDateTimeString() : null,
            'car_sold_date' => (request('car_sold_date')) ? Carbon::createFromFormat('d/m/Y', request('car_sold_date'))->toDateTimeString() : null,
        ]);
        $company_vehicle = $this->companyVehicle->find($id)->update(request()->except('_token','rent_per_day','rent_effective_date'));
        // save car rent
        $this->saveCarRent($request, $id);
        return redirect()->route('admin.vehicle.index')->with('success', 'Vehicle Updated');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\CompanyVehicle  $companyVehicle
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $this->companyVehicle->find($id)->delete();
        if (request()->ajax()) {
            return response()->json(['success' => true]);
        }
        return redirect()->back()->withSuccess('Deleted Successfully');
    }

    public function status($id)
    {
        $companyVehicle = $this->companyVehicle->find($id);

        $newStatus = ($companyVehicle->assigned == 1) ? 0 : 1;

        $companyVehicle->update(['assigned'=>$newStatus]);

        if(request()->ajax()){
            return response()->json(['updated' => true, 'status' => $newStatus]);
        }

        return redirect()->route('vehicle.index');
    }

    public function employeeVehicle($id)
    {
        $title = 'Assign Vehicle To Employee';
        $employees = $this->employee->select('id', 'full_name', 'employee_id')->whereNotIn('current_status', ['Separation', 'Offered'])->get();

        $vehicle = $this->companyVehicle->findOrFail($id);

        return view('admin.company_vehicles.assign', compact('employees', 'title', 'vehicle'));
    }

    public function employeeVehicleAdd($id)
    {
        $car_issue_date = (request('car_issue_date')) ? Carbon::createFromFormat('d/m/Y', request('car_issue_date'))->toDateTimeString() : null;

        $companyVehicle = $this->companyVehicle->find($id);

        if($companyVehicle->assign == 1){
            return redirect()->back()->with('success', 'Vehicle Already Assigned!');
        }

        $employee_vehicle = $this->employeeVehicle->where('employee_id', request('employee_id'))->whereNull('car_return_date')->orderBy('id', 'DESC')->first();

        if(($employee_vehicle) && ($employee_vehicle->id == $id)){
            $vehicleData = [
                'car_issue_date' => $car_issue_date,
            ];
            $vehicleStatus = ['assigned' => 1];
            $this->employeeVehicle->find($employee_vehicle->id)->update($vehicleData);
            $companyVehicle->update($vehicleStatus);
        } else {
            if($employee_vehicle){
                 $employee_vehicle->update(['car_return_date'=>Carbon::now()->toDateTimeString()]);
                 $vehicleStatus = ['assigned' => 0];
                 $this->companyVehicle->find($employee_vehicle->vehicle_id)->update($vehicleStatus);
            }
            $car_issue_date = Carbon::createFromFormat('d/m/Y', request('car_issue_date'))->toDateTimeString();
            $employee_id =  request('employee_id');
            $vehicle = [
                'employee_id' => $employee_id,
                'vehicle_id' =>  $id,
                'car_issue_date' => $car_issue_date,
            ];
            $vehicleStatus = ['assigned' => 1];
            $this->employeeVehicle->create($vehicle);
            $this->companyVehicle->find($id)->update($vehicleStatus);
        }


        return redirect()->route('admin.employee.edit', [$employee_id, 'type' => 'vehicle'])->with('success', 'Employee Vehicle Created Successfully!');
    }

    // export excel sheet
    public function exportExcel()
    {
        // prepare data for sheet
        $data = $this->companyVehicle->get()->toArray();

        return Excel::create('Abtach-vehicles-'.date('d-m-Y'), function($excel) use ($data) {
            $excel->sheet('Vehicles', function($sheet) use ($data)
            {
                // style headers
                $sheet->cell('A1:I1', function($cell) {
                    $cell->setBackground('#000');
                    $cell->setFontColor('#ffffff');
                    $cell->setFontWeight('bold');
                });
                // set headers
                $sheet->setCellValue('A1', 'Registration No');
                $sheet->setCellValue('B1', 'Type');
                $sheet->setCellValue('C1', 'Make');
                $sheet->setCellValue('D1', 'Model');
                $sheet->setCellValue('E1', 'Color');
                $sheet->setCellValue('F1', 'Purchase Date');
                $sheet->setCellValue('G1', 'Assigned');
                $sheet->setCellValue('H1', 'Vehicle Status');
                if (!empty($data)) {
                    foreach ($data as $key => $value) {
                        $i= $key+2;
                        $sheet->cell('A'.$i, $value['car_registration_no']); 
                        $sheet->cell('B'.$i, $value['car_type']); 
                        $sheet->cell('C'.$i, $value['car_make']); 
                        $sheet->cell('D'.$i, $value['car_model']); 
                        $sheet->cell('E'.$i, $value['car_color']); 
                        $sheet->cell('F'.$i, date('d M Y',strtotime($value['car_purchase_date']))); 

                        if($value['assigned'] == 1 && $value['car_status'] != 'sold'){
                            $vehicle_employee = get_employee_vehicle($value['id']);
                            $assigned = $vehicle_employee['name'];
                        } else {
                            $assigned = 'Not Assigned';
                        }

                        $sheet->cell('G'.$i, $assigned);

                        $sheet->cell('H'.$i, $value['car_status']); 
                    }
                }
                // $sheet->fromArray($excel_data);
            });
        })->download('xls');
    }
    // update car rent field
    public function updateRent(Request $request)
    {
        $id = $request->pk;
        $rent = $this->companyVehicleRent->where('id', $id)->first();
        if($rent){
            $column = $request->name;
            $value = $request->value;
            // $value = ($column == 'created_at') ?
            //             Carbon::createFromFormat('m/d/Y',$request->rent_effective_date)->toDateTimeString() :
            //             $request->value;
            $rent->update([$column => $value]);
            if(request()->ajax()){
                return response()->json(['status' => true]);    
            } else {
                return redirect()->back()->with('success','Rent Updated Successfully');
            }
        }
        return response()->json(['status' => false]);
    }
    // save car rent if type = rent
    public function saveCarRent($request, $id)
    {
        if($request->car_type == 'rent' && $request->rent_per_day){
            $rent_effective_date = Carbon::parse($request->rent_effective_date);
            $effective_month = $rent_effective_date->format('m');
            $effective_year = $rent_effective_date->format('Y');
            $effective_date = Carbon::createFromFormat('m/d/Y',$request->rent_effective_date)->toDateTimeString();
            $vehicle_rent = $this->companyVehicleRent->whereMonth('created_at','=', $effective_month)->whereYear('created_at', '=',$effective_year)->where('company_vehicle_id',$id)->first();
            $rent_data = [
                'rent_per_day' => $request->rent_per_day,
                'created_at' => $effective_date
            ];
            if($vehicle_rent) {
                $vehicle_rent->update($rent_data);
            } else {
                $this->companyVehicleRent->create(array_merge([
                    'company_vehicle_id' => $id
                ], $rent_data));
            }
        }
    }
}
