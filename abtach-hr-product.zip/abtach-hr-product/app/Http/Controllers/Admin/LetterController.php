<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Letter;
use Illuminate\Http\Request;

class LetterController extends Controller
{
    /**
     * @var Letter
     */
    private $letter;

    public function __construct(Letter $letter)
    {
        $this->letter = $letter;
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $title = 'Letters';
        $letters = $this->letter->where('status', '1')->orderBy('id', 'ASC')->get();
        return view('admin.letter.index',compact('title', 'letters'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $title = 'Add New Letter';
        return view('admin.letter.create', compact('title'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $letterData = [
            'name' => request('name'),
            'description' => request('description'),
            'content' => request('content'),
            'status' => request('status')
        ];
        $this->letter->create($letterData);
        return redirect()->route('admin.letter.index')->with('success', 'Letter Template Created Successfully!');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Letter  $letter
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $letters = $this->letter->where('status', '1')->orderBy('id', 'ASC')->get();
        return view('admin.letter.show',compact('id','letters'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Letter  $letter
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $letter =  $this->letter->find($id);
        $title = 'Edit '.ucwords($letter->name);
        return view('admin.letter.edit',compact('letter' ,'title'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Letter  $letter
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Letter $letter)
    {
        $letterData = [
            'name' => request('name'),
            'description' => request('description'),
            'content' => request('content'),
            'status' => request('status')
        ];
        $letter->update($letterData);
        return redirect()->route('admin.letter.index')->with('success', 'Letter Template Updated');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Letter  $letter
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        if (request('type') == 'restore') {
            $this->letter->onlyTrashed()->find($id)->restore();
        } elseif (request('type') == 'forceDelete') {
            $this->letter->onlyTrashed()->find($id)->forceDelete();
        } else{
            $this->letter->find($id)->delete();
        }
     return redirect()->route('admin.letter.index')->with('success', 'Letter Template Deleted');
    }
}
