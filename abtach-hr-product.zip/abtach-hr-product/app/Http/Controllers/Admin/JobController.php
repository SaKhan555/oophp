<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\CareerJob;
use App\JobCategory;

class JobController extends Controller
{
    /**
     * @var job
     */
    private $job;

    /**
     * JobController constructor.
     * @param CareerJob $job
     */
    public function __construct(CareerJob $job)
    {
        $this->job = $job;
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $title = 'Career Jobs';
        $jobs = $this->job->with('job_category')->paginate(20);
        return view('admin.job.index',  compact('title', 'jobs'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $title = 'Add New Job';
        $job_categories = JobCategory::pluck('title','id')->toArray();
        return view('admin.job.create',  compact('title','job_categories'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request, $this->validate_rules());
        $data = [
            'job_category_id' => $request->job_category_id,
            'title' => $request->title,
            'slug' => str_slug($request->title,'-'),
            'salary' => $request->salary,
            'vacancies' => $request->vacancies,
            'experience' => $request->experience,
            // 'experience_in_years' => $request->experience_in_years,
            'description' => htmlspecialchars($request->description),
        ];
        $this->job->create($data);
        return redirect()->route('admin.job.index')->with('success', 'Job Created Successfully');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $title = 'Edit Job';
        $job = $this->job->find($id);
        $job_categories = JobCategory::pluck('title','id')->toArray();
        return view('admin.job.edit',  compact('title','job','job_categories'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $this->validate($request, $this->validate_rules());
        $data = [
            'job_category_id' => $request->job_category_id,
            'title' => $request->title,
            'salary' => $request->salary,
            'vacancies' => $request->vacancies,
            'experience' => $request->experience,
            // 'experience_in_years' => $request->experience_in_years,
            'description' => htmlspecialchars($request->description),
        ];
        if($request->update_slug){
            $data['slug'] = str_slug($request->slug,'-');
        }

        $this->job->find($id)->update($data);
        return redirect()->route('admin.job.index')->with('success', 'Job Updated Successfully');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $this->job->find($id)->delete();
        if (request()->ajax()) {
            return response()->json(['success' => true]);
        }
        return redirect()->back()->withSuccess('Deleted Successfully');
    }
    /**
     * Validation rules
     * @return array
     */
    public function validate_rules($rules=array())
    {
        return array_merge([
            'title' => 'required',
        ], $rules);
    }
}
