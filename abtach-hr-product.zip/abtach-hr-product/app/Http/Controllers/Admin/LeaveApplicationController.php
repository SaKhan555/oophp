<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\EmployeeLeaveApplication;
use App\EmployeeLeaveApproval;
use App\EmployeeLeaveType;
use App\Employee;
use App\User;
use Illuminate\Support\Facades\Mail;
use App\Mail\EmployeeLeaveStatus;
use Maatwebsite\Excel\Facades\Excel;

class LeaveApplicationController extends Controller
{
	/**
     * @var EmployeeLeaveApplication
     */
    private $employee_leave_application;
    /**
     * @var EmployeeLeaveApproval
     */
    private $employee_leave_approval;
    /**
     * @var Employee
     */
    private $employee;
	/**
     * @var EmployeeLeaveType
     */
    private $employee_leave_type;
    /**
     * ExpenseController constructor.
     * @param EmployeeLeaveApplication $employee_leave_application
     */
    public function __construct(EmployeeLeaveApplication $employee_leave_application,EmployeeLeaveApproval $employee_leave_approval, Employee $employee, EmployeeLeaveType $employee_leave_type)
    {
        $this->employee_leave_application = $employee_leave_application;
        $this->employee_leave_approval = $employee_leave_approval;
        $this->employee = $employee;
        $this->employee_leave_type = $employee_leave_type;
    }

    /**
     * show all leave applications
     */
    public function index()
    {
    	$title = 'Leave Applications';
    	$leave_applications = $this->employee_leave_application->search()->paginate(20);
        $employees_list = $this->employee->active()->pluck('full_name', 'id')->toArray();
        $leave_types = $this->employee_leave_type->pluck('title', 'id')->toArray();
    	return view('admin.employee_leave_applications.index', compact('title','leave_applications', 'employees_list','leave_types'));
    }
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $title = 'Add Leave Application';
        $leave_types = EmployeeLeaveType::pluck('title','id')->toArray();
        $employees = $this->employee->pluck('full_name', 'id')->toArray();
        return view('admin.employee_leave_applications.create', compact('title','leave_types', 'employees'));
    }
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        // validate
        $employee = $this->employee->find($request->employee_id);
        $start_date = carbon()->createFromFormat('d/m/Y', request('start_date'));
        $end_date = carbon()->createFromFormat('d/m/Y', request('end_date'));
        if($start_date->greaterThan($end_date)){
            return redirect()->back()->with('error', 'Start Date must be a date before End Date');
        }
        $this->validate_rules($request);
        // create
        $start_date = carbon()->createFromFormat('d/m/Y', $request->input('start_date'));
        $end_date = ($request->input('end_date')) ? carbon()->createFromFormat('d/m/Y', $request->input('end_date')) : $start_date;

        $start_date_compare = $start_date->format('Y-m-d');
        $end_date_compare = $end_date->format('Y-m-d');
        $applied = $employee->leave_applications()->where(function($q) use($start_date_compare, $end_date_compare){
                            return $q->whereDate('start_date', '<=' ,$start_date_compare)
                                    ->whereDate('end_date', '>=' ,$end_date_compare);
                        })->first();
        if($applied) {
            return redirect()->back()->with('error', 'Already applied for this date');
        } else {
            if($request->leave_type == 5) {
                $total_leaves = .5;
            } else {
                $total_leaves = $start_date->diffInDays($end_date) + 1;
            }
            $data = [
                'employee_id' => $request->employee_id,
                'leave_type_id' => $request->leave_type,
                'contact_number' => $request->contact_number,
                'start_date' => $start_date,
                'end_date' => $end_date,
                'reason' => $request->reason,
                'total_leave' => $total_leaves
            ];
            $leave_application = $this->employee_leave_application->create($data);
            // email setup
            // $email = $leave_application->employee->manager_employee->email;
            // $cc_emails = [];
            // $users_emails = User::where('email_notify', 1)->pluck('email');
            // foreach($users_emails as $user_email) {
            //     if($user_email != $email){
            //         $cc_emails[] = $user_email;
            //     }
            // }
            // send email
            // Mail::to($email)->cc(array_unique($cc_emails))->send(new EmployeeLeaveApplicationEmail($leave_application));
            return redirect()->route('admin.employee_leave_application.index')->with('success', 'Leave Application Created');
        }
    }
    /**
     * Approve application
     */
    public function approve(Request $request, $id)
    {
        $employee_id = auth()->guard('admin_web')->user()->employee_id;
        // create approval
        $data = [
            'leave_id' => $id,
            'manager_id' => $employee_id,
            'comments' => $request->comments,
            'status' => $request->status,
            'type' => 'admin'
        ];
        $leave_approval = $this->employee_leave_approval->create($data);
        // email setup
        $leave_application = $this->employee_leave_application->find($request->leave_id);
        $employee = Employee::find($employee_id);
        $email = $leave_application->employee->email;
        $cc_emails = [];
        $users = User::where('id','!=',auth()->guard('admin_web')->id())->where('email_notify', 1)->get();
        foreach($users as $user) {
            $cc_emails[] = $user->email;
        }
        // send email
        Mail::to($email)->cc(array_unique($cc_emails))->send(new EmployeeLeaveStatus($leave_application,$leave_approval, $employee));
    	return back()->with('success','Updated Successfully');
    }
    /**
     * Show the leave application
     */
    public function show($id) 
    {
    	$title = 'View Leave Application';
    	$leave_application = $this->employee_leave_application->find($id);
    	return view('admin.employee_leave_applications.show', compact('title','leave_application'));
    }
    /**
     * Show the form for editing a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $title = 'Edit Leave Application';
        $leave_application = $this->employee_leave_application->find($id);
        $leave_types = EmployeeLeaveType::pluck('title','id')->toArray();
        $employees = $this->employee->pluck('full_name', 'id')->toArray();
        return view('admin.employee_leave_applications.edit', compact('title','leave_types', 'employees', 'leave_application'));
    }
    /**
     * Update status
     */
    public function update(Request $request, $id)
    {
        // validate
        $employee = $this->employee->find($request->employee_id);
        $leave_application = $this->employee_leave_application->find($id);
        $start_date = carbon()->createFromFormat('d/m/Y', request('start_date'));
        $end_date = carbon()->createFromFormat('d/m/Y', request('end_date'));
        if($start_date->greaterThan($end_date)){
            return redirect()->back()->with('error', 'Start Date must be a date before End Date');
        }
        $this->validate_rules($request);
        // create
        $start_date = carbon()->createFromFormat('d/m/Y', $request->input('start_date'));
        $end_date = ($request->input('end_date')) ? carbon()->createFromFormat('d/m/Y', $request->input('end_date')) : $start_date;

        $start_date_compare = $start_date->format('Y-m-d');
        $end_date_compare = $end_date->format('Y-m-d');
        $applied = $employee->leave_applications()->where('id','!=', $id)
                            ->where(function($q) use($start_date_compare, $end_date_compare){
                            return $q->whereDate('start_date', '<=' ,$start_date_compare)
                                    ->whereDate('end_date', '>=' ,$end_date_compare);
                        })->first();
        if($applied) {
            return redirect()->back()->with('error', 'Already applied for this date');
        } else {
            if($request->leave_type == 5) {
                $total_leaves = .5;
            } else {
                $total_leaves = $start_date->diffInDays($end_date) + 1;
            }
            $data = [
                'employee_id' => $request->employee_id,
                'leave_type_id' => $request->leave_type,
                'contact_number' => $request->contact_number,
                'start_date' => $start_date,
                'end_date' => $end_date,
                'reason' => $request->reason,
                'total_leave' => $total_leaves
            ];
            $leave_application->update($data);
            return redirect()->route('admin.employee_leave_application.index')->with('success', 'Leave Application Created');
        }
    }
    /**
     * Update Status
     */
    public function approveStatus(Request $request, $id)
    {
        $leave_application = $this->employee_leave_approval->find($id);
        $newStatus = ($leave_application->status == 1) ? 0 : 1;

        $leave_application->update(['status'=>$newStatus]);

        if($request->ajax()){
            return response()->json(['updated' => true, 'status' => $newStatus]);
        }

        return redirect()->back();
    }

    public function validate_rules($request, $rules=[], $id=null)
    {
        return $this->validate($request, array_merge([
            'contact_number' => 'required',
            'leave_type' => 'required',
            'start_date' => "required",
            'end_date' => "required",
            'reason' => 'required',
        ], $rules));
    }


    // export excel
    // public function export_excel()
    // {
    //     $employees_leaves = Excel::load('./annual-leaves.xlsx')->get()->toArray();
    //     $employees_leaves = array_filter($employees_leaves, function($employee_leave){
    //         return $employee_leave['total_leaves'] > 0;
    //     });
    //     foreach($employees_leaves as $employee_leave) {
    //         $employee = \App\Employee::where('employee_id', $employee_leave['employee_code'])->first();
    //         if($employee) {
    //             $end_date = carbon()->parse('25th july 2018');
    //             $employee_manager = $employee->managers()->latest()->first();
    //             if(strpos($employee_leave['leaves_availed'], '.') !== false){
    //                 $total_leaves = explode('.', $employee_leave['leaves_availed']);
    //                 $total_leaves = $total_leaves[0];
    //                 $data = [
    //                     'employee_id' => $employee->id,
    //                     'leave_type_id' => 5,
    //                     'contact_number' => $employee->phone_number,
    //                     'start_date' => carbon()->parse($end_date)->subDays(($total_leaves - 1))->subDay(),
    //                     'end_date' => $end_date,
    //                     'reason' => 'Some Reason',
    //                     'total_leave' => .5
    //                 ];
    //                 $leave_application = $this->employee_leave_application->create($data);
    //                 \App\EmployeeLeaveApproval::create([
    //                     'leave_id' => $leave_application->id,
    //                     'manager_id' => ($employee_manager) ? $employee_manager->manager_id : 33,
    //                     'comments' => 'approved',
    //                     'status' => 1
    //                 ]);
    //             } else {
    //                 $total_leaves = $employee_leave['leaves_availed'];
    //             }
    //             $data = [
    //                 'employee_id' => $employee->id,
    //                 'leave_type_id' => 1,
    //                 'status' => 1,
    //                 'contact_number' => $employee->phone_number,
    //                 'start_date' => carbon()->parse($end_date)->subDays(($total_leaves - 1)),
    //                 'end_date' => $end_date,
    //                 'reason' => 'Some Reason',
    //                 'total_leave' => $total_leaves
    //             ];
    //             $leave_application = $this->employee_leave_application->create($data);
    //             \App\EmployeeLeaveApproval::create([
    //                 'leave_id' => $leave_application->id,
    //                 'manager_id' => ($employee_manager) ? $employee_manager->manager_id : 33,
    //                 'comments' => 'approved',
    //                 'status' => 1
    //             ]);
    //         }
    //     }
    // }
}
