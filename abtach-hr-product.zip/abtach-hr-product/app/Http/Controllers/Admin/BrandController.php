<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Brand;

class BrandController extends Controller
{
	// load list
    public function load_list($unit_id=null)
    {
    	$brands = Brand::query();
    	if($unit_id) {
    		$brands = $brands->where('unit_id', $unit_id);
    	}
    	return json_encode($brands->pluck('name', 'id')->toArray());
    } 
}
