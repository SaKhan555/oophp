<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Employee;
use App\Team;
use App\Agent;
use App\Brand;
use App\AgentFactor;
use App\AgentTarget;
use Carbon\Carbon;

class EmployeeAgentController extends Controller
{
     /**
     * @var Employee
     */
    private $employee;
     /**
     * @var Employee
     */
    private $team;
     /**
     * @var Agent
     */
    private $agent;
     /**
     * @var Brand
     */
    private $brand;
     /**
     * @var AgentFactor
     */
    private $agent_factor;
     /**
     * @var AgentTarget
     */
    private $agent_target;
    /**
     * @param Employee $employee
     * @param Team $team
    */
    public function __construct(Employee $employee, Team $team, Agent $agent, Brand $brand, AgentFactor $agent_factor,AgentTarget $agent_target)
    {
        $this->employee = $employee;
        $this->team = $team;
        $this->agent = $agent;
        $this->brand = $brand;
        $this->agent_factor = $agent_factor;
        $this->agent_target = $agent_target;
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create($employee_id)
    {
        $employee = $this->employee->find($employee_id);
        $agent = $this->agent->where('email', $employee->email)->first();
        if(!$agent){
            $title = $employee->full_name. ' - Mark Agent';
            $teams = $this->team->orderBy('name','asc')->pluck('name','id')->toArray();
            return view('admin.employee_agent.create',compact('employee','title','teams'));
        } else {
            return redirect()->route('admin.employee_agent.edit',$agent->id);
        }
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store($employee_id, Request $request)
    {
        $employee = $this->employee->find($employee_id);
        $agent = $this->agent->where('email', $employee->email)->first();
        if(!$agent) {

        } else {
            return redirect()->route('admin.employee_agent.edit',$agent->id);
        }
        request()->merge([
            'employee_id'=>$employee->employee_id,
            'unit_id' => $employee->unit_id,
            'email'=>$employee->email,
            'name'=>$employee->full_name,
            'sudo_name' => $employee->sudo_name,
            'designation' => $employee->designation,
            'password'=>bcrypt('12345678'),
            'role'=>'sale'
        ]);
        $agent = $this->agent->create(request()->except(['department_ids']));

        $this->agent_factor->create([
            'agent_id' => $agent->id,
            'factor' => '0'
        ]);

        // save brands
        $brand_ids = $this->brand->where('unit_id', $employee->unit_id)->pluck('id')->toArray();
        $agent->brands()->sync($brand_ids);

        // save departments
        if($request->get('department_ids')){
            $agent->departments()->sync($request->get('department_ids'));
        }
        return redirect()->route('admin.employee.index')->with('success','Agent Assigned');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $agent = $this->agent->find($id);
        $title = $agent->name.' - Edit Agent';
        $teams = $this->team->orderBy('name','asc')->pluck('name','id')->toArray();
        $department_ids = $agent->departments()->pluck('id')->toArray();
        return view('admin.employee_agent.edit',compact('title','agent','teams','department_ids'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $agent = $this->agent->findOrFail($id);
        $employee = $this->employee->where('email', $agent->email)->first();
        request()->merge([
            'employee_id'=>$employee->employee_id,
            'email'=>$employee->email,
            // 'name'=>$employee->full_name,
            // 'password'=>'12345678',
            'role'=>'sale'
        ]);
        $agent_updated = $agent->update(request()->except(['_token', 'department_ids','factor_month']));
        $m = Carbon::parse($request->get('factor_month'))->format('m');
        $y = Carbon::parse($request->get('factor_month'))->format('Y');
        $agent_factor_current = $this->agent_factor->query();
        $agent_factor_current = $agent_factor_current->whereMonth('created_at', '=', $m);
        $agent_factor_current = $agent_factor_current->whereYear('created_at', '=', $y);
        $agent_factor_current =$agent_factor_current->where('agent_id', $id);
        $agent_factor_current = $agent_factor_current->first();
        if($agent_factor_current){
            $agent_factor_current->update([
                'agent_id' => $id,
                'factor' => $request->get('factor'),
                'created_at' => Carbon::parse($request->get('factor_month'))->toDateTimeString(),
            ]);
        } else {
            $this->agent_factor->create([
                'agent_id' => $id,
                'factor' => $request->get('factor'),
                'created_at' => Carbon::parse($request->get('factor_month'))->toDateTimeString(),
            ]);
        }


        // save brands
        $brand_ids = $this->brand->where('unit_id', $agent->employee->unit_id)->pluck('id')->toArray();
        $agent->brands()->sync($brand_ids);

        // save departments
        if($request->get('department_ids')){
            $agent->departments()->sync($request->get('department_ids'));
        }

        return redirect()->route('admin.employee_agent.edit', $id)->with('success', 'Agent Updated');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
    // agent brand targets
    public function targets($id)
    {
        $agent = $this->agent->find($id);
        $agent_brands = $agent->agent_brands;
        $title = "$agent->name - Brand Targets";
        return view('admin.employee_agent.targets', compact('agent','agent_brands','title'));
    }
    // update brand targets
    public function updateTargets($id, Request $request)
    {
        $agent = $this->agent->find($id);
        foreach($request->target_data as $brand_id => $target_data){
            if($target_data['target']){
                $target_date = Carbon::parse($target_data['date']);
                $m = $target_date->format('m');
                $y = $target_date->format('Y');
                $date = $target_date->toDateTimeString();
                $agent_target = $this->agent_target->where(['agent_id' => $id,'brand_id' => $brand_id])->whereMonth('created_at', '=', $m)->whereYear('created_at', '=', $y)->first();
                $target_data = [
                        'target' => $target_data['target'],
                        'brand_id' => $brand_id,
                        'created_at' => $date
                    ];
                if($agent_target){
                    $agent_target->update($target_data);
                } else {
                    $this->agent_target->create(array_merge([
                        'agent_id' => $id,
                    ], $target_data));
                }
            }
        }
        return redirect()->back()->with('success','Agent Brand Targets Updated Successfully!');
    }
}
