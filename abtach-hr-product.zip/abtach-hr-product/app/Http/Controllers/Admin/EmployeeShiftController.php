<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Employee;
use App\EmployeeShiftTiming;
use App\EmployeeSetting;
use Carbon\Carbon;
use Maatwebsite\Excel\Facades\Excel;

class EmployeeShiftController extends Controller
{
    private $employee;
    private $employee_shift;
    private $employee_setting;
    /**
     * EmployeeShiftController constructor
     */
    public function __construct(Employee $employee, EmployeeShiftTiming $employee_shift,EmployeeSetting $employee_setting)
    {
        $this->employee = $employee;
        $this->employee_shift = $employee_shift;
        $this->employee_setting = $employee_setting;
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $employee_shift = $this->employee_shift->find($id);
        $employee_id = $employee_shift->employee_id;
        if($employee_shift){
            $check_in = Carbon::parse($request->check_in);
            $check_out = Carbon::parse($request->check_out);
            $total_work_hour = $check_out->diffInHours($check_in);
            $check_in = $check_in->format('h:i A');
            $check_out = $check_out->format('h:i A');
            $effective_date = str_replace('/','-', $request->effective_date);
            $created_at_date = Carbon::createFromFormat('d-m-Y', $effective_date)->toDateTimeString();
            $employee_shift->update([
                'check_in' => $check_in,
                'check_out' => $check_out,
                'created_at' => $created_at_date,
                'total_work_hour' => $total_work_hour
            ]);

            $setting = $this->employee_setting->where('employee_id', $employee_id)->first();
            $setting_data = [
                'employee_id' => $employee_id,
                'total_work_hour' => config('app.working_hours'),
                'check_in' => $check_in,
                'check_out' => $check_out,
                'timezone' => config('app.timezone'),
            ];
            if(!$setting){
                $this->employee_setting->create($setting_data);
            } else {
                $setting->update($setting_data);
            }


            if(request()->ajax()){
                return response()->json(['status' => true]); 
            } else {
                return redirect()->back()->with('success', 'updated successfully');
            }
            // if(request('notify_employee')){
            //     Mail::to($employee->email)->cc(config('general.emails.cc_default'))->send(new NotifyEmployeeShift($employee, $employee_shift_timing));
            // }
        } else {
            return response()->json(['status' => false]);
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    public function loadExcel()
    {
        $employees = $this->employee->get();
        foreach($employees as $employee){
            if($employee->shift()) {
                $check_in = $employee->shift()->check_in;
                $check_out = $employee->shift()->check_out;
                $check_in_diff = carbon()->parse($check_in);
                $check_out_diff = carbon()->parse($check_out);
                EmployeeSetting::where('employee_id', $employee->id)->update([
                    'check_in' => $check_in,
                    'check_out' => $check_out,
                    'total_work_hour' => $check_out_diff->diffInHours($check_in_diff)
                ]);
            }
        }
        // $employees = Excel::load('./uploads/shift-timings.xlsx')->get();
        // foreach($employees as $employee) {
        //     $shift_timing = explode('-', $employee->shift_timing);
        //     $data = [
        //         'check_in' => trim($shift_timing[0]),
        //         'check_out' => trim($shift_timing[1]),
        //     ];
        //     $employee_data = $this->employee->where('employee_id', $employee->employee_code)->first();
        //     if($employee_data){
        //         $employee_shift = $this->employee_shift->where('employee_id', $employee_data->id)->orderBy('created_at','desc')->first();
        //         if($employee_shift){
        //             $employee_shift->update($data);
        //         } else {
        //             $this->employee_shift->create(array_merge([
        //                 'employee_id' => $employee_data->id,
        //                 'created_at' => $employee_data->created_at
        //             ], $data));
        //         }
        //     }
        // }
    }
}
