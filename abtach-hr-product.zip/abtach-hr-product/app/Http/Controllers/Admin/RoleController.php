<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Role;

class RoleController extends Controller
{
    /**
     * @var Role
     */
    private $role;
    /**
     * Constructor
     * @var Role $role
     */
    public function __construct(Role $role)
    {
        $this->role = $role;
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $title = 'Roles';
        $roles = $this->role->paginate(20);
        return view('admin.role.index',compact('title', 'roles'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $title = 'Create Role';
        $permission_routes = config('role_permissions');
        return view('admin.role.create', compact('title','permission_routes'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate_rules();
        $data = [
            'name' => $request->input('name'),
            'permissions' => json_encode($request->input('permissions')),
        ];
        $role = $this->role->create($data);
        return $role;
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $role = $this->role->find($id);
        $title = 'Edit Role - '.$role->name; 
        $permission_routes = config('role_permissions');
        return view('admin.role.edit', compact('title', 'role','permission_routes'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $this->validate_rules([],$id);
        $role = $this->role->find($id);
        $data = [
            'name' => $request->input('name'),
            'permissions' => json_encode($request->input('permissions')),
        ];
        $role->update($data);
        return redirect()->route('admin.role.index')->with('success', 'Role Updated');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    /**
     * validation
     */
    public function validate_rules($rules=[], $id=null)
    {
        $request = request();
        return $this->validate($request, array_merge([
            'name' => 'required|unique:roles'. (($id) ? ',name,'.$id : '')
        ], $rules));
    }
}
