<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\EmployeeAttendance;
use App\Employee;
use Maatwebsite\Excel\Facades\Excel;

class AttendanceReportController extends Controller
{
    /**
     * @var Employee
     */
    private $employee;
    /**
     * @var EmployeeAttendance
     */
    private $employee_attendance;
    /**
     * EmployeeController constructor.
     * @param $employee Employee
     * @param $employee_attendance EmployeeAttendance
    */
    public function __construct(Employee $employee, EmployeeAttendance $employee_attendance)
    {
        $this->employee = $employee;
        $this->employee_attendance = $employee_attendance;
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $employees_query = $this->employee->where('current_status','!=','Offered');
        $employees_list = $employees_query->pluck('full_name','id')->toArray();
        if(request('employee_id')){
            $employees_query = $employees_query->where('id', request('employee_id'));
        }
        $title = 'Employees - Attendance Report';
        $requested_date = (request('date')) ? carbon()->createFromFormat('d/m/Y',request('date'))->format('d-m-Y') : carbon()->now()->format('d-m-Y');
        // if(request('export_excel')){
        //     $this->export_excel($employees_query->get(), $requested_date);
        // }
        if(request('current_status')){
            $employees = $employees_query->whereCurrentStatus(request('current_status'));
        } else {
            $employees = $employees_query->active();
        }
        $employees = $employees_query->paginate(20);
        return view('admin.attendance_report.index', compact('employees','title','requested_date','employees_list'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    // export excel
    // public function export_excel($employees, $requested_date)
    // {
    //     return Excel::create('Abtach-Employee-attendance-report-'.$requested_date, function($excel) use ($employees, $requested_date) {
    //         $excel->sheet('All Employees Attendances', function($sheet) use ($employees, $requested_date)
    //         {
    //             // style headers
    //             $sheet->cell('A1:I1', function($cell) {
    //                 $cell->setBackground('#000');
    //                 $cell->setFontColor('#ffffff');
    //                 $cell->setFontWeight('bold');
    //             });
    //             // set headers
    //             $sheet->setCellValue('A1', 'Date');
    //             $sheet->setCellValue('B1', 'Employee');
    //             $sheet->setCellValue('C1', 'Employee Manager');
    //             $sheet->setCellValue('D1', 'Shift Time');
    //             $sheet->setCellValue('E1', 'Check In');
    //             $sheet->setCellValue('F1', 'Check Out');
    //             $sheet->setCellValue('G1', 'Working Hours');
    //             $sheet->setCellValue('H1', 'Late Hours');
    //             if ($employees->count()) {
    //                 $i = 2;
    //                 foreach ($employees as $employee) {
    //                     $i= $i+1;
    //                     $sheet->cell('A'.$i, $requested_date); 
    //                     $sheet->cell('B'.$i, $employee->full_name.' -- Code: ('.$employee->employee_id.')'); 
    //                     $sheet->cell('C'.$i, ($employee->manager_employee) ? $employee->manager_employee->full_name : ''); 
    //                     if($employee->shift()) {
    //                         $sheet->cell('D'.$i, $employee->shift_time($requested_date)); 
    //                     } else {
    //                         $sheet->cell('D'.$i, ''); 
    //                     }
    //                     $sheet->cell('E'.$i, $employee->check_in_for($requested_date)); 
    //                     $sheet->cell('F'.$i, $employee->check_out_for($requested_date)); 
    //                     $sheet->cell('G'.$i, $employee->working_hours_for($requested_date));
    //                     $sheet->cell('H'.$i, $employee->late_hours_for($requested_date)); 
    //                 }
    //             }
    //             // $sheet->fromArray($excel_data);
    //         });
    //     })->download('xls');
    // }

    // export full report
    public function exportFullReport()
    {
        if(request('current_status')) {
            $employees = $this->employee->whereCurrentStatus(request('current_status'));
        } else {
            $employees = $this->employee->whereNotIn('current_status',['Separation','Offered']);
        }
        $employees = $employees->get();
        Excel::create('Abtach-Employees-attendance-report-'.date('d-F-Y'), function($excel) use ($employees) {
            foreach($employees as $employee) {
                // each employee sheet
                $excel->sheet(substr($employee->full_name,0 ,30), function($sheet) use ($employee)
                {
                    // style headers
                    $sheet->cell('A1:M1', function($cell) {
                        $cell->setBackground('#000');
                        $cell->setFontColor('#ffffff');
                        $cell->setFontWeight('bold');
                    });
                    // set headers
                    $sheet->setCellValue('A1', 'Date');
                    $sheet->setCellValue('B1', 'Employee');
                    $sheet->setCellValue('C1', 'Employee Code');
                    $sheet->setCellValue('D1', 'Employee Designation');
                    $sheet->setCellValue('E1', 'Employee Manager');
                    $sheet->setCellValue('F1', 'Shift Time');
                    $sheet->setCellValue('G1', 'Check In');
                    $sheet->setCellValue('H1', 'Check Out');
                    $sheet->setCellValue('I1', 'Working Hours');
                    $sheet->setCellValue('J1', 'Late Hours');
                    $sheet->setCellValue('K1', 'Actual Status');
                    // $sheet->setCellValue('K1', 'Late');
                    // $sheet->setCellValue('L1', 'Half-day');
                    // $sheet->setCellValue('M1', 'Absent');
                    // employee attendance
                    $month = request('month') ? request('month') : carbon()->now()->format('m-Y');
                    $period_interval = period_interval(carbon()->parse('26-'.$month)->subMonths(1));
                    $i = 2;
                    foreach($period_interval as $day) {
                        $current_attendance = new \App\Employee\Attendance($employee, $day->format('Y-m-d'));
                        $i= $i+1;
                        $sheet->cell('A'.$i, $day->format('l d M Y')); 
                        $sheet->cell('B'.$i, $employee->full_name); 
                        $sheet->cell('C'.$i, $employee->employee_id); 
                        $sheet->cell('D'.$i, $employee->designation); 
                        $sheet->cell('E'.$i, ($employee->manager_employee) ? $employee->manager_employee->full_name : ''); 
                        if($current_attendance->shift) {
                            $sheet->cell('F'.$i, $current_attendance->shift->check_in.' - '.$current_attendance->shift->check_out); 
                        } else {
                            $sheet->cell('F'.$i, ''); 
                        }
                        $sheet->cell('G'.$i, $current_attendance->check_in); 
                        $sheet->cell('H'.$i, $current_attendance->check_out); 
                        $sheet->cell('I'.$i, $current_attendance->working_hours);
                        $sheet->cell('J'.$i, $current_attendance->late_hours); 
                        $sheet->cell('K'.$i, $current_attendance->actual_status()); 
                        // $sheet->cell('J'.$i, function($cell) use($current_attendance) {
                        //     if($current_attendance->check_in_status == 'late') {
                        //             $cell->setFontColor('#f44336');
                        //     } elseif($current_attendance->check_in_status == 'early'){
                        //             $cell->setFontColor('#4CAF50');
                        //     }
                        // });

                        // $sheet->cell('K'.$i, ($current_attendance->check_in_status == 'late') ? 'Yes' : '');
                        // $sheet->cell('K'.$i, function($cell) use($current_attendance) {
                        //     $cell->setFontColor('#f44336');
                        //     $cell->setFont([
                        //         'bold' => true
                        //     ]);
                        // }); 
                        // $sheet->cell('L'.$i, ($current_attendance->is_half_day()) ? 'Yes' : '');
                        // $sheet->cell('L'.$i, function($cell) use($current_attendance) {
                        //     $cell->setFontColor('#F0AD4E');
                        //     $cell->setFont([
                        //         'bold' => true
                        //     ]);
                        // }); 
                        // $sheet->cell('M'.$i, ($current_attendance->is_absent()) ? 'Yes' : '');
                        // $sheet->cell('M'.$i, function($cell) use($current_attendance) {
                        //     $cell->setFontColor('#000');
                        //     $cell->setFont([
                        //         'bold' => true
                        //     ]);
                        // });
                    }
                    // $sheet->fromArray($excel_data);
                });
            }
        })->download('xls');
        return redirect()->route('admin.attendance_report.index')->with('success','Exported Successfully!');
    }
}
