<?php

namespace App\Http\Controllers\Admin\Setting;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\EmailTemplate;

class EmailTemplateController extends Controller
{
    /**
     * constructor
     */
    public function __construct(EmailTemplate $email_template)
    {
        $this->email_template = $email_template;
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $email_templates = $this->email_template->paginate(20);
        $title = 'Email Templates';
        return view('admin.setting.email_template.index', compact('title', 'email_templates'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $email_template = $this->email_template->find($id);
        $title = 'Edit Email Template';
        return view('admin.setting.email_template.edit', compact('title', 'email_template'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $this->validate($request, [
            'content' => 'required'
        ]);
        $email_template = $this->email_template->find($id);
        $data = [
            'content' => htmlspecialchars($request->content)
        ];
        $email_template->update($data);
        return redirect()->route('admin.setting.email_template.index')->with('success', 'Email Template Updated!');

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
