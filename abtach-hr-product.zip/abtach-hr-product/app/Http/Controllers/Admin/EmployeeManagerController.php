<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Employee;
use App\EmployeeManager;
use Illuminate\Support\Facades\Mail;
use App\Mail\NotifyEmployeeReporting;

class EmployeeManagerController extends Controller
{
    /**
     * @var Employee
     */
    private $employee;
    /**
     * @var EmployeeManager
     */
    private $employee_manager;
    /**
     * Constructor
     * @var Employee $employee
     */
    public function __construct(Employee $employee, EmployeeManager $employee_manager)
    {
        $this->employee = $employee;
        $this->employee_manager = $employee_manager;
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index($employee_id)
    {
        $employee = $this->employee->find($employee_id);
        if($employee){
            $title = 'Reporting Authorities - '.$employee->full_name;
            $managers = $this->employee->where('is_manager', 1)->orderBy('employee_id', 'ASC')->pluck('full_name', 'id')->toArray();
            $employee_managers = $employee->managers()->orderBy('id','desc')->get();
            return view('admin.employee.manager',compact('title','employee','managers','employee_managers'));
        } else {
            return back();
        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store($employee_id, Request $request)
    {
        $employee = $this->employee->find($employee_id);
        $cc_emails = [config('general.emails.salmanyousuf'),config('general.emails.cc_default')];
        if($employee->manager_employee) {
            $cc_emails[] = $employee->manager_employee->email;
        }
        
        if($employee){
            $previous_employee_manager = $this->employee_manager->first();
            if(!$previous_employee_manager) {
                // create old assignment if not exist
                $old_manager = [
                    'manager_id' => $employee->manager_id,
                    'employee_id' => $employee_id,
                    'created_at' => $employee->created_at
                ];
                $this->employee_manager->create($old_manager);
            }
            // create new assignment
            $effective_date = \Carbon\Carbon::createFromFormat('d/m/Y',request('created_at'))->toDateTimeString();
            $new_manager_data = [
                'manager_id' => $request->manager_id,
                'employee_id' => $employee_id,
                'created_at' => $effective_date
            ];
            $employee_manager = $this->employee_manager->create($new_manager_data);
            // update employee
            $employee->manager_id = $employee_manager->manager_id;
            $employee->save();
            // notify employee if requested
            if(request('notify_employee') && $employee->email){
                $cc_emails[] = $employee_manager->manager->email;
                Mail::to($employee->email)->cc(array_unique($cc_emails))->send(new NotifyEmployeeReporting($employee, $employee_manager));
            }
            return redirect()->back()->with('success', 'Reporting authority changed successfully!');
        } else {
            return back();
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
