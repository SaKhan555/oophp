<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\JobCategory;
class JobCategoryController extends Controller
{
    /**
     * @var job
     */
    private $job_category;

    /**
     * JobController constructor.
     * @param JobCategory $job_category
     */
    public function __construct(JobCategory $job_category)
    {
        $this->job_category = $job_category;
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $title = 'Job Categories';
        $job_categories = $this->job_category->paginate(20);
        return view('admin.job_category.index',  compact('title', 'job_categories'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $title = 'Add New Job Category';
        return view('admin.job_category.create',  compact('title'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request, $this->validation_rules());
        $data = [
            'title' => $request->title,
            'slug' => str_slug($request->title,'-'),
            'icon' => null,
            'description' => htmlspecialchars($request->description),
            'status' => $request->status || 0,
        ];
        $this->job_category->create($data);
        return redirect()->route('admin.job-category.index')->with('success', 'Job Category Created Successfully');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $title = 'Edit Job';
        $job_category = $this->job_category->find($id);
        return view('admin.job_category.edit',  compact('title','job_category'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $this->validate($request, $this->validation_rules([], $id));
        $data = [
            'title' => $request->title,
            'description' => htmlspecialchars($request->description),
            'icon' => null,
            'status' => $request->status || 0,
        ];
        
        $this->job_category->find($id)->update($data);
        return redirect()->route('admin.job-category.index')->with('success', 'Job Category Updated Successfully');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
    /**
     * Update Status
     */
    public function status(Request $request, $id)
    {
        $job_category = $this->job_category->find($id);

        $newStatus = ($job_category->status == 1) ? 0 : 1;

        $job_category->update(['status'=>$newStatus]);

        if($request->ajax()){
            return response()->json(['updated' => true, 'status' => $newStatus]);
        }

        return redirect()->route('admin.job-category.index');
    }
    /**
     * Validation rules
     */
    public function validation_rules($rules = [], $id=null) 
    {
        return array_merge([
            'title' => 'required|unique:job_categories'. (($id) ? ',title,'.$id : ''),
        ], $rules);
    }
}
