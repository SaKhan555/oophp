<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Employee;
use App\EmployeeAsset;
use App\AssetCategory;

class EmployeeAssetController extends Controller
{
    protected $asset;
    protected $employee;
    protected $asset_category;
    /**
     * constructor
     */
    public function __construct(EmployeeAsset $asset, Employee $employee, AssetCategory $asset_category)
    {
        $this->asset = $asset;
        $this->employee = $employee;
        $this->asset_category = $asset_category;
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index($employee_id)
    {
        $title = 'Employee Assets';
        $employee = $this->employee->find($employee_id);
        $asset_categories = $this->asset_category->list();
        $assets = $employee->assets;
        return view('admin.employee_asset.index', compact('title', 'assets', 'employee', 'asset_categories'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request, $employee_id)
    {
        $this->validate_rules($request);
        $employee = $this->employee->find($employee_id);
        // update available assets
        if(isset($request->category_id['update']) && count($request->category_id['update'])){
            foreach ($request->category_id['update'] as $key => $value) {
                $asset = $employee->assets()->find($key);
                if($asset){
                    $data = [
                        'category_id' => $value,
                        'title' => $request->title['update'][$key],
                        'quantity' => $request->quantity['update'][$key],
                        'effective_date' => carbon()->createFromFormat('d/m/Y', $request->effective_date['update'][$key]),
                        'return_date' => ($request->return_date['update'][$key]) ? carbon()->createFromFormat('d/m/Y', $request->return_date['update'][$key]) : null,
                    ];
                    $asset->update($data);
                }
            }
        }
        // create new assets
        if(isset($request->category_id['new']) && count($request->category_id['new'])){
            foreach ($request->category_id['new'] as $key => $value) {
                if($request->title['new'][$key]){
                    $data = [
                        'employee_id' => $employee_id,
                        'category_id' => $value,
                        'title' => $request->title['new'][$key],
                        'quantity' => $request->quantity['new'][$key],
                        'effective_date' => carbon()->createFromFormat('Y-m-d', $request->effective_date['new'][$key]),
                        'return_date' => ($request->return_date['new'][$key]) ? carbon()->createFromFormat('Y-m-d', $request->return_date['new'][$key]) : null,
                    ];
                    $this->asset->create($data);
                }
            }
        }
        return redirect()->route('admin.employee.asset.index', $employee_id)->with('success', 'Assets Updated');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($employee_id, $id)
    {
        $employee = $this->employee->find($employee_id);
        $asset = $employee->assets()->find($id);
        $assets = $employee->assets;
        $asset_categories = $this->asset_category->list();
        $title = 'Edit Asset';
        return view('admin.employee_asset.edit', compact('title', 'asset','employee', 'assets', 'asset_categories'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $employee_id, $id)
    {
        $this->validate_rules($request);
        $asset = $this->asset->where('employee_id', $employee_id)->find($id);
        $data = [
            'title' => $request->title,
            'category_id' => $request->category_id,
            'effective_date' => carbon()->createFromFormat('d/m/Y', $request->effective_date),
            'return_date' => ($request->return_date) ? carbon()->createFromFormat('d/m/Y', $request->return_date) : null,
        ];
        $asset->update($data);
        return redirect()->route('admin.employee.asset.index', $employee_id)->with('success', 'Asset Updated');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
    /**
     * validate rules
     */
    public function validate_rules($request)
    {
        return $this->validate($request, [
            'title' => 'required',
            'effective_date' => 'required',
        ]);
    }
}
