<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Storage;

class AttachmentController extends Controller
{
    public function index($path, $filename)
    {
    	$contents = Storage::get("$path/$filename");
    	$ext = pathinfo(storage_path()."$path/$filename", PATHINFO_EXTENSION);
        return response($contents)
            ->header('Content-Type', $ext)
            ->header('Cache-control', 'public');
    }
}
