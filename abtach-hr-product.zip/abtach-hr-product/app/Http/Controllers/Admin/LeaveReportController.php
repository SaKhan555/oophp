<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Employee;
use App\EmployeeLeaveApplication;

class LeaveReportController extends Controller
{
    /**
     * @var EmployeeLeaveApplication
     */
    private $leave_application;
    /**
     * @var Employee
     */
    private $employee;
    /**
     * ExpenseController constructor.
     * @param EmployeeLeaveApplication $employee_leave_application
     */
    public function __construct(Employee $employee,EmployeeLeaveApplication $leave_application)
    {
        $this->employee = $employee;
        $this->leave_application = $leave_application;
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $employees = $this->employee->search()->active()->paginate(20);
        $title = 'Employee Leave Reports';
        return view('admin.leave_report.index', compact('title', 'employees'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($employee_id)
    {
        $employee = $this->employee->find($employee_id);
        if($employee) {
            return view('admin.leave_report.show', compact('title' ,'employee'));
        } else {
            return redirect()->back()->with('error', 'Employee not found');
        }
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
