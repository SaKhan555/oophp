<?php

namespace App\Http\Controllers\Admin;

use App\Employee;
use App\Mail\EmployeePayslip;
use App\PaymentHistory;
use Barryvdh\DomPDF\PDF;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Storage;
use Maatwebsite\Excel\Facades\Excel;
use App\Http\Controllers\Controller;

class PaymentController extends Controller
{

    /**
     * @var PDF
     */
    private $PDF;
    /**
     * @var PaymentHistory
     */
    private $paymentHistory;
    /**
     * @var Employee
     */
    private $employee;

    /**
     * PaymentController constructor.
     * @param PDF $PDF
     * @param PaymentHistory $paymentHistory
     * @param Employee $employee
     */
    public function __construct(PDF $PDF, PaymentHistory $paymentHistory, Employee $employee)
    {
        $this->PDF = $PDF;
        $this->paymentHistory = $paymentHistory;
        $this->employee = $employee;
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $title = 'Salary Slips';
        $paymentHistory = $this->paymentHistory->query();
        $paymentNotify = $this->paymentHistory->where('notify', 1)->count();

        if(request('type') == 'trashed'){
//      $employees = $employees->onlyTrashed();
        }

        $payments = $paymentHistory->search()->orderBy('salary_month', 'DESC')->orderBy('employee_code', 'ASC')->paginate((request('per_page')) ? request('per_page') : 20 );
        return view('admin.payslip.index',  compact('title', 'payments', 'paymentNotify'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    public function uploadExcel()
    {
        $title =  'Upload Salary Slip';
        return view('admin.payslip.upload', compact('title'));
    }

    public function uploadExcelSave(Request $request)
    {

        $this->validate($request, ['excel_file' => 'required']);

        if (request()->hasFile('excel_file'))
        {
            $path = request()->file('excel_file')->getRealPath();

            $data = Excel::load($path)->get();
			
			$month = request('salary_month');
			$year = request('salary_year');
			$date = '1-'.$month.'-'.$year;
			$salary_date = Carbon::parse($date)->lastOfMonth();
            foreach ($data as $salary){
                $employee = null;
                if($salary['emp.']){
                    $employee_code = $salary['emp.'];
                    $employee = $this->employee->where('employee_id', $salary['emp.'])->first();
                    /*if($employee){
                        $updatedEmployee = $employee->update([
                            'national_identity' => $salary['cnic'],
                            'join_date' => ($salary['doj']) ? Carbon::parse($salary['doj'])->toDateTimeString() : null,
                            'designation' => $salary['designation'],
                            'department' =>  $salary['department'],
                            'salary' =>  $salary['actual_total'],
                            'bank_details' => [
                                'name' =>  $salary['bank'],
                                'account_number' =>  $salary['pay_through'],
                                'branch' =>  $salary['branch'],
                            ],
                        ]);

                    } */



                    $checkSalary = $this->paymentHistory->where('employee_code', $employee_code)->whereYear('salary_month', '=', $year)
                        ->whereMonth('salary_month', '=', $month)->first();
					$per_day = ( $salary['actual_total'] / $salary['month_days'] );
                    $salaryData = [
                        'employee_id' => (isset($employee->id)) ? $employee->id : null,
                        'employee_code' => $employee_code,
                        'salary_month' => $salary_date,
                        'actual' => [
                            'actual_basic' => number_format($salary['actual_basic']),
                            'actual_h_rent' => number_format($salary['actual_h_rent']),
                            'actual_medical' => number_format($salary['actual_medical']),
                            'actual_cola' => number_format($salary['actual_cola']),
                            'actual_special' => number_format($salary['actual_special']),
                            'actual_total' => number_format($salary['actual_total']),
                        ],
                        'earning' => [
                            'earning_basic' => number_format($salary['earning_basic']),
                            'earning_h_rent' => number_format($salary['earning_h_rent']),
                            'earning_medical' => number_format($salary['earning_medical']),
                            'earning_cola' => number_format($salary['earning_cola']),
                            'earning_special' => number_format($salary['earning_special']),
                            'earning_compensation' => number_format($salary['earning_compensation']),
                            'earning_arrears' => number_format($salary['earning_arrears']),
                            'earning_total' => number_format($salary['earning_total']),
                        ],
                        'deduction' => [
                            'deduction_income_tax' => number_format($salary['deduction_income_tax']),
                            'deduction_eobi' => number_format($salary['deduction_eobi']),
                            'deduction_salary_advance' => number_format($salary['deduction_salary_advance']),
                            'deduction_loan' => number_format($salary['deduction_loan']),
                            'deduction_other' => (isset($salary['deduction_other'])) ? number_format($salary['deduction_other']) : 0,
                            'deduction_total' => number_format($salary['deduction_total']),
                        ],
                        'employee_detail' => [
                            'name' => $employee->full_name,
                            'code' =>  $employee->employee_id,
                            'email' =>  (isset($employee->email)) ? $employee->email : null,
                            'doj' => Carbon::parse($employee->join_date)->format('d-m-Y'),
                            'cnic' => $employee->national_identity,
                            'designation' => $employee->designation,
                            'department' => $employee->department,
                        ],
                        'bank_detail' => [
                            'bank' => $salary['bank'],
                            'branch' => $salary['branch'],
                            'pay_through' => $salary['pay_through'],
                        ],
                        'month_days' => $salary['month_days'],
                        'earning_days' => $salary['earning_days'],
                        'absent_days' => ($salary['month_days']-$salary['earning_days']),
						'late_days' => (isset($salary['late_days'])) ? $salary['late_days'] : null,
                        'rate_per_day' => number_format(round($per_day, 2)),
                        'net_salary' => number_format($salary['net_salary']),
                        'payslip' => null,
                        'email_exit' => (isset($employee->email)) ? 1 : 0,
                        'status' => 0,
                        'notify' => 0,
                    ];


                    if(!$checkSalary){
                       $this->paymentHistory->create($salaryData);
                    } 
                }
            }
            return redirect()->route('admin.payslip.index')->with('success', 'Salary Slip Uploaded Successfully!');
        }
        return redirect()->route('admin.payslip.index')->with('success'. 'Salary Slip Upload Error!');

    }

    public function generate()
    {
        if(request('generate') == 'enable'){
            cache()->forever('generate_pdf', 'enable');
            return redirect()->route('admin.payslip.index')->with('success', 'Salary Slip System Enable Successfully!');

        } elseif(request('generate') == 'disable') {
            cache()->forever('generate_pdf', 'disable');
            return redirect()->route('admin.payslip.index')->with('error', 'Salary Slip System Disable Successfully!');
        }

        $paymentHistory = $this->paymentHistory->with('employee')->where('status', 0)->first();
        if(cache('generate_pdf') == 'enable' && $paymentHistory){
            $salary_slip = $paymentHistory;
            /* foreach ($salary_slip as $salary_slip){ */
            $pdf = $this->PDF->loadView('admin.payslip.generate', ['salary_slip' => $salary_slip]);
            $salary_month = Carbon::parse($salary_slip->salary_month)->format('M-Y');
            $salary_generated = 'Salary-E-'.$salary_slip->employee_detail['code'].'-'.$salary_month.'.pdf';
            //  Storage::disk('payslip')->delete($salary_generated);
            if (\File::exists('uploads/payslip/'.$salary_generated)) {
                \File::delete('uploads/payslip/'.$salary_generated);
            }
            $pdf->save('uploads/payslip/' . $salary_generated);
            $salary_find = $this->paymentHistory->find($salary_slip->id);
            $updated_salary1 = $salary_find->update(['payslip' => $salary_generated]);

            if($salary_slip->email_exit == 1){
                $employee_email = (isset($salary_slip->employee->email)) ? $salary_slip->employee->email : null;
                if($employee_email){
                    $updated_salary2 = $salary_find->update(['notify'=>1]);
                   Mail::to(trim($employee_email))->send(new EmployeePayslip($salary_slip, $salary_generated));
                }

            }

            $updated_salary3 = $salary_find->update(['status'=>1]);

            /* } */
            return response()->json(['status' => 'enable', 'message'=>'Salary Slip Sent Successfully!']);




        } else {
            cache()->forever('generate_pdf', 'disable');
			return response()->json(['status' => 'disable', 'message'=>'Salary Slip Not Available!']);
        }
    }
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $payment = $this->paymentHistory->find($id);
        $title = 'Employee Salary #'.$payment->employee_code;
        return view('admin.payslip.show', compact('title', 'payment'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $salary_slip = $this->paymentHistory->with('employee')->find($id);
        $title = 'Edit Payslip';

        if(request('type') == 'email'){
            if($salary_slip->payslip){
                $employee_email = $salary_slip->employee->email;
                if($employee_email){
                    Mail::to($employee_email)->send(new EmployeePayslip($salary_slip, $salary_slip->payslip));
                    $updated_salary2 = $salary_slip->update(['notify'=>1]);
                }
                return redirect()->back()->with('success', 'Salary Slip Sent Successfully!');
            } else {
				
				/* foreach ($salary_slip as $salary_slip){ */
				$pdf = $this->PDF->loadView('admin.payslip.generate', ['salary_slip' => $salary_slip]);
				$salary_month = Carbon::parse($salary_slip->salary_month)->format('M-Y');
				$salary_generated = 'Salary-E-'.$salary_slip->employee_detail['code'].'-'.$salary_month.'.pdf';
				//  Storage::disk('payslip')->delete($salary_generated);
				if (\File::exists('uploads/payslip/'.$salary_generated)) {
					\File::delete('uploads/payslip/'.$salary_generated);
				}
				$pdf->save('uploads/payslip/' . $salary_generated);
				$employee_email = $salary_slip->employee->email;
				$updated_salary1 = $salary_slip->update(['payslip' => $salary_generated, 'notify' => 1]);
				if($employee_email){
                    Mail::to($employee_email)->send(new EmployeePayslip($salary_slip, $salary_generated));
                    $updated_salary2 = $salary_slip->update(['notify'=>1]);
                }
                return redirect()->back()->with('success', 'Salary Slip Sent Successfully!');
			}
            return redirect()->back()->with('error', 'Salary Slip Send Error!');
        } else {

            return view('admin.payslip.edit', compact('salary_slip', 'title'));
        }

    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
