<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Employee;

class EmployeePictureController extends Controller
{
    protected $employee;

    /**
     * constructor
     */
    public function __construct(Employee $employee)
    {
        $this->employee = $employee;
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request, $employee_id)
    {
        $this->validate_rules($request);
        $employee = $this->employee->find($employee_id);
        $file_name = $employee->photo;
        if($request->hasFile('photo')){
            $old_file_path = public_path().'/uploads/employee/avatars/'.$file_name;
            if($file_name && file_exists($old_file_path)){
                unlink($old_file_path);
            }
            $file = $request->file('photo');
            $file_name = $employee->employee_id.'.'.$file->getClientOriginalExtension();
            $file->move('uploads/employee/avatars' , $file_name);  
            $employee->update([
                'photo' => $file_name
            ]);
        }
        return redirect()->back()->with('success', 'Profile Picture Updated');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    /**
     * validate picture rules
     */
    public function validate_rules($request)
    {
        return $this->validate($request, [
            'photo' => 'required|dimensions:min_width=100,min_height=100|mimes:png,jpeg,jpg,gif'
        ]);
    }
}
