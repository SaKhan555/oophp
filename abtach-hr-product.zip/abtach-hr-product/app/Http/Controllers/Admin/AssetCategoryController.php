<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\AssetCategory;

class AssetCategoryController extends Controller
{
    protected $asset_category;
    /**
     * cosntructore
     */
    public function __construct(AssetCategory $asset_category)
    {
        $this->asset_category = $asset_category;
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $title = 'Assets';
        $assets = $this->asset_category->get();
        return view('admin.asset_category.index', compact('title', 'assets'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $title = 'Create Asset Category';
        return view('admin.asset_category.create', compact('title'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate_rules($request);
        $data = [
            'name' => $request->name,
        ];
        $this->asset_category->create($data);
        return redirect()->route('admin.asset_category.index')->with('success', 'Asset Added');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $asset = $this->asset_category->find($id);
        $title = 'Edit Asset Category';
        return view('admin.asset_category.edit', compact('title', 'asset'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $this->validate_rules($request);
        $asset = $this->asset_category->find($id);
        $data = [
            'name' => $request->name,
        ];
        $asset->update($data);
        return redirect()->route('admin.asset_category.index')->with('success', 'Asset Updated');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
    /**
     * validate rules
     */
    public function validate_rules($request)
    {
        return $this->validate($request, [
            'name' => 'required',
        ]);
    }
}
