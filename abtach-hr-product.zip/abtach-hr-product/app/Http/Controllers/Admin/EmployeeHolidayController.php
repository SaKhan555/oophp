<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\EmployeeHoliday;

class EmployeeHolidayController extends Controller
{
    /**
     * @var EmployeeHoliday
     */
    private $holiday;
    /**
     * Constructor
     * @var Employee $employee
     */
    public function __construct(EmployeeHoliday $holiday)
    {
        $this->holiday = $holiday;
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $holidays = $this->holiday->paginate(20);
        $title = 'Employee Holidays';
        return view('admin.employee_holiday.index', compact('title', 'holidays'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $title = 'Add New Holiday';
        return view('admin.employee_holiday.create', compact('title'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate_rules($request);
        $data = [
            'title' => $request->title,
            'date' => carbon()->createFromFormat('d/m/Y',$request->date)->format('Y-m-d')
        ];
        $this->holiday->create($data);
        return redirect()->route('admin.employee_holiday.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $holiday = $this->holiday->find($id);
        $title = "Edit Holiday - ".$holiday->title;
        return view('admin.employee_holiday.edit', compact('title', 'holiday'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $this->validate_rules($request,[], $id);
        $holiday = $this->holiday->find($id);
        $data = [
            'title' => $request->title,
            'date' => carbon()->createFromFormat('d/m/Y',$request->date)->format('Y-m-d')
        ];
        $holiday->update($data);
        return redirect()->back()->with('success', 'Holiday updated!');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $this->holiday->destroy($id);
        if (request()->ajax()) {
            return response()->json(['success' => true]);
        }
        return redirect()->back()->with('success','Deleted Successfully');
    }
    /**
     * validate rules
     */
    public function validate_rules($request, $rules=[],$id=null)
    {
        return $this->validate($request, array_merge([
            'title' => 'required|unique:employee_holidays'. (($id) ? ',title,'.$id : ''),
            'date' => 'required|unique:employee_holidays'. (($id) ? ',date,'.$id : ''),
        ], $rules));
    }
}
