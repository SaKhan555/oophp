<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Letter;
use App\Employee;
use App\EmployeeLetter;
use File;
use Barryvdh\DomPDF\PDF;
use Riskihajar\Terbilang\Facades\Terbilang;
use Illuminate\Support\Facades\Mail;
use App\Mail\EmployeeOfferLetterEmail;

class EmployeeLetterController extends Controller
{
    /**
     * @var EmployeeLetter
     */
    private $employee_letter;
    /**
     * @var Employee
     */
    private $employee;
    /**
     * @var Letter
     */
    private $letter;
    /**
     * @var PDF
     */
    private $PDF;
    /**
     * Constructor
     * @param Employee $employee
     */
    public function __construct(Employee $employee, Letter $letter, EmployeeLetter $employee_letter, PDF $PDF)
    {
        $this->employee = $employee;
        $this->letter = $letter;
        $this->employee_letter = $employee_letter;
        $this->PDF = $PDF;
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $title = 'Generate Letter';
        $employees = $this->employee->select('id', \DB::raw("CONCAT(full_name,' ',father_name) as full_name"))->pluck('full_name','id')->toArray();
        $letters = $this->letter->pluck('name','id')->toArray();
        return view('admin.employee_generate_letter.create',compact('title','employees','letters'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request, [
            'letter_id' => 'required|numeric',
            'employee_id' => 'required|numeric'
        ]);
        // save generated letter to database
        if(isset($request['generate_save'])){
            $employee_letter_data = [
                'letter_id' => $request->letter_id,
                'employee_id' => $request->employee_id
            ];
            $employee_letter = $this->employee_letter->create($employee_letter_data);
            $employee_letter->filename = $employee_letter->id.'.pdf';
            $employee_letter->save();

            return redirect()->route('admin.employee.generate_letter',[$request->employee_id, $request->letter_id,'save' => true,'employee_letter_id' => $employee_letter->id,'period' => request('period')]);
        }
        // generate letter
        return redirect()->route('admin.employee.generate_letter',[$request->employee_id, $request->letter_id,'period' => request('period')]);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $employee_letter = $this->employee_letter->find($id);

        if(File::exists('uploads/letters/'.$employee_letter->filename)){
            File::delete('uploads/letters/'.$employee_letter->filename);
        }

        $employee_letter->delete();

        if (request()->ajax()) {
            return response()->json(['success' => true]);
        }

        return redirect()->back()->withSuccess('Deleted Successfully');
    }
    /**
     * send letter
     */
    public function showSendForm()
    {
        $title = 'Send Offer Letter';
        return view('admin.employee_generate_letter.send',compact('title'));
    }
    /**
     * send letter
     */
    public function saveSendForm(Request $request)
    {
        $letter = $this->letter->find(14);
        
        $letterbody = $letter->content;
        $salary = $request->salary;
        //Fields Merage
        $letterbody = str_replace('@date@',date('F d, Y'),$letterbody);
        $letterbody = str_replace('@currentdate@',date('F d, Y'),$letterbody);
        $letterbody = str_replace('@name@',"{$request->first_name} {$request->last_name}",$letterbody);

        $firstname = $request->first_name;
        
        $letterbody = str_replace('@firstname@', $firstname, $letterbody);
        $letterbody = str_replace('@designation@', $request->designation, $letterbody);
        $letterbody = str_replace('@salary@', number_format($request->salary), $letterbody);
        $output = Terbilang::make($request->salary);
        $output = ucwords($output);
        $letterbody = str_replace('@salaryinwords@', $output, $letterbody);
        $letterbody = str_replace('@managername@', $request->manager_name, $letterbody);
        $letterbody = str_replace('@managerdesignation@', $request->manager_designation, $letterbody);
        $letterbody = str_replace('@validtill@', carbon()->now('Asia/Karachi')->addWeeks(1)->format('F, d Y'), $letterbody);
        $pdf = $this->PDF->loadView('admin.employee.letter.index', ['letterbody'=>$letterbody,'output'=>$output]);
        $file_name = "{$request->first_name}-{$request->last_name}-offer-letter.pdf";
        if(request('send_email')){
            $file_url = public_path('/uploads/employee_offer_letters/'.$file_name);
            $pdf->save($file_url);
            Mail::to($request->email)->send(new EmployeeOfferLetterEmail($file_url, $request->all()));
            return redirect()->back()->with('success', 'Offer Letter Send');
        } else {
            return $pdf->stream();
        }
    }
}
