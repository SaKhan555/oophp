<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\EmployeeResignation;
use App\EmployeeResignationReason;

class EmployeeResignationController extends Controller
{
    /**
     * @var EmployeeLeaveApproval
     */
    private $resignation;
    /**
     * @var EmployeeResignationReason
     */
    private $reason;
    /**
     * EmployeeResignationController constructor.
     * @param EmployeeResignation $resignation
     */
    public function __construct(EmployeeResignation $resignation, EmployeeResignationReason $resignation_reason)
    {
        $this->resignation = $resignation;
        $this->resignation_reason = $resignation_reason;
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $resignations = $this->resignation->search()->paginate(20);
        $title = 'Employees Resignations';
        $reasons = $this->resignation_reason->pluck('name', 'id')->toArray();
        return view('admin.employee_resignation.index', compact('title', 'resignations', 'reasons'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $resignation = $this->resignation->find($id);
        $title = $resignation->employee->full_name.' - Resignation';
        return view('admin.employee_resignation.show', compact('resignation', 'title'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $resignation = $this->resignation->find($id);
        if($resignation){
            $resignation->status_comments()->delete();
            $resignation->delete();
            if (request()->ajax()) {
                return response()->json(['success' => true]);
            }
        } else {
            return response()->json(['success' => false]);
        }
    }
}
