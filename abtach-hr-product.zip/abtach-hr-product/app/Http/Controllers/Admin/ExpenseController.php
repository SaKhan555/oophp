<?php

namespace App\Http\Controllers\Admin;

use App\Currency;
use App\Expense;
use App\Unit;
use App\User;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Maatwebsite\Excel\Facades\Excel;
use App\Http\Controllers\Controller;



class ExpenseController extends Controller
{
    /**
     * @var Unit
     */
    private $unit;
    /**
     * @var Currency
     */
    private $currency;
    /**
     * @var Expense
     */
    private $expense;
    /**
     * @var User
     */
    private $user;

    /**
     * ExpenseController constructor.
     * @param Unit $unit
     * @param Currency $currency
     * @param Expense $expense
     * @param User $user
     */
    public function __construct(Unit $unit, Currency $currency, Expense $expense, User $user)
    {
        $this->unit = $unit;
        $this->currency = $currency;
        $this->expense = $expense;
        $this->user = $user;
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $title = 'Expense';
        $expenses = $this->expense->query();

        if(request('type') == 'trashed'){
//            $employees = $employees->onlyTrashed();
        }
        if(request()->has('start_date') && request()->has('end_date')){
            $from = Carbon::parse(request('start_date'))->toDateString();
            $to =  Carbon::parse(request('end_date'))->toDateString();

            if($from != $to){
                $expenses = $expenses->whereBetween('created_at', [$from, $to]);
            } else {
                $expenses = $expenses->whereDate('created_at', '=', $to);
            }

        }

        if(request('type') == 'export'){
            $expenses = $expenses->search()->with(['user', 'unit'])->get();

            //return Stripe::balance()->current();

            Excel::create('Expense Sheet -- '.date('d-F-Y'), function($excel) use($expenses) {
                $excel->sheet('Expense Sheet', function($sheet) use($expenses) {

                    $sheet->row(1, [
                        'Unit',
                        'Transaction Id',
                        'Payment Type',
                        'Payment Mode',
                        'Currency',
                        'Amount',
                        'Head',
                        'Description',
                        'Purchase',
                        'Date',
                    ]);
                    $sheet->row(1, function($row) {
                        $row->setBackground('#000');
                        $row->setFontColor('#ffffff');
                        $row->setFontWeight('bold');
                    });

                    $i = 2;
                    foreach ($expenses as $expense) {
                        $sheet->row($i, array(
                            (isset($expense['unit']['name'])) ? $expense['unit']['name'] : '',
                            $expense['transaction_id'],
                            $expense['payment_type'],
                            $expense['payment_detail'],
                            $expense['currency'],
                            $expense['amount'],
                            $expense['type'],
                            $expense['description'],
                            $expense['purchase'],
                            Carbon::parse($expense['created_at'])->format('d F Y'),
                        ));
                        $i++;
                    }
                });
            })->export('xls');
        } else {
            $users = $this->user->where('type', 'marketing')->pluck('name', 'id')->toArray();
            $expenses = $expenses->search()->with(['user', 'unit'])->latest('updated_at')->paginate((request('per_page')) ? request('per_page') : 20 );
            return view('admin.expense.index',  compact('title', 'expenses', 'users'));
        }

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $title = 'Add Cost / Expense';
        $units = $this->unit->orderBy('name', 'ASC')->pluck('name', 'id')->toArray();
        $currency = $this->currency->pluck('name', 'name')->toArray();
        return view('admin.expense.create',  compact('title', 'units', 'currency'));
    }


    public function uploadExcel()
    {
        $title = 'Upload Expense/Cost';
        return view('admin.expense.upload',  compact('title'));
    }
    public function uploadExcelSave(Request $request)
    {
        $this->validate($request, ['excel_file' => 'required']);
        $payment_type = request('payment_type');
        if (request()->hasFile('excel_file'))
        {
            $path = request()->file('excel_file')->getRealPath();

            $data = Excel::load($path)->get();
            foreach ($data as $expenseData){

                if(isset($expenseData['unit'])){
                    $unit_id = collect(app('units'))->search($expenseData['unit']);
                    $date = Carbon::parse($request->get('date'))->toDateTimeString();
                    $date_foramt = Carbon::parse($request->get('date'))->format('Y-m-d');
                    $type = (isset($expenseData['type'])) ? ucwords($expenseData['type']) : 'Client';
                    $type = (in_array($type, ['Brand', 'Admin', 'Client'])) ? $type : 'Client';
                    if($payment_type == 'boa'){
                        $transaction_id = $expenseData['transaction_id'];

                        $inserData = [
                            "unit_id"=> $unit_id,
                            "transaction_id"=> $transaction_id,
                            "currency"=> $expenseData['currency'],
                            "amount"=> abs($expenseData['amount']),
                            "payment_detail"=> $payment_type,
                            "created_at"=> $date,
                            "type"=> $type,
                            "payment_type"=> $payment_type,
                            "description"=>  $expenseData['description'],
                            "purchase"=> $expenseData['category'],
                            "user_id"=> auth()->id()
                        ];
                        $check = $this->expense->where('transaction_id', $transaction_id)->whereDate('created_at', '=', $date_foramt)->first();
                        if(!$check){
                            $this->expense->create($inserData);
                        }
                    } elseif ($payment_type == 'paypal'){
                        $transaction_id = $expenseData['transaction_id'];
                        $inserData = [
                            "unit_id"=> $unit_id,
                            "transaction_id"=> $transaction_id,
                            "currency"=> $expenseData['currency'],
                            "amount"=> abs($expenseData['net']),
                            "payment_detail"=> $payment_type,
                            "created_at"=> $date,
                            "type"=> $type,
                            "payment_type"=> $payment_type,
                            "description"=>  $expenseData['name'],
                            "purchase"=> $expenseData['item_title'],
                            "user_id"=> auth()->id()
                        ];

                        $check = $this->expense->where('transaction_id', $transaction_id)->whereDate('created_at', '=', $date_foramt)->first();
                        if(!$check){
                            $this->expense->create($inserData);
                        }
                    } elseif ($payment_type == 'credit_card'){
                        $transaction_id = $expenseData['transaction_number'];

                        $inserData = [
                            "unit_id"=> $unit_id,
                            "transaction_id"=> $transaction_id,
                            "currency"=> $expenseData['currency'],
                            "amount"=> abs($expenseData['amount']),
                            "payment_detail"=> $expenseData['bank'].' -- '.$expenseData['card_number'],
                            "created_at"=> $date,
                            "type"=> $type,
                            "payment_type"=> $payment_type,
                            "description"=>  $expenseData['bank'],
                            "purchase"=> $expenseData['description'],
                            "user_id"=> auth()->id()
                        ];

                        $check = $this->expense->where('transaction_id', $transaction_id)->whereDate('created_at', '=', $date_foramt)->first();
                        if(!$check){
                            $this->expense->create($inserData);
                        }
                    } elseif ($payment_type == 'finance') {
                        $transaction_id = $expenseData['code'];
                        $inserData = [
                            "unit_id"=> $unit_id,
                            "transaction_id"=> $transaction_id,
                            "currency"=> 'PKR',
                            "amount"=> abs($expenseData['amount']),
                            "payment_detail"=> $expenseData['mode_of_payment'],
                            "created_at"=> $date,
                            "type"=> 'Admin',
                            "payment_type"=> strtoupper($payment_type),
                            "description"=>  $expenseData['head_of_account'],
                            "purchase"=> $expenseData['details_of_payment'],
                            "user_id"=> auth()->id()
                        ];

                        $check = $this->expense->where('transaction_id', $transaction_id)->whereDate('created_at', '=', $date_foramt)->first();
                        if(!$check){
                            $this->expense->create($inserData);
                        }
                    }
                }


              }

        return redirect()->route('admin.expense.index')->with('success', 'Expense Uploaded Successfully!');
        }
    }
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        request()->merge([
            'created_at'=>Carbon::parse($request->get('created_at'))->toDateTimeString(),
            'user_id'=>auth()->id()
        ]);
        $this->expense->create(request()->except('_token'));
        return redirect()->route('admin.expense.create')->with('success', 'Cost Created Successfully');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $title = 'Edit Cost / Expense #'.$id;
        $units = $this->unit->orderBy('name', 'ASC')->pluck('name', 'id')->toArray();
        $currency = $this->currency->pluck('name', 'name')->toArray();
        $expense = $this->expense->findOrFail($id);
        return view('admin.expense.edit',  compact('title', 'units', 'currency', 'expense'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $expense = $this->expense->findOrFail($id);
        request()->merge([
            'created_at'=>Carbon::parse($request->get('created_at'))->toDateTimeString(),
        ]);
        $expense->update(request()->except('_token'));
        return redirect()->route('admin.expense.index')->with('success', 'Cost Updated Successfully');


    }

    public function destroy($id)
    {
        if (request('type') == 'restore') {
            $this->expense->onlyTrashed()->find($id)->restore();
        } elseif (request('type') == 'forceDelete') {
            $this->expense->onlyTrashed()->find($id)->forceDelete();
        } else{
            $this->expense->find($id)->delete();
        }

        if (request()->ajax()) {
            return response()->json(['success' => true]);
        }

        return redirect()->back()->withSuccess('Deleted Successfully');
    }
}
