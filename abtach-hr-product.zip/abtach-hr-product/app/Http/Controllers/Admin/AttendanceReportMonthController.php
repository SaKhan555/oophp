<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Maatwebsite\Excel\Facades\Excel;
use App\Employee;

class AttendanceReportMonthController extends Controller
{
	/**
     * @var Employee
     */
    private $employee;
    /**
     * ExpenseController constructor.
     * @param EmployeeLeaveApplication $employee_leave_application
     */
    public function __construct(Employee $employee)
    {
        $this->employee = $employee;
    }
    /**
     * list report
     */
    public function index()
    {
        $month = (request('month')) 
                    ? carbon()->createFromFormat('m-Y', request('month')) 
                    : carbon()->now();
        $attendance_reports = \App\EmployeeAttendanceReport::whereMonth('month', $month->format('m'))->whereYear('month', $month->format('Y'));
        if(request('export')){
            $attendance_reports = $attendance_reports->get();
            Excel::create('Month-report', function($excel) use($month, $attendance_reports){
                    $excel->sheet('Month Report', function($sheet) use($month, $attendance_reports){
                         $sheet->loadView('admin.attendance_report_month.partials.newtable', array('month' => $month,'attendance_reports' => $attendance_reports));
                        });
                })->export('xls');
        }
        $attendance_reports = $attendance_reports->paginate(20);
        $title = 'Attendance Report Month';
        return view('admin.attendance_report_month.index', compact('title', 'attendance_reports', 'month'));
    }

    /**
     * show the specific employee month report
     */
    public function show($employee_id)
    {
        return response()->json(['status' => true]);
    }
}
