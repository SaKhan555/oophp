<?php

namespace App\Http\Controllers\Admin;

use App\Employee;
use App\Libraries\SMSService;
use App\SMSLogs;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class SMSController extends Controller
{
    /**
     * @var SMSLogs
     */
    private $logs;
    /**
     * @var Employee
     */
    private $employee;

    /**
     * SMSController constructor.
     * @param SMSLogs $logs
     * @param Employee $employee
     */
    public function __construct(SMSLogs $logs, Employee $employee)
    {
        $this->logs = $logs;
        $this->employee = $employee;
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $logs = $this->logs->where('action', 'sms_reminder')->latest('id')->paginate(15);
        return view('admin.sms.index',  compact('title', 'logs'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $title = 'Send SMS';

        if(\request('type') == 'employee'){
            $title = 'Send Employee SMS';
            $employees = $this->employee->pluck('full_name', 'id')->toArray();
            return view('admin.sms.create',  compact('title', 'employees'));
        }
        return view('admin.sms.create',  compact('title'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        if($request->get('type') == 'employee'){
            $this->validate($request, ['employee_id' => 'required_without:send_to_all','message'=>'required']);
            $employees = $this->employee->query();
            if($request->send_to_all){
                $employees = $employees->active();
            } else {
                $employees = $employees->whereIn('id', $request->get('employee_id'));
            }
            $employees = $employees->pluck('mobile_number')->toArray();
            foreach ($employees as $number) {
                $number1 = $this->clean($number);
                $service = new SMSService();
                $service->execute($number, $request->get('message'), 'sms_reminder');
            }

        } else {
            $this->validate($request, ['number'=>'required', 'message'=>'required']);
            $service = new SMSService();
            $numbers = array_unique(explode(',',$request->number));
            foreach($numbers as $number){
                $service->execute($number, $request->get('message'), 'sms_reminder');
            }
        }

        return redirect()->route('admin.sms.index')->with('success', 'Message Sent Successfully!');
    }
    public function clean($string) {

        return   preg_replace("/[^a-zA-Z0-9]/", "", $string);
    }
    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
