<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\EmployeeAttendance;
use App\Employee;
use App\AdminAttendanceLog;
use Carbon\Carbon;

class EmployeeAttendanceController extends Controller
{
    /**
     * @var Employee
     */
    private $employee;
    /**
     * @var EmployeeAttendance
     */
    private $employee_attendance;
    /**
     * EmployeeController constructor.
     * @param $employee Employee
     * @param $employee_attendance EmployeeAttendance
    */
    public function __construct(Employee $employee, EmployeeAttendance $employee_attendance)
    {
        $this->employee = $employee;
        $this->employee_attendance = $employee_attendance;
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index($employee_id)
    {
        $employee = $this->employee->find($employee_id);
        $title = $employee->full_name.' - Attendance Summary';
        $attendance_months = $employee->monthly_attendance();
        return view('admin.employee_attendance.index', compact('title','attendance_months','employee'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request, $employee_id)
    {
        $employee = $this->employee->find($employee_id);
        if($employee){
            $date = str_replace('-','/', $request->date).' '.$request->checked_at;
            $timestamp = Carbon::createFromFormat('d/m/Y h:i A',$date)->format('Y-m-d H:i:s');
            $data = [
                'employee_id' => $employee->employee_id,
                'status' => $request->status,
                'type' => 'manual',
                'checked_at' => $timestamp,
                'created_at' => $timestamp
            ];
            $employee_attendance = $this->employee_attendance->create($data);
            // create log
            AdminAttendanceLog::create([
                'employee_attendance_id' => $employee_attendance->id,
                'user_id' => auth()->guard('admin_web')->id(),
                'action' => 'created attendance',
                'new_time' => $timestamp,
            ]);
            if(request()->ajax()){
                return response()->json(['status' => true]);
            } else {
                return redirect()->back()->with('success','Updated Successfully');
            }
        } else {
            return redirect()->back()->with('error','Something went wrong');
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {
        $id = $request->attendance_id;
        $attendance = $this->employee_attendance->find($id);
        if($attendance) {
            $prev_timestamp = $attendance->created_at;
            // update attendance
            $datetime = $request->date.' '.$request->time;
            $timestamp = Carbon::parse($datetime)->format('Y-m-d H:i:s');
            $data = [
                'checked_at' => $timestamp,
                'created_at' => $timestamp,
            ];
            $attendance->update($data);
            // create log
            AdminAttendanceLog::create([
                'employee_attendance_id' => $id,
                'user_id' => auth()->guard('admin_web')->id(),
                'action' => 'updated attendance',
                'previous_timestamp' => $prev_timestamp,
                'new_time' => $timestamp,
            ]);
            if(request()->ajax()){
                return response()->json(['status' => true]);
            } else {
                return redirect()->back()->with('success','updated successfully');
            }
        } else {
            return redirect()->back()->with('error','something went wrong');
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    /**
     * update time of specific record
     */
    public function updateTime(Request $request, $id)
    {
        $employee_attendance = $this->employee_attendance->find($id);
        if($employee_attendance) {
            $prev_timestamp = $employee_attendance->checked_at;
            $timestamp = $employee_attendance->checked_at->format('Y-m-d').' '.$request->value;
            $timestamp = formatDate($timestamp, 'Y-m-d H:i:s');
            $employee_attendance->update([
                'checked_at' => $timestamp,
                'created_at' => $timestamp,
            ]);
            // create log
            AdminAttendanceLog::create([
                'employee_attendance_id' => $employee_attendance->id,
                'user_id' => auth()->guard('admin_web')->id(),
                'action' => 'updated attendance',
                'new_time' => $timestamp,
                'previous_time' => $prev_timestamp
            ]);
            return response()->json(['status' => true]);
        }
        return response()->json(['status' => false]);
    }
}
