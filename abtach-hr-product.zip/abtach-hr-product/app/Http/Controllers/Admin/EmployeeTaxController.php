<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\EmployeePaidTax;
use App\Employee;

class EmployeeTaxController extends Controller
{
    private $paid_tax;
    private $employee;

    public function __construct(EmployeePaidTax $paid_tax, Employee $employee)
    {
        $this->paid_tax = $paid_tax;
        $this->employee = $employee;
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index($employee_id)
    {
        $employee = $this->employee->find($employee_id);
        $title = $employee->full_name." Paid Taxes";
        $paid_taxes = $this->paid_tax->where('employee_id', $employee_id)->get();
        return view('admin.employee_paid_tax.index', compact('paid_taxes', 'employee'));

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request, $employee_id)
    {
        $data = [
            'employee_id' => $employee_id,
            'amount' => $request->amount,
            'month' => carbon()->createFromFormat('d/m/Y', $request->month),
            'comment' => $request->comment
        ];
        $this->paid_tax->create($data);
        return redirect()->back()->with('success', 'Tax Added Successfully!');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($employee_id, $id)
    {
        $employee = $this->employee->find($employee_id);
        $edit_paid_tax = $this->paid_tax->find($id);
        $title = $employee->full_name." Paid Taxes";
        $paid_taxes = $this->paid_tax->where('employee_id', $employee_id)->get();
        return view('admin.employee_paid_tax.edit', compact('paid_taxes', 'employee', 'edit_paid_tax'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $employee_id, $id)
    {
        $paid_tax = $this->paid_tax->find($id);
        $data = [
            'month' => carbon()->createFromFormat('d/m/Y', $request->month)->format('Y-m-d'),
            'amount' => $request->amount,
            'comment' => $request->comment
        ];
        $paid_tax->update($data);
        return redirect()->route('admin.employee.paid_tax', $employee_id)->with('success', 'Tax Updated!');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
