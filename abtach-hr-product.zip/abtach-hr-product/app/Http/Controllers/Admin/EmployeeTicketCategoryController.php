<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\EmployeeTicketCategory;
use App\Employee;

class EmployeeTicketCategoryController extends Controller
{
    /**
     * @var EmployeeTicketCategory
     */
    private $ticket_category;
    /**
     * @var Employee
     */
    private $employee;
    /**
     * Constructor
     * @var Employee $employee
     */
    public function __construct(EmployeeTicketCategory $ticket_category, Employee $employee)
    {
        $this->ticket_category = $ticket_category;
        $this->employee = $employee;
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $title = 'Ticket Categories';
        $ticket_categories = $this->ticket_category->paginate(20);
        return view('admin.ticket_category.index', compact('title', 'ticket_categories'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $title = 'Add Ticket Category';
        $employees = $this->employee->active()->pluck('full_name','id')->toArray();
        return view('admin.ticket_category.create', compact('title','employees'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate_rules($request);
        $data = [
            'name' => $request->name,
            'email' => $request->email,
            'employee_ids' => $request->employee_ids
        ];
        $this->ticket_category->create($data);
        return redirect()->route('admin.ticket_category.index')->with('success', 'Ticket Category created!');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $ticket_category = $this->ticket_category->find($id);
        $title = 'Ticket Category- '.$ticket_category->name;
        return view('admin.ticket_category.show', compact('ticket_category'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $ticket_category = $this->ticket_category->find($id);
        $employees = $this->employee->pluck('full_name', 'id')->toArray();
        $title = 'Edit Ticket Category - '.$ticket_category->name;
        return view('admin.ticket_category.edit', compact('title', 'ticket_category','employees'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $ticket_category = $this->ticket_category->find($id);
        $this->validate_rules($request, [], $id);
        $data = [
            'name' => $request->name,
            'email' => $request->email,
            'employee_ids' => $request->employee_ids
        ];
        $ticket_category->update($data);
        return redirect()->back()->with('success', 'Ticket Category updated!');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
    /**
     * validate rules
     */
    private function validate_rules($request, $rules = [], $id=null)
    {
        return $this->validate($request, array_merge([
            'name' => 'required|unique:employee_ticket_categories'. (($id) ? ',name,'.$id : ''),
            'email' => 'required'
        ], $rules));
    }
}
