<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Support\Facades\Storage;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Document;

class DocumentController extends Controller
{
/**
* Display a listing of the resource.
*
* @return \Illuminate\Http\Response
*/
public function index()
{
    $documents = Document::paginate(5);
    $title = "Documents";
    return view('admin.document.index',compact('documents','title'));
}

/**
* Show the form for creating a new resource.
*
* @return \Illuminate\Http\Response
*/
public function create()
{
        $title = "Create Document";
    return view('admin.document.create',compact('title'));
}

/**
* Store a newly created resource in storage.
*
* @param  \Illuminate\Http\Request  $request
* @return \Illuminate\Http\Response
*/
public function store(Request $request)
{
    if($request->hasfile('file')) {
        $file = $request->file->getClientOriginalName(); 
        $filename = uniqid(time()).'.'.$request->file->getClientOriginalExtension(); 
        Storage::putFileAs('documents', $request->file, $filename);
    }

    $document = new Document;
    $document->title = $request->title;
    $document->file = $filename;
    if($document->save()){
        return redirect()->route('admin.document.index')->with('success','successfully added');
    }else{
        return redirect()->back()->with('error','There is some problem!');
    }
}

/**
* Display the specified resource.
*
* @param  int  $id
* @return \Illuminate\Http\Response
*/
public function show($id)
{
//
}

/**
* Show the form for editing the specified resource.
*
* @param  int  $id
* @return \Illuminate\Http\Response
*/
public function edit($id)
{
  $document = Document::find($id);
    $title = "Edit Document";
    return view('admin.document.edit',compact('document','title'));
}


/**
* Update the specified resource in storage.
*
* @param  \Illuminate\Http\Request  $request
* @param  int  $id
* @return \Illuminate\Http\Response
*/
public function update(Request $request, $id)
{

      $document = Document::find($id);
     
     if($request->hasFile('file')) {
        $file = $request->file->getClientOriginalName(); 
        $filename = uniqid(time()).'.'.$request->file->getClientOriginalExtension(); 
        Storage::putFileAs('documents', $request->file, $filename);
        $document->file = $filename;
    }

    $document->title = $request->title;
    if($document->save()){
        return redirect()->route('admin.document.index')->with('success','successfully updated');
    }else{
        return redirect()->back()->with('error','There is some problem while updating!');
    }
}

/**
* Remove the specified resource from storage.
*
* @param  int  $id
* @return \Illuminate\Http\Response
*/
public function destroy($id)
{
    $document = Document::find($id)->forceDelete();
    if($document){
        return redirect()->route('admin.document.index')->with('success','successfully deleted');
    }else{
        return redirect()->back()->with('error','There is some problem while deleting!');
    }
}
}
