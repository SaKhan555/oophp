<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Employee;
use App\EmployeeEmergencyContact;

class EmployeeEmergencyContactController extends Controller
{
    protected $employee;
    protected $emergency_contact;

    public function __construct(Employee $employee, EmployeeEmergencyContact $emergency_contact)
    {
        $this->employee = $employee;
        $this->emergency_contact = $emergency_contact;
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index($employee_id)
    {
        $employee = $this->employee->find($employee_id);
        $title = $employee->full_name." Emergency Contacts";
        $emergency_contacts = $this->emergency_contact->where('employee_id', $employee_id)->get();
        return view('admin.employee_emergency_contact.index', compact('emergency_contacts', 'employee'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request, $employee_id)
    {
        $this->validate_rules($request);
        $data = [
            'employee_id' => $employee_id,
            'name' => $request->name,
            'relation' => $request->relation,
            'phone' => $request->phone
        ];
        $this->emergency_contact->create($data);
        return redirect()->back()->with('success', 'Emergency Contact Added Successfully!');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($employee_id, $id)
    {
        $employee = $this->employee->find($employee_id);
        $edit_emergency_contact = $this->emergency_contact->find($id);
        $title = $employee->full_name." Emergency Contact";
        $emergency_contacts = $employee->emergency_contacts;
        return view('admin.employee_emergency_contact.edit', compact('title','emergency_contacts', 'employee', 'edit_emergency_contact'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $employee_id, $id)
    {
        $this->validate_rules($request);
        $emergency_contact = $this->emergency_contact->find($id);
        $data = [
            'employee_id' => $employee_id,
            'name' => $request->name,
            'relation' => $request->relation,
            'phone' => $request->phone
        ];
        $emergency_contact->update($data);
        return redirect()->route('admin.employee.emergency_contact.index', $employee_id)->with('success', 'Emergency Contact Updated!');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
    /**
     * validate inputs
     */
    public function validate_rules($request)
    {
        return $this->validate($request, [
            'name' => 'required',
            'phone' => 'required'
        ]);
    }
    
}
