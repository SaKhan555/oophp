<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Employee;
use App\EmployeeLeaveDay;

class EmployeeLeaveDayController extends Controller
{
    protected $employee;
    protected $leave_day;
    /**
     * constructor
     */
    public function __construct(Employee $employee, EmployeeLeaveDay $leave_day)
    {
        $this->employee = $employee;
        $this->leave_day = $leave_day;
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index($employee_id)
    {
        $employee = $this->employee->find($employee_id);
        $title = $employee->full_name." - Update Leave Days";
        $leave_days = $employee->leave_days()->first();
        return view('admin.employee_leave_day.index', compact('leave_days', 'employee', 'title'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request, $employee_id)
    {
        $this->validate_rules($request);
        $employee = $this->employee->find($employee_id);
        $data = [
            'vacation_days' => $request->vacation_days,
            'home_work_days' => $request->home_work_days,
            'jury_duty_days' => $request->jury_duty_days,
            'sick_days' => $request->sick_days,
            'leaves_year' => date('Y')
        ];
        $employee->leave_days()->create($data);
        return redirect()->route('admin.employee.leave_day.index', $employee_id)->with('success', 'Leave Days Created!');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $employee_id, $id)
    {
        $this->validate_rules($request);
        $leave_days = $this->leave_day->find($id);
        $data = [
            'vacation_days' => $request->vacation_days,
            'home_work_days' => $request->home_work_days,
            'jury_duty_days' => $request->jury_duty_days,
            'sick_days' => $request->sick_days,
        ];
        $leave_days->update($data);
        return redirect()->route('admin.employee.leave_day.index', $employee_id)->with('success', 'Leave days updated!');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
    /**
     * validate rules
     */
    public function validate_rules($request)
    {
        return $this->validate($request, [
            'vacation_days' => 'required|numeric',
            'home_work_days' => 'required|numeric',
            'jury_duty_days' => 'required|numeric',
            'sick_days' => 'required|numeric',
        ]);
    }
}
