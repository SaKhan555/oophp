<?php

namespace App\Http\Controllers\Admin;

use App\Mail\UserCredentials;
use App\User;
use App\Employee;
use App\Role;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class UserController extends Controller
{

    protected $user;
    /**
     * @var Brand
     */


    /**
     * UserController constructor.
     * @param User $user
     * @param Brand $brand
     */
    public function __construct(User $user)
    {
        // $this->middleware('verify_admin');
        $this->user = $user;
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
		/*if(!in_array(auth()->user()->email, ['Muhammad.Baqir@abtach.org'])){
			return redirect()->to('/home');
		}*/

        $title = 'Users';
        $users = $this->user->search()->orderBy('type', 'ASC')->paginate(30);
        return view('admin.user.index', compact('title', 'users'));

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $title = 'Create User';
        $employees = Employee::pluck('full_name','id')->toArray();
        $types = $this->user_types();
        $roles = Role::pluck('name','id')->toArray();
        return view('admin.user.create', compact('title','employees','types'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request, $this->user->rules());
        $verified = $this->verify_allowed();
        if(!$verified['status']){
            return redirect()->back()->with('error', $verified['msg']);
        } else {
    		if(request('password')){
            $user_password = $request->password;
    			request()->merge(['password' => bcrypt(request('password')),
                    'user_id' => auth()->guard('admin_web')->id(),
                    'ip_address' => request()->ip()
                ]);
    		}
            $user_details = $this->user->create($request->all());
            $user_details['password'] = $user_password; 
            \Mail::to($user_details)->send(new UserCredentials($user_details));
            return redirect()->route('admin.user.index')->with('success', 'User Created Successfully!');
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        try {
            $user = $this->user->findOrFail($id);
            $title = 'Edit User - '.$user->name;

            if(request('type') == 'password'){
                $title = 'Change Password';
            }
            $employees = Employee::pluck('full_name','id')->toArray();
            $roles = Role::pluck('name','id')->toArray();
            $types = $this->user_types();
            return view('admin.user.edit', compact('title', 'user', 'employees', 'roles', 'types'));

        } catch (\Exception $e) {
            return redirect()->back()->with('error', $e->getMessage());
        }
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        try {
            $user = $this->user->findOrFail($id);
            $verified = $this->verify_allowed($id);
            if(!$verified['status']){
                return redirect()->back()->with('error', $verified['msg']);
            } else {
                if(request()->has('password')){
    				request()->merge(['password' => bcrypt(request('password'))]);
                    $user->update(request()->except('_token'));
    				return redirect()->route('admin.user.index')->with('success', 'User Updated Successfully!');

                } else {
                    // request()->merge([
                    //     'email_notify' => (request('email_notify')) ? 1 : 0
                    // ]);
                    $user->update(request()->except('_token', 'password'));
    				return redirect()->route('admin.user.index')->with('success', 'User Updated Successfully!');

                }
            }
        } catch (\Exception $e) {
            return redirect()->back()->with('error', $e->getMessage());
        }
    }

    public function destroy($id)
    {
        if (request('type') == 'restore') {
            $this->user->onlyTrashed()->find($id)->restore();
        } elseif (request('type') == 'forceDelete') {
            $this->user->onlyTrashed()->find($id)->forceDelete();
        } else{
            $this->user->find($id)->delete();
        }

        if (request()->ajax()) {
            return response()->json(['success' => true]);
        }

        return redirect()->back()->withSuccess('Deleted Successfully');
    }

    public function status(Request $request, $id)
    {
        $user = $this->user->find($id);

        $newStatus = ($user->status == 1) ? 0 : 1;

        $user->update(['status'=>$newStatus]);

        if($request->ajax()){
            return response()->json(['updated' => true, 'status' => $newStatus]);
        }

        return redirect()->route('admin.user.index');
    }

    // varify admins
    private function verify_allowed($id=null)
    {
        $status = true;
        $msg = '';
        if(request('type') == 'admin'){
            $users = $this->user->where('type', 'admin');
            if($id){
                $users = $users->where('id', '!=', $id);
            }
            $users = $users->get()->count();
            if($users){
                $status = false;
                $msg = 'Only 1 admin allowed per organization.';
            }
        } elseif(in_array(request('type'), ['manager', 'hr'])) {
            $users = $this->user->where('type', request('type'));
            if($id){
                $users = $users->where('id', '!=', $id);
            }
            $users = $users->get()->count();
            if(request('type') == 'manager' && $users > 1){
                $status = false;
                $msg = 'Only 2 managers allowed per organization.';
            } elseif(request('type') == 'hr' && $users){
                $status = false;
                $msg = 'Only 1 HR allowed per organization.';
            }
        }
        return [
            'status' => $status,
            'msg' => $msg
        ];
    }

    /**
     * user types
     */
    private function user_types()
    {
        if(auth()->guard('admin_web')->user()->type == 'admin'){
            $types = config('general.roles');
        } else {
            $types = array_filter(config('general.roles'), function($role){
                return $role != 'Admin';
            });
        }
        return $types;
    }
}
