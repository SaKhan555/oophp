<?php

namespace App\Http\Controllers\Admin;

use App\Mail\EmployeeFileUploadMail;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Maatwebsite\Excel\Facades\Excel;
use App\Employee;
use App\EmployeeEmergencyContact;
use App\EmployeeDepartment;
use DB;

class EmployeeUploadController extends Controller
{
    private $employee;
    /**
     * constructor
     */
    public function __construct(Employee $employee)
    {
        $this->employee = $employee;
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $title =  'Upload Employee';
        return view('admin.employee.upload', compact('title'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $path = request()->file('excel_file')->getRealPath();
        $data = Excel::load($path)->get();
        DB::beginTransaction();
        try {
            foreach($data as $val){
                // $employee_exists = $this->employee->where('employee_id', $val->employee_code)->first();
                // if($employee_exists){
                //     return back()->with('error', "The Employee Code: {$val->employee_code} has already been taken kindly correct and upload the file");
                // } else {
                    $latest_employee_id = ($this->employee->orderBy('id', 'desc')->withTrashed()->first()->id + 1);
                    $new_employee_code = str_pad($latest_employee_id, 7, "0", STR_PAD_LEFT);
                    $date_of_join = carbon()->parse($val->date_of_join);
                    $reporting_authority_code = str_pad($val->reporting_authority_code, 7, "0", STR_PAD_LEFT);
                    $reporting_authority = $this->employee->where('employee_id', $reporting_authority_code)->first();
                    $department_name = trim(strtolower($val->department));
                    $department_id = EmployeeDepartment::where(DB::raw('LOWER(name)'), '=', $department_name)->pluck('id')->first();
                    // prepare data
                    $employee_data = [
                        'manager_id' => ($reporting_authority) ? $reporting_authority->id : null,
                        'department_id' => $department_id,
                        'full_name' => $val->first_name,
                        'father_name' => $val->last_name,
                        'other_email' => $val->personal_email,
                        'mobile_number' => $val->mobile_number,
                        'reference' => $val->reference,
                        'join_date' => $date_of_join,
                        'birth_date' => carbon()->parse($val->date_of_birth)->format('Y-m-d'),
                        'address' => $val->address,
                        // 'bank_details' => [
                        //     "transit_number" =>  $val->bank_transit_number,
                        //     "financial_institution_number" => $val->bank_financial_institution_number,
                        //     "account_number" => $val->bank_account_number
                        // ],
                        'employee_id' => $new_employee_code,
                        'email' => $val->company_email,
                        'password' => bcrypt($val->account_password),
                        'first_password' => $val->account_password,
                        'designation' => $val->role,
                        'department' => $val->department,
                        'reporting_authority' => ($reporting_authority) ? $reporting_authority->full_name : null,
                        'current_status' => ucfirst($val->employee_status),
                        'salary' => $val->salary,
                        'profile_completed' => 0
                    ];
                    $employee = $this->employee->create($employee_data);
                    $id = $employee->id;
                    // save leave days
                    $employee->leave_days()->create([
                        'leaves_year' => date('Y'),
                        'vacation_days' => $val->vacation_days,
                        'home_work_days' => $val->work_from_home_days,
                        'jury_duty_days' => $val->jury_duty_days,
                        'sick_days' => $val->sick_days,
                    ]);
                    // save emergency contacts
                    $emergency_contacts = [];
                    $emergency_contacts[] = new EmployeeEmergencyContact([
                        'name' => '',
                        'relation' => '',
                        'phone' => '',
                    ]);
                    $emergency_contacts[] = new EmployeeEmergencyContact([
                        'name' => '',
                        'relation' => '',
                        'phone' => '',
                    ]);
                    $emergency_contacts[] = new EmployeeEmergencyContact([
                        'name' => '',
                        'relation' => '',
                        'phone' => '',
                    ]);
                    $employee->emergency_contacts()->saveMany($emergency_contacts);
                    // $emergency_contacts = [];
                    // if($val->emergency_contact_name_1 && $val->emergency_contact_number_1){
                    //     $emergency_contacts[] = new EmployeeEmergencyContact([
                    //         'name' => $val->emergency_contact_name_1,
                    //         'relation' => $val->emergency_contact_relation_1,
                    //         'phone' => $val->emergency_contact_number_1,
                    //     ]);
                    // }
                    // if($val->emergency_contact_name_2 && $val->emergency_contact_number_2){
                    //     $emergency_contacts[] = new EmployeeEmergencyContact([
                    //         'name' => $val->emergency_contact_name_2,
                    //         'relation' => $val->emergency_contact_relation_2,
                    //         'phone' => $val->emergency_contact_number_2,
                    //     ]);
                    // }
                    // $employee->emergency_contacts()->saveMany($emergency_contacts);
                    // save employee department
                    if($department_id){
                        $employee->departments()->create([
                            'department_id' => $department_id,
                            'created_at' => $date_of_join->toDateTimeString()
                        ]);
                    }
                    // save employee manager
                    if($reporting_authority){
                        // $manager_name = trim(strtolower($val->reporting_authority));
                        // $manager_id = $this->employee->where(DB::raw('LOWER(full_name)'), '=', $manager_name)->pluck('id')->first();
                        $employee->managers()->create([
                            'manager_id' => $reporting_authority->id,
                            'created_at' => $date_of_join->toDateTimeString(),
                        ]);
                    }
                    // save employee status
                    if($val->employee_status) {
                        $status = ucfirst(trim($val->employee_status));
                        $checkStatus = $employee->employee_status()->where('status', $status)->first();
                        if (!$checkStatus) {
                            $updated1 = $employee->update(['current_status' => $status]);
                            // $status_date = Carbon::createFromFormat('d/m/Y', request('status_date'))->toDateTimeString();
                            if(($status == 'Permanent') && ($val->probation_period)){
                                $end_date = carbon()->parse($date_of_join)->addMonths($val->probation_period)->subDay()->toDateTimeString();
                                $status_date = carbon()->parse($end_date)->addDay();
                                $employee->employee_status()->create([
                                    'status' => 'Probation',
                                    'comments' => '',
                                    'status_at' => $date_of_join,
                                    'end_at' => $end_date,
                                ]);
                            }
                            $employee->employee_status()->create([
                                'status' => $status,
                                'comments' => null,
                                'status_at' => (!empty($status_date)) ? $status_date : $date_of_join,
                                'end_at' => null,
                            ]);
                        }
                    }
                    // save employee salary
                    if($val->salary){
                        $amount = $val->salary;
                        $checkSalary = $employee->employee_salaries()->where('amount', $amount)->first();
                        if (!$checkSalary) {
                            $updated2 = $employee->update(['salary' => $amount]);
                            // $updated_date = Carbon::createFromFormat('d/m/Y', request('join_date'))->toDateTimeString();
                            $employee->employee_salaries()->create([
                                'amount' => $amount,
                                'comments' => null,
                                'created_at' => $date_of_join->toDateTimeString()
                            ]);
                        }
                    }
                    // save employee designation
                    $employee->employee_designation()->create([
                        'name' => $val->role,
                        'created_at' => $date_of_join->toDateTimeString(),
                    ]);
                    // save shift timing
                    $check_in = (!empty($val->shift_time_in)) ? Carbon::createFromFormat('h:i A', $val->shift_time_in)->format('h:i A') : '8:00 AM';
                    $check_out = (!empty($val->shift_time_out)) ? Carbon::createFromFormat('h:i A', $val->shift_time_out)->format('h:i A') : '5:00 PM';  
                    $setting = $employee->employee_setting;
                    $setting_data = [
                        'total_work_hour' => config('app.working_hours'),
                        'check_in' => $check_in,
                        'check_out' => $check_out,
                        'timezone' => config('app.timezone'),
                    ];
                    if(!$setting){
                        $setting = $employee->employee_setting()->create($setting_data);
                        $setting = $employee->employee_shifts()->create([
                            'check_in' => $check_in,
                            'total_work_hour' => config('app.working_hours'),
                            'check_out' => $check_out,
                        ]);
                    } else {
                        $setting->update($setting_data);
                        $setting = $employee->employee_shifts()->create([
                            'check_in' =>  $check_in,
                            'total_work_hour' => config('app.working_hours'),
                            'check_out' => $check_out,
                        ]);
                    }
                // }
                $employee = ['name'=>$val->first_name,'email'=>$val->company_email,'password'=>$val->account_password];
                \Mail::to($val->personal_email)->send(new EmployeeFileUploadMail($employee));
            }

            DB::commit();
            return redirect()->route('admin.employee.index')->with('success', 'Successfully imported employees!');
        } catch (\Exception $e) {
            DB::rollback();
            return redirect()->back()->with(['error'=> 'Line Number: '.$e->getLine().' Message: '.$e->getMessage()]);
        } catch (\Throwable $e) {
            DB::rollback();
            return redirect()->back()->with(['error'=>$e->getMessage()]);
        }
    }

    /**
     * Store a newly created resource in storage.
     *
     * @return \Illuminate\Http\Response
     */
    public function excelTemplate()
    {
        Excel::create('employee-excel-template', function($excel){
                    $excel->sheet('Template', function($sheet){
                         $sheet->loadView('admin.employee.upload.partials.excel_template');
                        });
                })->export('csv');
    }
}
