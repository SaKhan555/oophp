<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class NotificationController extends Controller
{
    public function seen()
    {
    	auth()->guard('admin_web')->user()->notifications()->update([
    		'seen' => 1
    	]);
    	return json_encode(['success' => true]);
    }
}
