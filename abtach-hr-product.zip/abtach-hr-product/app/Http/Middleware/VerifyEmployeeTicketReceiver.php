<?php

namespace App\Http\Middleware;

use Closure;

class VerifyEmployeeTicketReceiver
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        if(!auth()->user()->is_ticket_receiver()){
            return redirect()->route('home')->with('error','No Access');
        }
        return $next($request);
    }
}
