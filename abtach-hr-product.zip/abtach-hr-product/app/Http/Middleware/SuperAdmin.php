<?php

namespace App\Http\Middleware;

use Closure;

class SuperAdmin
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        if(!hasSuperAdmin()){
            return redirect()->route('admin.home')->with('error', 'No Access');
        } else {
            return $next($request);
        }
    }
}
