<?php

namespace App\Http\Middleware;

use Closure;

class RestrictIp
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        if(in_array(env('APP_ENV'), ['stage', 'production'])){
    		$ips = ['10.10.33.1', '221.132.113.78', '204.12.61.70', '182.176.184.57', '45.35.14.23', '111.88.66.174', '111.88.101.70', '119.63.133.115', '110.93.232.46', '192.168.10.1'];
            if (!in_array($request->ip(), $ips)) {
                return redirect()->to('/admin/home')->with('error', 'You are not authorized to view this Page');
            }
        }
		

        return $next($request);
    }
}
