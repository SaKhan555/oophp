<?php

namespace App\Http\Middleware;

use Closure;

class VerifyIp
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        // if(env('APP_ENV') != 'local'){
        //     if(in_array($request->ip(), ['221.132.113.78','110.93.232.46','149.255.32.86', '182.176.184.57'])){
        //         return $next($request);
        //     }
        //     return abort(401);
        // }
        return $next($request);
    }
}
