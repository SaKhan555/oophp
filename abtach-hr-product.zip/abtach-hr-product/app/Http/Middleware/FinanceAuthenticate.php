<?php

namespace App\Http\Middleware;

use Closure;

class FinanceAuthenticate
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {

        if (auth()->guest()) {
            if ($request->ajax()) {
                return response('Unauthorized.', 401);
            } else {
                return redirect()->guest('login');
            }
        }

        if (auth()->check()) {
            $type = auth()->user()->type;
            if(!in_array($type, ['finance', 'admin']))
            {
                return redirect()->to('/home');
            }
        }
        return $next($request);
    }
}
