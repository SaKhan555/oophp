<?php

namespace App\Http\Middleware;

use Closure;

class VerifyEmployeeManager
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        $role = strtolower(auth()->guard('web')->user()->role);
        // if(($role == 'manager') || ($role == 'admin') || auth()->guard('web')->user()->is_manager) {
        //     return $next($request);
        // }
        if(auth()->user()->has_employees()){
            return $next($request);
        }
        return redirect()->route('home')->with('error','Access denied!');
    }
}
