<?php

namespace App\Http\Middleware;

use Closure;

class VerifyEmployeeActive
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        $disallowed_statuses = ['probation', 'notice period', 'separation', 'offered'];
        $current_status = strtolower(auth()->user()->current_status);
        if(auth()->check() && in_array($current_status, $disallowed_statuses)){
            return redirect()->route('home')->with('error', 'not allowed');
        }
        return $next($request);
    }
}
