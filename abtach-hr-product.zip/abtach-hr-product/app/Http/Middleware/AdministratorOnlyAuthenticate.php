<?php

namespace App\Http\Middleware;

use Closure;

class AdministratorOnlyAuthenticate
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        if (!auth()->guard('admin_web')->check()) {
            return redirect('/admin/login');
        }

        $type = auth()->guard('admin_web')->user()->type;
        if(!in_array($type, ['admin']))
        {
            return redirect()->to('/admin/home');
        }



        return $next($request);
    }
}
