<?php

namespace App\Http\Middleware;

use Closure;

class CheckPermission
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        return $next($request);
        // if(auth()->guard('admin_web')->id() == 1 || in_array($request->route()->getName(), auth()->guard('admin_web')->user()->role->permissions())){
        //     return $next($request);
        // } else {
        //     return redirect()->route('admin.home')->with('error','Not Allowed');
        // }
    }
}
