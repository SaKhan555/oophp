<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CompanyVehicleRent extends Model
{
    protected $guarded = ['id'];
}
