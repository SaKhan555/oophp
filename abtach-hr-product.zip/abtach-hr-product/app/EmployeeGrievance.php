<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class EmployeeGrievance extends Model
{
    protected $guarded = ['id'];

    // belongs to an employee
    public function employee()
    {
    	return $this->belongsTo(Employee::class);
    }
    // belongs to an employee
    public function against_employee()
    {
    	return $this->belongsTo(Employee::class, 'against');
    }
    // has many comments
    public function comments()
    {
    	return $this->hasMany(EmployeeGrievanceComment::class, 'grievance_id');
    }
    // actual statu
    public function actual_status()
    {
    	return ($this->status) ? 'Resolved' : 'Pending';
    }
    /**
     * search scope
     */
    public function scopeSearch($query)
    {
    	$s = request('s');
    	if($s){
    		return $query->whereHas('employee', function($q) use($s) {
    			return $q->where('full_name', 'LIKE', "%$s%");
    		});
    	}
    	return $query;
    }
}
