<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class EmployeeManager extends Model
{
    protected $guarded = ['id'];

    /**
     * belongs to Employee
     */
    public function manager()
    {
    	return $this->belongsTo(Employee::class,'manager_id');
    }
    /**
     * belongs to Employee
     */
    public function employee()
    {
    	return $this->belongsTo(Employee::class,'employee_id');
    }

}
