<?php

namespace App;

use Barryvdh\DomPDF\PDF;
use Faker\Provider\ar_SA\Payment;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Notifications\Notifiable;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Carbon\Carbon;
use App\Traits\RecordActivity;

class Employee extends Authenticatable
{
	use RecordActivity, Notifiable, SoftDeletes;

    protected $guarded = ['id'];

    protected $casts = [
        'bank_details' => 'json',
        'status' => 'boolean',
        'is_manager' => 'boolean',
    ];
    // dates
    protected $dates = [
        'join_date'
    ];
    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token','salary','bank_details'
    ];
    public function scopeSearch($query)
    {
        $s = trim(request('s'));
        if($s) {
            $query = $query->where('full_name', 'LIKE', '%' . $s . '%')
                ->orWhere('employee_id', 'LIKE', '%' . $s . '%')
                ->orWhere('email', 'LIKE', '%' . $s . '%');
        }
        if(request('current_status')){
            $query = $query->where('current_status', request('current_status'));
            // if(request('current_status') == 'Separation' && request('status_type')){
            //     $query = $query->whereHas('employee_status', function($q){
            //         return $q->where('type', request('status_type'));
            //     });
            // }
        } else {
            $query = $query->where('current_status', '!=', 'Separation');
        }
        if(request('marital_status') == 'n_a'){
            $query = $query->whereNull('marital_status')->where('current_status', '!=', 'Separation');
        } elseif(request('marital_status')){
            $query = $query->where('marital_status', request('marital_status'));

        }
		if(request('is_join') == 'no'){
            $query = $query->where('is_join', 0);
        } else {
			$query = $query->where('is_join', 1);
		}
        if(!count(request()->all())){
            $query = $query->where('current_status', '!=', 'Offered');
        }
        if(request('department_ids')){
            $department_ids = array_filter(request('department_ids'), function($department_id){
                return $department_id != null;
            });
            if(count($department_ids)){
                $query = $query->whereIn('department_id', $department_ids);
            }
        }
        if(request('unit_ids')){
            $unit_ids = array_filter(request('unit_ids'), function($department_id){
                return $department_id != null;
            });
            if(count($unit_ids)){
                $query = $query->whereIn('unit_id', $unit_ids);
            }
        }
        if(!is_null(request('is_foreigner'))){
            $query = $query->where('is_foreigner', request('is_foreigner'));
        }
        return $query;

    }
    // restrict manager
    public function scopeRestrictManager($query, $manager = null)
    {
        if(is_integer($manager)){
            $manager_id = $manager_id;
        } elseif($manager){
            $manager_id = $manager->id;
        } else {
            $manager_id = ($manager) ? $manager : auth()->id();
        }
        $reporting_managers = ($manager) ? $manager->reporting_managers() : auth()->user()->reporting_managers();
        return $query->whereIn('manager_id', 
            array_merge([$manager_id], $reporting_managers)
        );
    }
    // only active employees
    public function scopeActive($query) 
    {
        return $query->whereNotIn('current_status',['Offered','Separation']);
    }
    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsToMany
     */
    public function employee_salaries()
    {
        return $this->hasMany(EmployeeSalary::class);
    }
    // latest salary
    public function salary_for_month($month='', $year='')
    {
        $month = ($month) ? $month : carbon()->now()->format('m');
        $year = ($year) ? $year : carbon()->now()->format('Y');
        $date = "$year-$month-01";
        $current_salary = $this->employee_salaries()->whereDate('created_at', '<=', $date)->orderBy('created_at', 'desc')->first();
        return ($current_salary) ? $current_salary->amount : $this->salary;
    }
    // latest salary object 
    public function salary_object_for_month($month='', $year='')
    {
        $month = ($month) ? $month : carbon()->now()->format('m');
        $year = ($year) ? $year : carbon()->now()->format('Y');
        $date = "$year-$month-01";
        $current_salary = $this->employee_salaries()->whereDate('created_at', '<=', $date)->orderBy('created_at', 'desc')->first();
        if(!$current_salary){
            $current_salary = $this->employee_salaries()->orderBy('created_at', 'desc')->first();
        }
        return $current_salary;
    }
    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsToMany
     */
    public function employee_status()
    {
        return $this->hasMany(EmployeeStatus::class)->orderBy('status_at', 'DESC');
    }
    /**
     * has many emergency contacts
     */
    public function emergency_contacts()
    {
        return $this->hasMany(EmployeeEmergencyContact::class);
    }
    /**
     * has one bank details
     */
    public function bank_detail()
    {
        return $this->hasOne(EmployeeBankDetail::class);
    }
	public function employee_vehicle()
    {
        return $this->belongsToMany(CompanyVehicle::class, 'employee_vehicles', 'employee_id',  'vehicle_id')->withPivot('car_issue_date', 'car_return_date');
    }
    public function employee_designation()
    {
        return $this->hasMany(EmployeeDesignation::class)->latest();
    }
    public function employee_shifts()
    {
        return $this->hasMany(EmployeeShiftTiming::class)->latest();
    }
    public function employee_relation()
    {
        return $this->hasMany(EmployeeRelation::class);
    }
    public function resignations()
    {
        return $this->hasMany(EmployeeResignation::class);
    }
    public function salary_slips()
    {
        return $this->hasMany(PaymentHistory::class)->orderBy('salary_month', 'DESC');
    }
	// new salary slips
    public function new_salary_slips()
    {
        return $this->hasMany(EmployeeSalarySlip::class)->orderBy('month', 'desc');
    }
	
    public function employee_setting()
    {
        return $this->hasOne(EmployeeSetting::class);
    }
    public function manager_employee()
    {
        return $this->belongsTo(Employee::class,  'manager_id', 'id');
    }
    /**
     * employees
     */
    public function employees()
    {
        return $this->hasMany(Employee::class, 'manager_id');
    }

    public function unit_employee()
    {
        return $this->belongsTo(Unit::class,  'unit_id', 'id');
    }
    public function employee_department()
    {
        return $this->belongsTo(EmployeeDepartment::class,  'department_id', 'id');
    }
    public function employee_attendance()
    {
        return $this->hasMany(EmployeeAttendance::class, 'employee_id','employee_id');
    }
    // has many paid taxes
    public function paid_taxes()
    {
        return $this->hasMany(EmployeePaidTax::class);
    }
    /**
     * has many allownaces
     */
    public function allowances()
    {
        return $this->hasMany(EmployeeAllowance::class);
    }
    /**
     * has many incentives
     */
    public function incentives()
    {
        return $this->hasMany(EmployeeIncentive::class)->orderBy('date', 'desc');
    }
    /**
     * has one settlement
     */
    public function final_settlement()
    {
        return $this->hasOne(EmployeeFinalSettlement::class);
    }
    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsToMany
     */
    public function units_employee()
    {
        return $this->belongsToMany(Unit::class, 'employee_units')->withPivot('percent');
    }
    /**
     * has many notes
     */
    public function notes()
    {
        return $this->hasMany(EmployeeNote::class,'employee_id','id')->orderBy('created_at','desc');
    }
    /**
     * has many tickets
     */
    public function tickets()
    {
        return $this->hasMany(EmployeeTicket::class,'employee_id','id')->orderBy('created_at','desc');
    }
    /**
     * belongs to many ticketcategories
     */
    public function ticket_categories()
    {
        return $this->belongsToMany(EmployeeTicketCategory::class,
                                    'employee_ticket_category_employees','employee_id','category_id');
    }
    // belongs to a country
    public function country()
    {
        return $this->belongsTo(Country::class);
    }
    // has foreign agent
    public function foreign_agent()
    {
        return $this->hasOne(ForeignAgent::class);
    }
    // has foreign employee password
    public function foreign_agent_password()
    {
        return $this->hasOne(EmployeeForeignPassword::class);
    }
    // has many discrepancies
    public function attendance_discrepancies()
    {
        return $this->hasMany(EmployeeAttendanceDiscrepancy::class);
    }
    /**
     * employee assets
     */
    public function assets()
    {
        return $this->hasMany(EmployeeAsset::class);
    }
    /**
     * insurance
     */
    public function insurance_plan()
    {
        return $this->belongsTo(InsurancePlan::class, 'insurance_plan');
    }
    /**
     * ticket category ids
     */
    public function ticket_category_ids()
    {
        return $this->ticket_categories()->pluck('category_id')->toArray();
    }
    /**
     * unseen notes
     */
    public function unseen_notes()
    {
        return $this->notes()->where('seen', 0)->count();
    }

    public function rules($id=null, $merge=[]) {
        return array_merge(
            [
                'full_name' => 'required',
            ],
            $merge);
    }

    public  function generate_letter($id)
    {
        $pdf = PDF::loadView('admin.employee.letter.offer', $data);
        return $pdf->download('invoice.pdf');
    }
	/**
     * leave days
     */
    public function leave_days()
    {
        return $this->hasMany(EmployeeLeaveDay::class);
    }
    /**
     * vacation days left
     */
    public function vacation_days_left()
    {
        $leave_days = $this->leave_days()->whereYear('leaves_year', '=', date('Y'))->first();
        if($leave_days){
            $total_approved_leaves = $this->leave_applications()->where('leave_type_id', 1)->whereYear('start_date', '=', date('Y'))->whereYear('end_date', '=', date('Y'))->where('status', 1)->pluck('total_leave')->toArray();
            return ($leave_days->vacation_days - array_sum($total_approved_leaves));
        }
        return 0;
    }
    /**
     * vacation days left
     */
    public function homework_days_left()
    {
        $leave_days = $this->leave_days()->whereYear('leaves_year', '=', date('Y'))->first();
        if($leave_days){
            $total_approved_leaves = $this->leave_applications()->where('leave_type_id', 2)->whereYear('start_date', '=', date('Y'))->whereYear('end_date', '=', date('Y'))->where('status', 1)->pluck('total_leave')->toArray();
            return ($leave_days->home_work_days - array_sum($total_approved_leaves));
        }
        return 0;
    }
    /**
     * vacation days left
     */
    public function sick_days_left()
    {
        $leave_days = $this->leave_days()->whereYear('leaves_year', '=', date('Y'))->first();
        if($leave_days){
            $total_approved_leaves = $this->leave_applications()->where('leave_type_id', 3)->whereYear('start_date', '=', date('Y'))->whereYear('end_date', '=', date('Y'))->where('status', 1)->pluck('total_leave')->toArray();
            return ($leave_days->sick_days - array_sum($total_approved_leaves));
        }
        return 0;
    }
    /**
     * vacation days left
     */
    public function juryduty_days_left()
    {
        $leave_days = $this->leave_days()->whereYear('leaves_year', '=', date('Y'))->first();
        if($leave_days){
            $total_approved_leaves = $this->leave_applications()->where('leave_type_id', 4)->whereYear('start_date', '=', date('Y'))->whereYear('end_date', '=', date('Y'))->where('status', 1)->pluck('total_leave')->toArray();
            return ($leave_days->jury_duty_days - array_sum($total_approved_leaves));
        }
        return 0;
    }
	/**
     * Total Leaves
     */
    public function leaves_in_account()
    {
        $total_leaves = $this->leaves()->pluck('total_leave')->toArray();
        return array_sum($total_leaves);
    }
    public function leaves_in_balance()
    {
        return ($this->leaves_in_account() - $this->leaves_availed());
    }
	public function leaves()
    {
        return $this->hasMany(EmployeeLeave::class);
    }
	
	public function leave_applications() 
    {
        return $this->hasMany(EmployeeLeaveApplication::class);
    }
    public function total_applied_leaves($month)
    {
        return array_sum($this->leave_applications()->whereMonth('start_date', '=',$month)->whereMonth('end_date' ,'=', $month)->whereYear('start_date', '=', date('Y'))->pluck('total_leave')->toArray());
    }
    public function total_approved_leaves($month)
    {
        return array_sum($this->leave_applications()->whereMonth('start_date','=',$month)->whereMonth('end_date', '=', $month)->whereYear('start_date', '=', date('Y'))->where('status', 1)->pluck('total_leave')->toArray());
    }
    /**
     * has many letters
     */
    public function letters()
    {
        return $this->hasMany(EmployeeLetter::class);
    }
    /**
     * has many assigned departments
     */
    public function departments()
    {
        return $this->hasMany(EmployeeDepartmentAssign::class);
    }
    /**
     * has many assigned managers
     */
    public function managers()
    {
        return $this->hasMany(EmployeeManager::class);
    }
    /**
     * is manager
     */
    public function is_manager()
    {
        return (in_array($this->role, ['admin','manager']) || $this->is_manager);
    }
    /**
     * is admin
     */
    public function is_admin()
    {
        return $this->role == 'admin';
    }
    /**
     * is active
     */
    public function is_active()
    {
        $disallowed_statuses = ['probation', 'notice period', 'separation', 'offered'];
        $current_status = strtolower($this->current_status);
        return (!in_array($current_status, $disallowed_statuses));
    }
    /**
     * is ticket receiver
     */
    public function is_ticket_receiver()
    {
        return ($this->is_admin() || $this->ticket_categories()->count());
    }
    /**
     * reporting managers
     */
    public function reporting_managers($id = null, &$ids= [])
    {
        // If no ID is passed, set the current model ID as the parent
        if (is_null($id)) {
            $id = $this->id;
        }

        // Find subcategory IDs
        $managerIds = $this->query()->where('manager_id', $id)->pluck('id')->toArray();

        // Add each ID to the list and recursively find other subcategory IDs
        foreach ($managerIds as $managerId) {
            $ids[] = $managerId;
            $ids += $this->reporting_managers($managerId, $ids);
        }

        return $ids;
    }
    /**
     * reporting employees 
     */
    public function reporting_employees()
    {
        $managers = array_merge([
                $this->id
            ], $this->reporting_managers());
        return $this->active()->whereIn('manager_id', $managers)->get();
    }
    /**
     * check if has reporting employees
     */
    public function has_employees()
    {
        if($this->reporting_employees()->count()){
            return true;
        }
        return false;
    }
    /**
     * team employees
     */
    public function team_employees()
    {
        if($this->is_manager) {
            $team = $this->reporting_employees();
        } else {
            $team = $this->active()->where('id', '!=', $this->id)
                                    ->where('department_id', $this->department_id)
                                    ->where('unit_id', $this->unit_id)->get();
        }
        return $team;
    }
    /**
     * all managers
     */
    public function all_manager_ids($id = null, &$ids= [])
    {
        if (is_null($id)) {
            $id = $this->manager_id;
        }
        $manager = $this->query()->where('is_manager',1)->where('id', $id)->first();

        if($manager){
            $ids[] = $manager->id;
            if($manager->manager_employee){
                $ids += $this->all_manager_ids($manager->manager_id, $ids);
            }
        }

        return $ids;
    }
    /**
     * Total leaves availed
     */
    public function leaves_availed()
    {
        $leave_availed = 0;
        if($this->leaves) {
            foreach($this->leaves as $leave) {
                $currentMonth = Carbon::parse($leave->month)->format('m');
                $leave_applications = $this->leave_applications()
                            ->whereRaw('MONTH(created_at) = ?',[$currentMonth])
                            ->get();
                if($leave_applications){
                    foreach($leave_applications as $leave_application){
                        $approval = $leave_application->approvals()->first();
                        if($approval && $approval->status) {
                            $leave_availed += $leave_application->total_leave;
                        }
                    }
                }
            }
        }
        return $leave_availed;
    }

    // employee current shift
    public function shift($date='')
    {
        $shift = $this->employee_shifts();
        if($date){
            $shift = $shift->whereDate('created_at', '<=',formatDate($date, 'Y-m-d'));
        }
        $shift = $shift->latest()->first();
        if(!$shift){
            $shift = $this->employee_shifts()->orderBy('created_at','desc')->first();
        }
        return $shift;
    }   
    // employee current shift time
    public function shift_time($date='')
    {
        $shift = $this->shift($date);
        return ($shift) ? $shift->check_in .'-'.$shift->check_out : '';
    }	
    // monthly attendance
    public function monthly_attendance()
    {
        $attendances = $this->employee_attendance()->orderBy('checked_at','desc')->get();
        $attendance_monthly = [];
        foreach($attendances as $attendance) {
            $attendance_monthly[$attendance->checked_at->format('F Y')][] = $attendance;
        }
        return $attendance_monthly;
    }
    // all check in and outs
    public function checkInOuts($search='', $order='asc', $type='normal')
    {
        $attendance_checkeds = $this->employee_attendance();
        if($search){
            $requested_month = carbon()->parse('25-'.$search);
            // if($type == 'export') {
            $to_date = $requested_month->format('Y-m-d');
            $from_date = $requested_month->subMonths(1)->format('Y-m').'-26'; 
            $attendance_checkeds = $attendance_checkeds->whereDate('checked_at', '>=',$from_date)->whereDate('checked_at','<=', $to_date);
            // } else {
            //     $attendance_checkeds = $attendance_checkeds->whereMonth('checked_at', '=',$requested_month->format('m'))->whereYear('checked_at','=', $requested_month->format('Y'));                
            // }
        }
        $attendance_checkeds = $attendance_checkeds->orderBy('checked_at', $order)->pluck('checked_at')->toArray();
        $attendance_months_data = [];
        foreach($attendance_checkeds as $attendance_checked){
            $month = formatDate($attendance_checked, 'F Y');
            $day = formatDate($attendance_checked, 'd-m-Y');
            $attendance_months_data[$month][] = $day;
            $attendance_months_data[$month] = array_unique($attendance_months_data[$month]);
        }
        return $attendance_months_data;
    }
    
    // check in
    public function check_in_for($date,$format="h:i A")
    {
        $date = formatDate($date, 'Y-m-d');
        $shift = $this->employee_shifts()->whereDate('created_at', '<=',$date)->latest()->first();
        if(!$shift){
            $shift = $this->shift();
        }
        if($shift){
            $shift_time_in = $shift->check_in;
            $shift_time_out = $shift->check_out;
            if(($shift_time_in && strtolower(explode(' ',$shift_time_in)[1]) == 'pm') && ($shift_time_out && strtolower(explode(' ',$shift_time_out)[1]) == 'am')){
                $checked_in = $this->employee_attendance()->whereDate('checked_at', $date)->whereTime('created_at','>=', date("H:i", strtotime($shift_time_in)))->whereStatus('01')
                    ->orderBy('created_at','asc')->first();
            } else {
                $checked_in = $this->employee_attendance()->whereDate('checked_at', $date)->whereStatus('01')
                    ->orderBy('created_at','asc')->first();
            }
            return ($checked_in) ? formatDate($checked_in->checked_at,$format) : '';
        } 
        return '';
    }
    // check out
    public function check_out_for($date, $format="h:i A")
    {
        $shift = $this->employee_shifts()->whereDate('created_at', '<=',formatDate($date, 'Y-m-d'))->latest()->first();
        if(!$shift){
            $shift = $this->shift();
        }
        if($shift){
            $shift_time_in = $shift->check_in;
            $shift_time_out = $shift->check_out;
            $date = Carbon::parse($date.' '.$shift_time_in)->addHour(9)->format('Y-m-d H:i:s');
            $datenew = formatDate($date, 'Y-m-d');
            if(($shift_time_in && strtolower(explode(' ',$shift_time_in)[1]) == 'pm') && ($shift_time_out && strtolower(explode(' ',$shift_time_out)[1]) == 'am')){
                $checked_out = $this->employee_attendance()->whereTime('created_at','<', date("H:i", strtotime($shift_time_in)))->whereDate('created_at',$datenew)->whereStatus('02')->orderBy('created_at','desc')->first();
            } else {
                $checked_out = $this->employee_attendance()->whereDate('checked_at', $datenew)->whereStatus('02')->orderBy('checked_at','desc')->first();
                if(!$checked_out){
                    $datenew = Carbon::parse($datenew)->addDay(1)->format('Y-m-d');
                    $checked_out = $this->employee_attendance()->whereTime('created_at','<', $shift_time_in)->whereDate('created_at',$datenew)->whereStatus('02')->orderBy('created_at','desc')->first();
                }
            }
            return ($checked_out) ? formatDate($checked_out->checked_at,$format) : '';
        }
        return '';
    }
    // working hours
    public function working_hours_for($date)
    {
        $check_in = $this->check_in_for($date);
        $check_out = $this->check_out_for($date);
        if($check_in && $check_out) {
            $to = Carbon::parse($this->check_out_for($date,'Y-m-d H:i:s'));
            $from = Carbon::parse($this->check_in_for($date,'Y-m-d H:i:s'));
            return $diff_in_hours = $to->diff($from)->format('%H:%I');
            // $to = \Carbon\Carbon::createFromFormat('Y-m-d H:i:s', $check_out);
            // $from = \Carbon\Carbon::createFromFormat('Y-m-d H:i:s', $check_in);
        }
        return '';
        // return ($check_in && $check_out) ? $check_out->diff($check_in)->format('%H:%I') : '';
    }
    // late hours
    public function late_hours_for($date)
    {
        $check_in = ($this->check_in_for($date)) ? Carbon::parse($this->check_in_for($date)) : '';
        $shift = $this->employee_shifts()->whereDate('created_at', '<=',formatDate($date, 'Y-m-d'))->latest()->first();
        if(!$shift){
            $shift = $this->shift();
        }
        if($shift) {
            $shift_time_in = carbon()->parse($shift->check_in);
            if($check_in && $shift_time_in) {
                $late_hours = $check_in->diff($shift_time_in)->format('%H:%I');
                if($check_in->lessThan($shift_time_in)) {
                    return $late_hours .' (early)';
                } else {
                    return $late_hours.' (late)';
                }
            }
        }
        return '';
    }
    // late hours
    public function is_half_day_for($date)
    {
        $check_in = $this->check_in_for($date);
        $check_in = ($check_in) ? Carbon::parse($check_in) : '';

        $check_out = $this->check_out_for($date);
        $check_out = ($check_out) ? Carbon::parse($check_out) : '';

        $shift = $this->shift($date);

        if($shift) {
            // calculate by check in
            $shift_time_in = carbon()->parse($shift->check_in);
            if($check_in && $shift_time_in) {
                if($check_in->greaterThan($shift_time_in->addHours('2.29'))) {
                    return true;
                }
            }
            // calculate by check out
            $shift_time_out = carbon()->parse($shift->check_out);
            if($check_out && $shift_time_out) {
                if($check_out->lessThan($shift_time_out->subHours('2.29'))){
                    return true;
                } 
            }
        }
        return false;
    }

    // attend status
    public function attend_status_for($checked_in, $checked_out)
    {
        $output = '';
        $attend_status = function($status,$title='') {
            return "<span class='attend-status attend-$status' title='$title'></span>";
        };
        if($checked_in && $checked_out){
            $output = $attend_status('both', 'Checked in and checked out');
        } elseif($checked_in && !$checked_out) {
            $output = $attend_status('checkin','Only checked in');
        } elseif($checked_out && !$checked_in) {
            $output = $attend_status('checkout','Only checked out');
        } else {
            $output = $attend_status('none','No Checked in and Checked out');
        }
        return $output;
    }
    // check in status
    public function check_in_status_for($date)
    {
        $check_in = ($this->check_in_for($date)) ? Carbon::parse($this->check_in_for($date)) : '';
        $shift = $this->shift($date);
        if($shift && $check_in) {
            $shift_time_in = carbon()->parse($shift->check_in);
            if($check_in->lessThan($shift_time_in)) {
                return 'early';
            } elseif ($check_in->diffInMinutes($shift_time_in) > 30) {
                return 'late';
            } else {
                return 'normal';
            }
        }
    }
    // check out status
    public function check_out_status_for($date)
    {
        $check_in = ($this->check_in_for($date)) ? Carbon::parse($this->check_in_for($date)) : '';
        $check_out = ($this->check_out_for($date)) ? Carbon::parse($this->check_out_for($date)) : '';
        $shift = $this->shift($date);
        $working_hours = 8;
        if($shift && $check_out) {
            $shift_time_out = carbon()->parse($shift->check_out);
            if($check_out->diffInHours($check_in) < 9) {
                return 'early';
            } elseif ($check_out->diffInHours($check_in) > $working_hours) {
                return 'late';
            } else {
                return 'normal';
            }
        }
    }
    // in status
    public function in_status($date)
    {
        $in_status = $this->check_in_status_for($date);
        return function($status='') use($in_status) {
            return $in_status == $status;
        };
    }
    // in status class
    public function in_status_class($check_in_status)
    {
        switch ($check_in_status) {
            case 'early':
                $status_class = 'alert-success';
                break;
            case 'late':
                $status_class = 'alert-danger';
                break;
            default:
                $status_class = '';
                break;
        }
        return $status_class;
    }
    // picture url
    public function photo_url()
    {
        if($this->photo && file_exists("../public/uploads/employee/avatars/{$this->photo}")){
            return '/uploads/employee/avatars/'.$this->photo;
        }
        if(strtolower($this->sex) == 'female'){
            return '/assets/new-theme/images/avatar-female.svg';
        } else {
            return '/assets/new-theme/images/avatar-male.svg';
        }
    }
    // arrears
    public function arrears($month = '', $year='')
    {
        $year = ($year) ? $year : carbon()->now()->format('Y'); 
        $month = ($month) ? ($month - 1) : carbon()->now()->subMonth()->format('m');
        $prev_month = ($month) ? ($month - 1) : carbon()->now()->subMonth()->format('m');
        $date = "1-$month-$year";
        $approved_leaves = $this->leave_applications()
                        ->whereDate('start_date', '>=', "$year-$prev_month-26")
                        ->whereDate('end_date', '>=', "$year-$prev_month-26")
                        ->whereDate('start_date', '<=' , "$year-$month-25")
                        ->whereDate('end_date', '<=' , "$year-$month-25")
                        ->where('status', 1)
                        ->whereHas('approvals', function($q) use($month, $year) {
                            return $q->where('status', 1)->whereDate('created_at', '>', "$year-$month-27");
                        })->pluck('total_leave')->toArray();
        $perday_salary = $this->perday_salary($month.'-'.$year);
        $arrears = array_map(function($approved_leave_application) use($perday_salary) {
            return $perday_salary*$approved_leave_application;
        }, $approved_leaves);
        $arrears = floor(array_sum($arrears));
        // verify arrears
        // $date = carbon()->parse($date)->subMonth();
        // $prev_month = $date->format('m');
        // $prev_year = $date->format('Y');
        $prev_payslip = $this->new_salary_slips()->whereMonth('month',"=",$month)->whereYear("month","=",$year)->first();
        if($prev_payslip) {
            $total_prev_deductions = ($prev_payslip->per_day_salary * $prev_payslip->deductions['absents']);
            if($arrears > $total_prev_deductions){
                return $total_prev_deductions;
            } else {
                return $arrears;
            }
        } else {
            return $arrears;
        }
    }

    // perday salary
    public function perday_salary($month='')
    {
        $total_days = total_days_of_month($month);
        return ($this->salary/$total_days);
    }
    // total yearly salary
    public function current_year_salary()
    {
        $month = carbon()->parse("first day of june ".date('Y'));
        $total_salary = 0;
        for ($i = 1; $i <= 12; $i++) {
            $month = $month->addMonth();
            $current_salary = $this->employee_salaries()->whereDate('created_at', '<=', $month->format('Y-m-d'))
                                    ->orderBy('created_at', 'desc')
                                    ->first();
            $total_salary += $current_salary->amount;
        }
        return $total_salary;
        // $current = carbon()->parse("first day of ".date('F Y'));
        // $latest_salary = $this->employee_salaries()->orderBy('created_at', 'desc')->first();
        // $paid_months = $year_start->diffInMonths($current);
        // $remaining_months = (12 - $paid_months);
        // $salary_to_be_paid = $latest_salary->amount * $remaining_months;
        // $salary_paid = $;
        // return ($salary_to_be_paid + $salary_paid);
    }
    // total yearly taxable salary
    public function current_year_taxable_salary()
    {
        $current = carbon()->now();
        $year = $current->format('Y');
        $current_month = $current->format('m');
        if($current_month <= 06){
            $year = $current->subYear()->format('Y');
        }

        $month = carbon()->parse("first day of june ".$year);
        $total_salary = 0;
        $leaved = [];
        $salary_amounts = [];
        for ($i = 1; $i <= 11; $i++) {
            $month = $month->addMonth();
            if( ($this->join_date->format('Y') > $month->format('Y')) || ($this->join_date->format('Y') == $month->format('Y') && $this->join_date->format('m') > $month->format('m')) || ( ($this->join_date->format('Y') == $month->format('Y')) && ($this->join_date->format('m') == $month->format('m') && $this->join_date->format('d') > 25)) ){
                $leaved[] = $month->format('m-Y');
            } else {
                $salary_slip = $this->new_salary_slips()->whereYear('month', '=', $month->format('Y'))->whereMonth('month', '=', $month->format('m'))->whereDate('month', '<', "$year-{$current_month}-01")->first();
                if(!$salary_slip){
                    $salary = $this->employee_salaries()->whereDate('created_at', '<=', $month->format('Y-m-d'))
                                            ->orderBy('created_at', 'desc')->first();
                    if(!$salary){
                        // if salary not available according to date the get the salary before joined date
                        $joined_date = formatDate($this->join_date, 'Y-m-d');
                        $salary = $this->employee_salaries()->whereDate('created_at', '<=', $joined_date)
                                        ->orderBy('created_at', 'desc')->first();
                    }
                    if(!$salary){
                        $salary = $this->employee_salaries()->orderBy('created_at', 'desc')->first();
                    }
                    $medical_allowance = $salary->breakups['medical'];
                    $salary_amount = $salary->amount;
                } else {
                    $medical_allowance = $salary_slip->additions['medical'];
                    $salary_amount = ($salary_slip->net_salary 
                                        + $salary_slip->deductions['loan'] 
                                        + $salary_slip->deductions['income_tax']
                                        + $salary_slip->deductions['eobi']);
                    $salary_amount += (isset($salary_slip->deductions['advance_salary'])) 
                                        ? $salary_slip->deductions['advance_salary'] 
                                        : 0;
                }
                $salary_amounts[] = $salary_amount;
                $total_salary += ($salary_amount - $medical_allowance); // deduct medical allowance
            }
        }
        return $total_salary;
        // $current = carbon()->parse("first day of ".date('F Y'));
        // $latest_salary = $this->employee_salaries()->orderBy('created_at', 'desc')->first();
        // $paid_months = $year_start->diffInMonths($current);
        // $remaining_months = (12 - $paid_months);
        // $salary_to_be_paid = $latest_salary->amount * $remaining_months;
        // $salary_paid = $;
        // return ($salary_to_be_paid + $salary_paid);
    }
    // total yearly extra days taxable salary
    public function extra_days_taxable_salary()
    {
        $current = carbon()->now();
        $year = $current->format('Y');
        $current_month = $current->format('m');
        if($current_month <= 06){
            $year = $current->subYear()->format('Y');
        }

        $month = carbon()->parse("first day of june ".$year);
        $total_salary = 0;
        for ($i = 1; $i <= 12; $i++) {
            $month = $month->addMonth();
            $current_salary = $this->employee_salaries()->whereDate('created_at', '<=', $month->format('Y-m-d'))
                                    ->orderBy('created_at', 'desc')
                                    ->first();
            $total_salary += ($current_salary->amount - (($current_salary->amount * 6.35)/100));
        }
        return $total_salary;
    }
    // confirmed_at
    public function confirmed_at($format='M d, Y')
    {
        $status = $this->employee_status()->where('status', 'Permanent')->first();
        return ($status) ? formatDate($status->status_at, $format) : null;
    }
    // is present
    public function is_present($date='')
    {
        $date = ($date) ? $date : carbon()->now()->format('d-m-Y');
        $shift = $this->shift($date);
        if($shift) {
            $shift_time_in = carbon()->createFromFormat('h:i A', $shift->check_in)->subHours(5)->format('H:i');
            $check_in = $this->employee_attendance()
                                ->whereDate('checked_at', '=', formatDate($date, 'Y-m-d'))
                                ->whereTime('checked_at', '>=', $shift_time_in)
                                ->first();
            if($check_in){
                return true;
            } else {
                return false;
            }
        }
    }
    // has discrepancies
    public function has_discrepancies($start_date='', $end_date='')
    {
        return true;
        // $start_date = (!$start_date) ? carbon()->now()->subMonth()->format('Y-m-25') : $start_date;
        // $end_date = (!$end_date) ? carbon()->now()->format('Y-m-26') : $end_date;
        // $count_discrepancies = $this->attendance_discrepancies()
        //                             ->whereDate('attendance_date', '>', $start_date)
        //                             ->whereDate('attendance_date', '<', $end_date)
        //                             ->get()->count();
        // if($count_discrepancies < 6){
        //     return true;
        // }
        // return false;
    }

    // probation end date
    public function probation_end_date()
    {
        $status = $this->employee_status()
                        ->where('status', 'Probation')
                        ->orderBy('end_at', 'desc')
                        ->first();
        return $status->end_at;
    }

    /**
     * Attribute Getters and Setters
     */
    public function getEmployeeCodeAttribute()
    {
        return str_pad($this->id, 7, "0", STR_PAD_LEFT);
    }
    /**
     * full_name
     */
    public function full_name()
    {
        return $this->full_name.' '.$this->father_name;
    }
    /**
     * full_name
     */
    public function profile_initial()
    {
        $first_name = explode(' ', $this->full_name);
        $last_name = explode(' ', $this->father_name);
        $profile_initial = '';
        if(count($first_name) > 1){
            $profile_initial = "{$first_name[0][0]}{$first_name[1][0]}";
        } else {
            $profile_initial = "{$first_name[0][0]}{$last_name[0][0]}";
        }
        return $profile_initial;
    }
}
