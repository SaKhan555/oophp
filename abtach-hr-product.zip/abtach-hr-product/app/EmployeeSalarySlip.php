<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class EmployeeSalarySlip extends Model
{
    protected $guarded = ['id'];
    protected $casts = [
    	'additions' => 'array',
    	'deductions' => 'array',
        'deduction_days_amounts' => 'array',
        'bank_details' => 'array'
    ];
    protected $dates = [
    	'months'
    ];

    // belongs to employee
    public function employee()
    {
    	return $this->belongsTo(Employee::class);
    }
    // deduction days getter
    public function getDeductionDaysAttribute()
    {
        return ($this->total_days - $this->earning_days);
    }
    // deducted salary getter
    public function getDeductedSalaryAttribute()
    {
        return ($this->per_day_salary * $this->deduction_days);
    }
}
