<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class EmployeeGrievanceComment extends Model
{
	protected $guarded = ['id'];

	// belongs to employee
	public function employee()
	{
		return $this->belongsTo(Employee::class);
	}
	// belongs to grievance
	public function grievance()
	{
		return $this->belongsTo(EmployeeGrievance::class, 'grievance_id');
	}
	// actual status
	public function actual_status()
	{
		return ($this->status) ? 'Resolved' : 'Pending';
	}
}
