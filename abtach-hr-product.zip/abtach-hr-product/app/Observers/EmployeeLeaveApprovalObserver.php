<?php

namespace App\Observers;

use App\EmployeeLeaveApproval;

class EmployeeLeaveApprovalObserver
{
    /**
     * Listen to the EmployeeLeaveApproval created event.
     *
     * @param  EmployeeLeaveApproval  $leave_approval
     * @return void
     */
    public function created(EmployeeLeaveApproval $leave_approval)
    {
        $leave_application = $leave_approval->leave_application;
        if($leave_application){
            $leave_application->update([
                    'status' => $leave_approval->status
                ]);
        }
    }
}