<?php

namespace App\Observers;

use Illuminate\Support\Facades\Mail;
use App\Employee;
use APp\EmployeeGrievanceComment;
use App\Mail\EmployeeGrievanceCommentEmail;

class EmployeeGrievanceCommentObserver
{
    /**
     * Listen to the EmployeeAttendanceDiscrepancy created event.
     *
     * @param  EmployeeAttendanceDiscrepancy $discrepancy
     * @return void
     */
    public function created(EmployeeGrievanceComment $grievance_comment)
    {
        $grievance = $grievance_comment->grievance;
        if($grievance){
            // update grievance status
            $grievance->update(['status' => $grievance_comment->status]);
            // send notification email to employee
            $employee = $grievance->employee;
            if($employee && $employee->email) {
                Mail::to($employee->email)->cc(config('general.emails.cc_default'))->send(new EmployeeGrievanceCommentEmail($grievance_comment));
            }
        }
    }
}