<?php

namespace App\Observers;

use App\EmployeeTicketTransfer;
use Illuminate\Support\Facades\Mail;
use App\Mail\EmployeeTicketTransferEmail;

class EmployeeTicketTransferObserver
{
    /**
     * Listen to the EmployeeTicketTransfer created event.
     *
     * @param  EmployeeTicketTransfer  $ticket
     * @return void
     */
    public function created(EmployeeTicketTransfer $ticket_transfer)
    {
        $ticket = $ticket_transfer->ticket;
        if($ticket){
            $ticket->update([
                'category_id' => $ticket_transfer->transfer_to
            ]);
            $ticket_category = $ticket->category;
            if($ticket_category){
                $employees_emails = $ticket_category->employees()->pluck('email')->toArray();
                if($employees_emails){
                    Mail::to($employees_emails)->cc([
                            config('general.emails.cc_default'),
                        ])->send(new EmployeeTicketTransferEmail($ticket_transfer));
                }
            }
        }
    }
}