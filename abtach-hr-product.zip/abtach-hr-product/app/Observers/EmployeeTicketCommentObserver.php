<?php

namespace App\Observers;

use Illuminate\Support\Facades\Mail;
use App\Mail\EmployeeTicketCommentEmail;
use App\Mail\EmployeeTicketReopenEmail;
use App\Mail\EmployeeTicketReopenEmployeeEmail;
use App\EmployeeTicketComment;

class EmployeeTicketCommentObserver
{
    /**
     * Listen to the EmployeeTicketComment created event.
     *
     * @param  EmployeeTicketComment  $ticket_comment
     * @return void
     */
    public function created(EmployeeTicketComment $ticket_comment)
    {
        $ticket = $ticket_comment->ticket;
        if($ticket) {
            $ticket_data = [
                'status_id' => $ticket_comment->status_id
            ];
            if($ticket_comment->status_id == 4){
                $ticket_data["open"] = 0;
            } else {
                $ticket_data["open"] = 1;
            }
            $ticket->update($ticket_data);
            if($ticket->employee_id == auth()->id()){
                $emails = $ticket->category->employee_emails();
            } else {
                $emails = ($ticket->employee) ? $ticket->employee->email : '';
            }
            if($emails){
                $mail = Mail::to($emails)->cc([
                            config('general.emails.cc_default'),
                        ]);
                if($ticket_comment->status_id == 5){
                    if($ticket->employee_id == auth()->id()){
                        $mail->send(new EmployeeTicketReopenEmail($ticket_comment));
                    } else {
                        $mail->send(new EmployeeTicketReopenEmployeeEmail($ticket_comment));
                    }
                } else {
                    $mail->send(new EmployeeTicketCommentEmail($ticket_comment));
                }
            }
        }
    }
}