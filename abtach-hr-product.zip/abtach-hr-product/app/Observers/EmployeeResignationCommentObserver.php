<?php

namespace App\Observers;

use App\EmployeeResignationComment;
use Illuminate\Support\Facades\Mail;
use App\Mail\NotifyEmployeeNoticePeriod;
use App\Mail\ResignationCommentEmail;
use App\EmployeeStatus;
use App\EmployeeFinalSettlement;

class EmployeeResignationCommentObserver
{
    /**
     * Listen to the EmployeeResignationComment created event.
     *
     * @param  EmployeeResignationComment  $leave_approval
     * @return void
     */
    public function created(EmployeeResignationComment $resignation_comment)
    {
        $employee = $resignation_comment->resignation->employee;
        $resignation = $resignation_comment->resignation;
        if($employee){
            // send email process
            $cc_emails = [
                config('general.emails.cc_default'),
                config('general.emails.salmanyousuf'),
                config('general.emails.hr'),
            ];
            if($employee->manager_employee){
                $cc_emails[] = $employee->manager_employee->email;
            }
            if(auth()->user()->role == 'admin'){
                // if comment status is approved
                if($resignation_comment->status){
                    // update resignation date
                    if(request('end_date')){
                        $end_date = carbon()->createFromFormat('d/m/Y',request('end_date'))->format('Y-m-d');
                        $resignation->update([
                            'end_date' => $end_date
                        ]);
                    }
                    // update status
                    $status = 'Notice Period';
                    $end_date = (request('end_date')) ? carbon()->createFromFormat('d/m/Y',request('end_date'))->format('Y-m-d') : $resignation->end_date;
                    $employee_status = $employee->employee_status()->first();
                    if(!$employee_status || ($employee_status->status && $employee_status->status != 'Notice Period')){
                        $employee_new_status = EmployeeStatus::create([
                            'employee_id' => $employee->id,
                            'status' => $status,
                            'comments' => 'resignation accepted',
                            'status_at' => $resignation->effective_date,
                            'end_at' => $end_date,
                        ]);
                    } elseif($employee_status->status == 'Notice Period'){
                        $employee_status->update([
                            'status_at' => $resignation->effective_date,
                            'end_at' => $end_date
                        ]);
                    }
                    $updated_true =  $employee->update(['current_status' => $status]);
                    // add final settlement
                    $clearance_date = carbon()->parse($end_date)->addDays(45)->format('Y-m-d');
                    EmployeeFinalSettlement::updateOrCreate([
                        'employee_id' => $employee->id
                    ], [
                        'date' => $clearance_date,
                        'status_id' => 2
                    ]);
                    // send email for notice period
                    if($employee->email) {
                        Mail::to($employee->email)->cc($cc_emails)->send(new NotifyEmployeeNoticePeriod($employee, $end_date, 'Your resignation has been approved'));
                    }
                }
            }
            // send comment status email
            if($resignation_comment->status == 0){
                // remove final settlement
                $employee->final_settlement()->delete();
                // move employee to previous status
                if(in_array(strtolower($employee->current_status), ['notice period', 'separation'])){
                    $employee->employee_status()->where('status', '=', $employee->current_status)->orderBy('status_at', 'desc')->limit(1)->delete();
                    $employee_status = $employee->employee_status()->where('status', '!=', $employee->current_status)->orderBy('status_at', 'desc')->first();
                    $employee->update([
                        'current_status' => $employee_status->status
                    ]);
                }
                // send email to employee
                if($employee->email) {
                    Mail::to($employee->email)->cc([config('general.emails.hr'), config('general.emails.cc_default')])->send(new ResignationCommentEmail($resignation_comment, $employee));
                }
            }
        }
    }
}