<?php

namespace App\Observers;

use Illuminate\Support\Facades\Mail;
use App\EmployeeAttendance;
use App\EmployeeAttendanceDiscrepancy;
use App\Mail\EmployeeAttendanceDiscrepancyEmail;

class EmployeeAttendanceDiscrepancyObserver
{
    /**
     * Listen to the EmployeeAttendanceDiscrepancy created event.
     *
     * @param  EmployeeAttendanceDiscrepancy $discrepancy
     * @return void
     */
    public function created(EmployeeAttendanceDiscrepancy $discrepancy)
    {
        // if($attendance){
            $employee = $discrepancy->employee;
            // send email process
            $cc_emails = array_filter([
                config('general.emails.cc_default'),
                config('general.emails.hr'),
            ], function($email) use($employee) {
                return $email != $employee->manager_employee->email;
            });

            Mail::to($employee->manager_employee->email)->cc($cc_emails)->send(new EmployeeAttendanceDiscrepancyEmail($employee, $discrepancy));
        // }
    }
}