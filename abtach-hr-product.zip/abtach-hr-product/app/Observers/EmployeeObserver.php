<?php

namespace App\Observers;

use Illuminate\Support\Facades\Mail;
use App\Mail\WelcomeEmployeeEmail;
use App\Mail\EmployeeSetPasswordEmail;
use App\Mail\NotifyEmployeePermenant;
use App\Employee;
use App\Note;

class EmployeeObserver
{
    /**
     * Listen to the Employee created event.
     *
     * @param  Employee $employee
     * @return void
     */
    public function created(Employee $employee)
    {
        // send emails
        if($employee->email && request('probation_period')){
            // send welcome email
            $cc_emails = [config('general.emails.cc_default')];
            if($employee->manager_employee) {
                $cc_emails[] = $employee->manager_employee->email;
            }
            $dept_employees = Employee::active()->where('department_id', $employee->department_id)->pluck('email','id')->toArray();
            $employee_ids = array_merge(
                [$employee->manager_id],
                $employee->all_manager_ids(),
                array_keys($dept_employees),
                [33]
            );
            $cc_emails = array_unique(array_merge($cc_emails, array_values($dept_employees)));
            $cc_emails = array_filter($cc_emails, function($email){
                return $email != null;
             });
            // add welcome note
             $note = Note::create([
                'user_id' => auth()->guard('admin_web')->id(),
                'title' => "Welcoming {$employee->full_name}",
                'content' => htmlspecialchars(view('admin.emails.employee.partials.welcome')->with([
                    'employee' => $employee
                ])),
                'employee_ids' => json_encode($employee_ids),
                'email_enabled' => 0
            ]);
             // send email
            Mail::to($employee->email)->cc($cc_emails)->send(new WelcomeEmployeeEmail($employee));

            if(!$employee->is_foreigner){
                // send portal account email
                Mail::to($employee->email)->send(new EmployeeSetPasswordEmail($employee));
                // send insurance email
                // Mail::to($employee->email)->cc(config('general.emails.cc_default'))->send(new NotifyEmployeePermenant($employee));
            }
        }
    }
}