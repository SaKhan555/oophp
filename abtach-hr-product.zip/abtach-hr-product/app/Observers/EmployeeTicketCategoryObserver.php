<?php

namespace App\Observers;

use App\EmployeeTicketCategory;
use App\EmployeeTicketCategoryAssign;

class EmployeeTicketCategoryObserver
{
    /**
     * Listen to the EmployeeTicket saved event.
     *
     * @param  EmployeeTicketCategory $ticket_category
     * @return void
     */
    public function saved(EmployeeTicketCategory $ticket_category)
    {
        $employee_ids = $ticket_category->employee_ids;
        $ticket_category->employees()->sync($employee_ids);
    }
}