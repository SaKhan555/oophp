<?php

namespace App\Observers;

use App\EmployeeTicket;
use Illuminate\Support\Facades\Mail;
use App\Mail\EmployeeTicketEmail;

class EmployeeTicketObserver
{
    /**
     * Listen to the EmployeeTicket created event.
     *
     * @param  EmployeeTicket  $ticket
     * @return void
     */
    public function created(EmployeeTicket $ticket)
    {
        $ticket_category = $ticket->category;
        if($ticket_category){
            $employees_emails = $ticket_category->employees()->pluck('email')->toArray();
            if($employees_emails){
                Mail::to($employees_emails)->cc([
                        config('general.emails.cc_default'),
                    ])->send(new EmployeeTicketEmail($ticket_category, $ticket));
            }
        }
    }
}