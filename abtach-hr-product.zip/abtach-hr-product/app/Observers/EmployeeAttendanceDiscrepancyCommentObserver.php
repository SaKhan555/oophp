<?php

namespace App\Observers;

use Illuminate\Support\Facades\Mail;
use App\EmployeeAttendance;
use App\EmployeeAttendanceDiscrepancyComment;
use App\Mail\EmployeeAttendanceDiscrepancyCommentEmail;

class EmployeeAttendanceDiscrepancyCommentObserver
{
    /**
     * Listen to the EmployeeAttendanceDiscrepancy created event.
     *
     * @param  EmployeeAttendanceDiscrepancy $discrepancy
     * @return void
     */
    public function created(EmployeeAttendanceDiscrepancyComment $discrepancy_comment)
    {
        $discrepancy = $discrepancy_comment->discrepancy;
        $employee = $discrepancy->employee;
        // update attendance if discrepancy approved
        if($discrepancy_comment->status) {
            $shift = $employee->shift($discrepancy->attendance_date);
            if($shift){
                $attendance = $discrepancy->attendance;
                $date = carbon()->parse($discrepancy->attendance_date)->format('Y-m-d');
                if($discrepancy->attendance_type == '01'){
                    $time = carbon()->createFromFormat('h:i A',$shift->check_in)->format('H:i:s');
                } else {
                    $time = carbon()->createFromFormat('h:i A',$shift->check_out)->format('H:i:s');
                }
                $timestamp = "$date $time";
                if($attendance){
                    $prev_timestamp = $attendance->checked_at;
                    $attendance->update([
                        'checked_at' => $timestamp,
                    ]);
                } else {
                    $attendance = EmployeeAttendance::create([
                        'employee_id' => $employee->employee_id,
                        'checked_at' => $timestamp,
                        'created_at' => $timestamp,
                        'type' => 'manual',
                        'status' => $discrepancy->attendance_type
                    ]);
                    // add attendance id to discrepancy and discrepancy comment
                    $discrepancy->update([
                        'attendance_id' => $attendance->id
                    ]);
                    $discrepancy_comment->update([
                        'attendance_id' => $attendance->id
                    ]);
                    $prev_timestamp = '';
                }
                // create log
                $attendance->create_log([
                    'action' => 'discrepancy approved',
                    'previous_time' => $prev_timestamp,
                    'new_time' => $timestamp,
                ]);
            }
        }
        // update discrepancy status
        $discrepancy->update([
            'status' => $discrepancy_comment->status
        ]);
        // send email
        if($employee) {
            $cc_emails = array_filter([
                config('general.emails.cc_default'),
                config('general.emails.hr'),
            ], function($email) use($employee) {
                return $email != $employee->email;
            });

            Mail::to($employee->email)->cc($cc_emails)->send(new EmployeeAttendanceDiscrepancyCommentEmail($discrepancy_comment));
        }

    }
}