<?php

namespace App\Observers;

use Illuminate\Support\Facades\Mail;
use APp\EmployeeGrievance;
use App\Mail\EmployeeGrievanceEmail;

class EmployeeGrievanceObserver
{
    /**
     * Listen to the EmployeeAttendanceDiscrepancy created event.
     *
     * @param  EmployeeAttendanceDiscrepancy $discrepancy
     * @return void
     */
    public function created(EmployeeGrievance $grievance)
    {
        Mail::to(config('general.emails.cc_default'))->send(new EmployeeGrievanceEmail($grievance));
    }
}