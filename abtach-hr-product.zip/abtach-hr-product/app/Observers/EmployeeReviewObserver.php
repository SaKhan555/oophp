<?php

namespace App\Observers;

use Illuminate\Support\Facades\Mail;
use App\EmployeeReview;
use App\Note;
use App\Mail\EmployeeReviewEmail;

class EmployeeReviewObserver
{
    /**
     * Listen to the EmployeeAttendanceDiscrepancy created event.
     *
     * @param  EmployeeAttendanceDiscrepancy $discrepancy
     * @return void
     */
    public function created(EmployeeReview $review)
    {
        $note = Note::create([
            'user_id' => 0,
            'title' => "{$review->by_employee->full_name} Reviewed About {$review->to_employee->full_name}",
            'content' => $review->review,
            'employee_ids' => json_encode([$review->submit_by, $review->submit_to]),
            'email_enabled' => 0
        ]);
        Mail::to(config('general.emails.hr'))->send(new EmployeeReviewEmail($review));
    }
}