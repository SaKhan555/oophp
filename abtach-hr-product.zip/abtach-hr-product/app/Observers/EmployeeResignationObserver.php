<?php

namespace App\Observers;

use App\EmployeeResignation;
use Illuminate\Support\Facades\Mail;
use App\Mail\EmployeeResignationEmail;
use App\EmployeeFinalSettlement;

class EmployeeResignationObserver
{
    /**
     * Listen to the EmployeeResignation created event.
     *
     * @param  EmployeeLeaveApproval  $leave_approval
     * @return void
     */
    public function created(EmployeeResignation $resignation)
    {
        $employee = $resignation->employee;

        if($employee && $employee->manager_employee){
            // create final settlement
            $clearance_date = carbon()->parse($resignation->end_date)->addDays(45)->format('Y-m-d');
            EmployeeFinalSettlement::updateOrCreate([
                'employee_id' => $employee->id
            ], [
                'date' => $clearance_date,
                'status_id' => 2
            ]);
            // send email
            $manager_email = $employee->manager_employee->email;
            $cc_emails = [
                    config('general.emails.cc_default'),
                    config('general.emails.hr')
                ];
            $cc_emails = array_filter($cc_emails, function($cc_email) use($manager_email){
                return $cc_email != $manager_email;
            });

            Mail::to($manager_email)
                ->cc($cc_emails)
                ->send(new EmployeeResignationEmail($employee, $resignation));
        }
    }
}