<?php

namespace App\Observers;

use App\Note;
use App\Employee;
use App\EmployeeNote;
use Illuminate\Support\Facades\Mail;
use App\Mail\NoteEmail;

class NoteObserver
{
    /**
     * Listen to the EmployeeTicket created event.
     *
     * @param  EmployeeTicket  $ticket
     * @return void
     */
    public function created(Note $note)
    {
        $employee_ids = [];
        foreach(json_decode($note->employee_ids) as $employee_id){
            $employee_ids[] = $employee_id;
        }
        if($employee_ids){
            // assign note to employees
            $note->employee_notes()->sync($employee_ids);
            // if email enabled for this note
            if($note->email_enabled){
                // send email
                $employees = Employee::active()->whereIn('id', $employee_ids)->pluck('email')->toArray();
                $employee_emails = array_unique(
                    array_values($employees)
                );
                $employee_emails = array_filter($employee_emails,function($employee_emails){
                    return $employee_emails != null;
                });
                $cc_emails = [];
                $cc_email_1 = config('general.emails.cc_default');
                $cc_email_2 = config('general.emails.salmanyousuf');
                if(!in_array($cc_email_1, $employee_emails)){
                    $cc_emails[] = $cc_email_1;
                }
                if(!in_array($cc_email_2, $employee_emails)){
                    $cc_emails[] = $cc_email_2;
                }
                Mail::to($employee_emails)->cc($cc_emails)->send(new NoteEmail($note));
            }
        }
    }
}