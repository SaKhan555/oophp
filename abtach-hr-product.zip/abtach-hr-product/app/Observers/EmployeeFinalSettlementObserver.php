<?php

namespace App\Observers;

use App\EmployeeFinalSettlement;

class EmployeeFinalSettlementObserver
{
    /**
     * Listen to the EmployeeFinalSettlement created event.
     *
     * @param  EmployeeFinalSettlement  $leave_approval
     * @return void
     */
    public function updated(EmployeeFinalSettlement $final_settlement)
    {
        $employee = $final_settlement->employee;
        if($employee) {
            $employee->update([
                'clearance_date' => carbon()->parse($final_settlement->date)
            ]);
        }
    }
}