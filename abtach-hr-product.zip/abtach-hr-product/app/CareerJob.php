<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\Traits\RecordActivity;

class CareerJob extends Model
{
    use RecordActivity;

    protected $table = 'career_jobs';
    protected $guarded = ['id'];

    /**
     * Relations
     */
    public function applications()
    {
    	return $this->hasMany('App\JobApplication');
    }
	
	
	public function job_category()
    {
        return $this->belongsTo(JobCategory::class,  'job_category_id', 'id');
    }
}
