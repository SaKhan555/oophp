<?php

namespace App\Providers;

use App\Currency;
use App\EmployeeDepartment;
use App\JobApplication;
use App\CareerJob;
use App\Unit;
use App\Employee;
use App\EmployeeLeaveApproval;
use App\EmployeeResignation;
use App\EmployeeResignationComment;
use App\EmployeeFinalSettlement;
use App\EmployeeTicket;
use App\EmployeeTicketComment;
use App\EmployeeTicketCategory;
use App\EmployeeTicketTransfer;
use App\EmployeeAttendanceDiscrepancy;
use App\EmployeeAttendanceDiscrepancyComment;
use App\Note;
use App\EmployeeGrievance;
use App\EmployeeGrievanceComment;
use App\EmployeeReview;
use App\Observers\EmployeeLeaveApprovalObserver;
use App\Observers\EmployeeResignationObserver;
use App\Observers\EmployeeResignationCommentObserver;
use App\Observers\EmployeeFinalSettlementObserver;
use App\Observers\EmployeeTicketObserver;
use App\Observers\EmployeeTicketCategoryObserver;
use App\Observers\EmployeeTicketCommentObserver;
use App\Observers\EmployeeTicketTransferObserver;
use App\Observers\EmployeeAttendanceDiscrepancyObserver;
use App\Observers\EmployeeAttendanceDiscrepancyCommentObserver;
use App\Observers\EmployeeObserver;
use App\Observers\NoteObserver;
use App\Observers\EmployeeGrievanceObserver;
use App\Observers\EmployeeGrievanceCommentObserver;
use App\Observers\EmployeeReviewObserver;
use Illuminate\Queue\Jobs\Job;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
        Employee::observe(EmployeeObserver::class);
        EmployeeLeaveApproval::observe(EmployeeLeaveApprovalObserver::class);
        EmployeeResignation::observe(EmployeeResignationObserver::class);
        EmployeeResignationComment::observe(EmployeeResignationCommentObserver::class);
        EmployeeFinalSettlement::observe(EmployeeFinalSettlementObserver::class);
        EmployeeTicket::observe(EmployeeTicketObserver::class);
        EmployeeTicketCategory::observe(EmployeeTicketCategoryObserver::class);
        EmployeeTicketComment::observe(EmployeeTicketCommentObserver::class);
        EmployeeTicketTransfer::observe(EmployeeTicketTransferObserver::class);
        EmployeeAttendanceDiscrepancy::observe(EmployeeAttendanceDiscrepancyObserver::class);
        EmployeeAttendanceDiscrepancyComment::observe(EmployeeAttendanceDiscrepancyCommentObserver::class);
        EmployeeGrievance::observe(EmployeeGrievanceObserver::class);
        EmployeeGrievanceComment::observe(EmployeeGrievanceCommentObserver::class);
        Note::observe(NoteObserver::class);
        EmployeeReview::observe(EmployeeReviewObserver::class);
    }

    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        $this->app->singleton('currencies_all', function () {
            return cache()->rememberForever('currencies_all', function() {
                return Currency::get();
            });
        });
        $this->app->singleton('units', function () {
                return Unit::where('status', 1)->pluck('name', 'id')->toArray();
        });

        $this->app->singleton('departments', function () {
            return EmployeeDepartment::pluck('name', 'id')->toArray();
        });
        $this->app->singleton('job_categories', function () {
                // return JobApplication::select('category')->groupBy('category')->pluck('category')->toArray();
                return CareerJob::orderBy('title','asc')->get();
        });
    }
}
