<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class EmployeeLeave extends Model
{
    protected $guarded = ['id'];

    /**
     * belongs to an employee
     */
    public function employee()
    {
    	return $this->belongsTo(Employee::class, 'employee_id', 'id');
    }

    public function get_availed_leaves()
    {
    	$month = carbon()->parse($this->month)->format('m');
    	$employee_id = $this->employee_id;
    	$total_approved_leaves = EmployeeLeaveApplication::where('employee_id', $employee_id)
    		->where('status', 1)
    		->whereMonth('start_date', '=', $month)
    		->orWhere(\DB::raw('end_date'), '=', $month)
    		->pluck('total_leave')->toArray();

    	return array_sum($total_approved_leaves);
    }

    public function get_cf_leaves()
    {
    	$month = carbon()->parse($this->month)->subMonths(1)->format('m');
    	$employee_id = $this->employee_id;
    	$previous_approved_leaves = EmployeeLeaveApplication::where('employee_id', $employee_id)
    		->where('status', 1)
    		->where(\DB::raw('MONTH(start_date)'), '<=', $month)
    		->orWhere(\DB::raw('MONTH(end_date)'), '=<', $month)
    		->pluck('total_leave')->toArray();
    	$previous_approved_leaves = array_sum($previous_approved_leaves);

    	$previous_leaves = $this->employee->leaves()
    		->where(\DB::raw('MONTH(month)'),'<=', $month)
    		->pluck('total_leave')->toArray();
    	$previous_leaves = array_sum($previous_leaves);

    	return ($previous_leaves - $previous_approved_leaves);
    }
}
