<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class EmployeeDesignation extends Model
{
   protected $guarded = ['id'];
}
