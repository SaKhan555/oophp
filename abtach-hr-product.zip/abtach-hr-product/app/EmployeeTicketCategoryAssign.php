<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class EmployeeTicketCategoryAssign extends Model
{
    protected $guarded = [
    	'id'
    ];
}
