<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class EmployeeTicketComment extends Model
{
    protected $guarded = ['id'];
    protected $dates = ['datetime'];

    /**
     * belongsto employee
     */
    public function employee()
    {
    	return $this->belongsTo(Employee::class, 'employee_id');
    }
    /**
     * belongsto ticket
     */
    public function ticket()
    {
    	return $this->belongsTo(EmployeeTicket::class, 'ticket_id');
    }
    /**
     * belongsto status
     */
    public function status()
    {
    	return $this->belongsTo(EmployeeTicketStatus::class, 'status_id');
    }
}
