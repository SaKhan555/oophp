<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class EmployeeDepartmentAssign extends Model
{
    protected $guarded = ['id'];

    /**
     * belongs to department
     */
    public function department()
    {
    	return $this->belongsTo(EmployeeDepartment::class);
    }
    /**
     * belongs to employee
     */
    public function employee()
    {
    	return $this->belongsTo(Employee::class);
    }
}
