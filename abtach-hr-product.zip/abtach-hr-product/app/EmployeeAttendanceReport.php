<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class EmployeeAttendanceReport extends Model
{
    protected $guarded = ['id'];

    // belogns to an employee
    public function employee()
    {
    	return $this->belongsTo(Employee::class);
    }
}
