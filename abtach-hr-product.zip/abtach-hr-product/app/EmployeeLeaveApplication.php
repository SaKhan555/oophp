<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\Traits\RecordActivity;

class EmployeeLeaveApplication extends Model
{
    use RecordActivity;
    protected $guarded = ['id'];

    /**
     * Relations
     */
    /**
     * belongs to leave type
     */
    public function leave_type()
    {
    	return $this->belongsTo(EmployeeLeaveType::class, 'leave_type_id');
    }
    /**
     * belongs to employee
     */
    public function employee()
    {
        return $this->belongsTo(Employee::class);
    }
    /**
     * has many approvals
     */
    public function approvals()
    {
    	return $this->hasMany(EmployeeLeaveApproval::class,'leave_id')->latest();
    }
    /**
     * Restrict manager to fetch leave applications
     */
    public function scopeRestrictManager($query) 
    {
        $role = strtolower(auth()->guard('web')->user()->role);
        if($role == 'admin'){
            if(request('manager_id')){
                return $query->whereHas('employee', function($q) {
                    return $q->where('manager_id', request('manager_id'));
                });
            }
            return $query;
        } else {
            $manager_ids = array_merge([
                auth()->id()
            ], auth()->user()->reporting_managers());
            return $query->whereHas('employee', function($q) use($manager_ids) {
                        return $q->whereIn('manager_id', $manager_ids);
                    });
        }
    }
    /**
     * search scope
     */
    public function scopeSearch($query)
    {
        $employee_id = request('employee_id');
        $date = request('date');
        $leave_type_id = request('leave_type_id');
        $status = request('status');
        if($employee_id){
            $query = $query->where('employee_id', $employee_id);
        }
        if($date){
            $date = carbon()->createFromFormat('d/m/Y', $date)->format('Y-m-d');
            $query = $query->whereDate('start_date', '<=' ,$date)->whereDate('end_date','>=', $date);
        }
        if($leave_type_id){
            $query = $query->where('leave_type_id', $leave_type_id);
        }
        if(!is_null($status)){
            if($status == 2){
                $query = $query->whereDoesntHave('approvals');
            } else {
                $query = $query->where('status', $status)->whereHas('approvals');
            }
        }
        return $query;
    }
    /**
     * Leave status
     */
    public function approval_status()
    {
        $approvals = $this->approvals();
        $comments_count = $approvals->count();
        $approval = $approvals->first();
        if(!$comments_count){
            return 'pending';
        } elseif($approval->status) {
            return 'approved';
        } else {
            return 'disapproved';
        }
    }
}
