<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class EmployeeResignationComment extends Model
{
    use SoftDeletes;
    
    protected $guarded = ['id'];

    // belongs to a resignation
    public function resignation()
    {
    	return $this->belongsTo(EmployeeResignation::class, 'resignation_id', 'id');
    }
    // belongs to employee
    public function manager()
    {
        return $this->belongsTo(Employee::class, 'manager_id', 'id');
    }
    // status
    public function status()
    {
    	return ($this->status) ? 'Approved' : 'Disapproved';
    }
}
