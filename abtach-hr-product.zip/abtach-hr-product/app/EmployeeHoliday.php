<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class EmployeeHoliday extends Model
{
    protected $guarded = ['id'];
}
