<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Notifications\Notifiable;
use Illuminate\Foundation\Auth\User as Authenticatable;
use App\Traits\RecordActivity;

class User extends Authenticatable
{
    use RecordActivity, Notifiable, SoftDeletes;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $guarded = [
        'id'
    ];
    protected $table = 'users_portal';

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];

    /**
     * @param $value
     */
   /* public function setPasswordAttribute($value)
    {
        $this->attributes['password'] = bcrypt($value);
    }*/
    /**
     * has many notifications
     */
    public function notifications()
    {
        return $this->hasMany(Notification::class, 'user_id');
    }
    /**
     * has many unseen notifications
     */
    public function unseen_notifications()
    {
        return $this->hasMany(Notification::class, 'user_id')->where('seen', 0);
    }


    public function rules ($id=null, $merge=[]) {
        return array_merge(
            [
                'name' => 'required',
                'email' => 'required|email|unique:users_portal,email' . ($id ? ",$id" : ''),
            ],
            $merge);
    }

    public function scopeSearch($query)
    {
        $s = trim(request('s'));
        if($s) {
            $query = $query->where('name', 'LIKE', '%' . $s . '%')
                ->orWhere('email', 'LIKE', '%' . $s . '%');
        }

        return $query;

    }
    // belongs to role
    public function role()
    {
        return $this->belongsTo(Role::class);
    }
    // picture url
    public function picture_url()
    {
        if($this->picture && file_exists("../public/uploads/user/avatars/{$this->picture}")){
            return '/uploads/user/avatars/'.$this->picture;
        }
        return '/assets/new-theme/images/avatar-male.svg';
    }

}
