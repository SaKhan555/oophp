<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\Traits\RecordActivity;

class JobCategory extends Model
{
    use RecordActivity;

    protected $table = 'job_categories';
    protected $guarded = ['id'];

    /**
     * Relations
     */
    /**
     * has many jobs
     */
    public function jobs() 
    {
    	return $this->hasMany('App\CareerJob');
    }
}
