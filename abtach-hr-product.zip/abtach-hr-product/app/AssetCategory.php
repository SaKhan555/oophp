<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AssetCategory extends Model
{
    protected $guarded = ['id'];

    // get name and ids
    public function scopeList($query)
    {
    	return $query->pluck('name', 'id')->toArray();
    }
}
