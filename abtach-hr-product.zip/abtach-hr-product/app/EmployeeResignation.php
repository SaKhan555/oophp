<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\Traits\RecordActivity;
use Illuminate\Database\Eloquent\SoftDeletes;

class EmployeeResignation extends Model
{
    use RecordActivity, SoftDeletes;

    protected $guarded = ['id'];
    protected $dates = [
        'effective_date'
    ];
    // belongs to employee
    public function employee()
    {
    	return $this->belongsTo(Employee::class);
    }
    // has one reason
    public function reason()
    {
    	return $this->belongsTo(EmployeeResignationReason::class, 'reason_id', 'id');
    }
    // has many comments
    public function status_comments()
    {
        return $this->hasMany(EmployeeResignationComment::class, 'resignation_id', 'id')->latest();
    }
    // restrict managers scope
    /**
     * Restrict manager to fetch leave applications
     */
    public function scopeRestrictManager($query) 
    {
        $role = strtolower(auth()->guard('web')->user()->role);
        $managers = array_merge([
                auth()->id()
            ], auth()->user()->reporting_managers());
        if($role == 'admin'){
            return $query;
        } else {
            return $query->whereHas('employee', function($q) use($managers) {
                    return $q->whereIn('manager_id', $managers);
                });
        }
    }
    /**
     * Search Scope
     */
    public function scopeSearch($query)
    {
        $s = request('s');
        $status = request('status');
        $reason = request('reason_id');
        if($s){
            $query = $query->whereHas('employee', function($q){
                return $q->search();
            });
        }
        if(!is_null($status)){
            if($status == 2){
                $query = $query->whereDoesntHave('status_comments');
            } else {
                $query = $query->whereHas('status_comments')->where('status', $status);
            }
        }
        if($reason){
            $query = $query->where('reason_id', $reason);
        }
        return $query;
    }
    // status
    public function status()
    {
        return ($this->status) ? 'Approved' : 'Disapproved';
    }
    // approval status
    /**
     * Leave status
     */
    public function approval_status()
    {
        $comments = $this->status_comments();
        $comments_count = $comments->count();
        $latest_comment = $comments->first();
        if(!$comments_count){
            return 'pending';
        } elseif($latest_comment->status) {
            if($latest_comment->manager->role == 'admin') {
                return 'approved';
            } else {
                return 'approved by ra';
            }
        } else {
            return 'disapproved';
        }
    }
}
