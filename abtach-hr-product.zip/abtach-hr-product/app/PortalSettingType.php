<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PortalSettingType extends Model
{
    //
}
