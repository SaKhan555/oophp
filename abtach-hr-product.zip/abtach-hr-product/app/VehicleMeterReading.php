<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\Traits\RecordActivity;

class VehicleMeterReading extends Model
{
    use RecordActivity;

    protected $guarded = ['id'];
    protected $dates = [
    	'created_at',
    	'updated_at',
    	'date'
    ];
    // belongs to car
    public function vehicle()
    {
    	return $this->belongsTo(CompanyVehicle::class, 'vehicle_id', 'id');
    }
}
