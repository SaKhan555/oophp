<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\Traits\RecordActivity;

class Letter extends Model
{
	use RecordActivity;
    protected $guarded = ['id'];

}
