<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\Traits\RecordActivity;

class EmployeeTicket extends Model
{
    use RecordActivity;
    protected $guarded = ['id'];

    /**
     * belongs to ticket category
     */
    public function category()
    {
    	return $this->belongsTo(EmployeeTicketCategory::class, 'category_id');
    }
    /**
     * belongs to ticket employee
     */
    public function employee()
    {
    	return $this->belongsTo(Employee::class);
    }
    /**
     * belongs to status
     */
    public function status()
    {
        return $this->belongsTo(EmployeeTicketStatus::class, 'status_id');
    }
    /**
     * has many comments
     */
    public function comments()
    {
        return $this->hasMany(EmployeeTicketComment::class, 'ticket_id')->orderBy('datetime', 'desc');
    }
    /**
     *  has many transfers
     */
    public function transfers()
    {
        return $this->hasmany(EmployeeTicketTransfer::class, 'ticket_id');
    }
    /**
     * ticket resolved by
     */
    public function resolved_by()
    {
        $comment = $this->comments()->where('status_id', 4)->latest()->first();
        if($comment && $comment->employee)
            return $comment->employee->full_name;
    }
    /**
     * search scope
     */
    public function scopeSearch($query)
    {
        $category_id = request('category_id');
        $status_id = request('status_id');
        $start_date = (request('start_date')) ? carbon()->createFromFormat('d/m/Y', request('start_date'))->format('Y-m-d') : '';
        $end_date = (request('end_date')) ? carbon()->createFromFormat('d/m/Y', request('end_date'))->format('Y-m-d') : '';
        if($start_date && $end_date){
            $query = $query->whereDate('created_at', '>=' ,$start_date)
                            ->whereDate('created_at', '<=', $end_date);
        }
        if($category_id){
            $query = $query->where('category_id', $category_id);
        }
        if($status_id){
            $query = $query->where('status_id', $status_id);
        }
    }
    /**
     * actual status
     */
    public function actual_status()
    {
        $status = 'new';
        if($this->status){
            $status = $this->status->name;
        }
        return $status;
    }
    /**
     * has access
     */
    public function has_access()
    {
        $role = auth()->user()->role;
        if($this->employee_id == auth()->id() || $role == 'admin'){
            return true;
        }
        return false;
    }
    /**
     * get tickets current employee can access
     * for employee portal use only
     */
    public function accessable_tickets()
    {
        $query = $this->query();
        if(auth()->user()->role != 'admin'){
            $query = $query->where('employee_id', auth()->id());
        }
        return $query;
    }
    /**
     * get tickets current employee can recieve
     * for employee portal use only
     */
    public function receivable_tickets()
    {
        $query = $this->query();
        if(auth()->user()->role != 'admin'){
            $query = $query->whereHas('category', function($q){
                return $q->whereIn('id', auth()->user()->ticket_category_ids());
            });
        }
        return $query;
    }

}
