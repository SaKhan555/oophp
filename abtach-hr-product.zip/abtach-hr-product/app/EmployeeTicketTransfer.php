<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class EmployeeTicketTransfer extends Model
{
   protected $guarded = ['id'];

	// belongs to employee
	public function employee()
	{
		return $this->belongsTo(Employee::class);
	}
	// belongs to ticket
	public function ticket()
	{
		return $this->belongsTo(EmployeeTicket::class);
	}
	// transfer from
	public function category_transfer_from()
	{
		return $this->belongsTo(EmployeeTicketCategory::class, 'transfer_from');
	}
	// transfer from
	public function category_transfer_to()
	{
		return $this->belongsTo(EmployeeTicketCategory::class, 'transfer_to');
	}
}
