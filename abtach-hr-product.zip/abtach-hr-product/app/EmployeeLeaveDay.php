<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class EmployeeLeaveDay extends Model
{
    protected $fillable = ['employee_id', 'vacation_days', 'home_work_days', 'jury_duty_days', 'sick_days', 'leaves_year'];
}
