<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class EmployeeTicketStatus extends Model
{
    protected $guarded = ["id"];

    /**
     * get ticket filtered
     */
   	public function get_filtered_list($ticket)
   	{
   		$query = $this->whereNotIn('id', [1,$ticket->status_id]);
        if($ticket->open){
            $query = $query->where('id','!=',5);
        } else {
            $query = $query->where('id',5);
        }
        return $query->pluck('name','id')->toArray();
   	}
}
