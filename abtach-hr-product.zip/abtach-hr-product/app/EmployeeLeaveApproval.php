<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\Traits\RecordActivity;

class EmployeeLeaveApproval extends Model
{
  use RecordActivity;
  protected $guarded = ['id'];

    /**
     * belongs to manager
     */
    public function manager() 
    {
    	return $this->belongsTo(Employee::class,'manager_id');
    }
    /**
     * belongs to a leave application
     */
   	public function leave_application()
   	{
   		return $this->belongsTo(EmployeeLeaveApplication::class, 'leave_id', 'id');
   	}
    
}
