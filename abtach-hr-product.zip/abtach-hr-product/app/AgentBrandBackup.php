<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AgentBrandBackup extends Model
{
    protected $guarded = ['id'];
    // belongs to agent
    public function agent()
    {
    	return $this->belongsTo(Agent::class);
    }
    // belongs to brand
    public function brand()
    {
    	return $this->belongsTo(Brand::class);
    }
}

