<?php

namespace App;

use App\Scopes\UserScope;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Expense extends Model
{
    use SoftDeletes;
    protected static function boot()
    {
        parent::boot();
        static::addGlobalScope(new UserScope());
    }
    protected $guarded = ['id'];

    public function scopeSearch($query)
    {
        $s = trim(request('s'));
        if($s) {
            $query = $query->where('amount', 'LIKE', '%' . $s . '%')
                ->orWhere('description', 'LIKE', '%' . $s . '%')
                ->orWhere('card', 'LIKE', '%' . $s . '%')
                ->orWhere('purchase', 'LIKE', '%' . $s . '%');
        }

        if(request('user_id')){
            $query = $query->where('user_id', request('user_id'));
        }
        if(request('payment_type')){
            $query = $query->where('payment_type', request('payment_type'));
        }
        if(request('unit_id')){
            $query = $query->where('unit_id', request('unit_id'));
        }

        return $query;
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsToMany
     */
    public function user()
    {
        return $this->belongsTo(User::class, 'user_id');
    }
    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsToMany
     */
    public function unit()
    {
        return $this->belongsTo(Unit::class, 'unit_id');
    }
	
	 /**
     * @param $value
     * @return string
     */
    public function getAmountAttribute($value)
    {
        return convertAmount($value);

    }
}
