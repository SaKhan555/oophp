<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class EmployeeMachineAttendance extends Model
{
    protected $table = 'employee_attendances2';
    protected $guarded = ['id'];

}
