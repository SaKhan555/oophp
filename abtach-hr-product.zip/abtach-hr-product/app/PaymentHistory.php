<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PaymentHistory extends Model
{
    protected $guarded = ['id'];
    
    protected $casts = [
        'actual' => 'json',
        'earning' => 'json',
        'deduction' => 'json',
        'bank_detail' => 'json',
        'employee_detail' => 'json',
        'notify' => 'boolean',
        'status' => 'boolean',
    ];
    protected $table = 'employees_payment_histories';

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsToMany
     */
    public function employee()
    {
        return $this->belongsTo(Employee::class, 'employee_id');
    }

    public function scopeSearch($query)
    {
        $s = trim(request('s'));
		if(request('email_status')) {
			$notify = (request('email_status') == 'no') ? 0 : 1; 
            $query = $query->where('notify',  $notify);
        }
        if($s) {
            $query = $query->where('employee_code', 'LIKE', '%' . $s . '%')
                ->orWhere('employee_id', 'LIKE', '%' . $s . '%');
        }
		
		if(request('criteria_key')) {
            $query = $query->whereHas('employee', function($q){
				$q->where(request('criteria_key'), 'LIKE', '%' . request('criteria_value') . '%');
			});
        }

        return $query;

    }

}
