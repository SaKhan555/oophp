<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class EmployeeTicketCategory extends Model
{
    protected $guarded = ['id'];
    protected $casts = [
    	'employee_ids' => 'array'
    ];
    /**
     * has many tickets
     */
    public function tickets()
    {
    	return $this->hasMany(EmployeeTicket::class, 'category_id', 'id');
    }
    /**
     * ticket category assignments
     */
    public function employees()
    {
        return $this->belongsToMany(Employee::class,
                                    'employee_ticket_category_employees','category_id','employee_id');
    }
    /**
     * scope accessable
     * for portal use only
     */
    public function scopeAccessable($query)
    {
        if(!auth()->user()->is_admin()){
            $query = $query->whereIn('id', auth()->user()->ticket_category_ids());
        }
        return $query;
    }
    /**
     * scope names and ids
     */
    public function scopeNamesAndIds($query)
    {
        return $query->pluck('name', 'id');
    }
    /**
     * employee emails
     */
    public function employee_emails()
    {
        return $this->employees()->pluck('email')->toArray();
    }
}
