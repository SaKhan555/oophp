<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class EmployeeForeignPassword extends Model
{
    protected $guarded = ['id'];

    // belongs to an employee\
    public function employee()
    {
    	return $this->belongsTo(Employee::class);
    }

}
