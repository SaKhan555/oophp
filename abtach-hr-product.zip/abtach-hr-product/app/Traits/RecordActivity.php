<?php

namespace App\Traits;

use App\Activity;

trait RecordActivity
{

    public static function bootRecordActivity()
    {
        foreach (static::getModelEvents() as $event) {
            static::$event(function ($model) use ($event) {
                $model->addActivity($event);
            });
        }
    }

    public static function getModelEvents()
    {
        if (isset(static::$recordEvents)) {
            return static::$recordEvents;
        }

        return [
            'created', 'updated', 'deleted'
        ];
    }

    public function addActivity($event)
    {
        $method = request()->method();
        if(request()->segment(1) == 'admin' && auth()->guard('admin_web')->check()){
            if($method != 'GET'){
                $name = strtolower((new \ReflectionClass($this))->getShortName());
                Activity::create([
                    'user_id' => (auth()->guard('admin_web')->check()) ? auth()->guard('admin_web')->id() : null,
                    'loggable_type' => get_class($this),
                    'loggable_id'   => $this->getKey(),
                    'ip' => request()->getClientIp(),
                    'method' => request()->method(),
                    'url' => request()->fullUrl(),
                    'event' => $event,
                    'subject' => $name
                ]);
            }
        }

    }

}
