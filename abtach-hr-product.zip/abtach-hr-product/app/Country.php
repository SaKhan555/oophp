<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Country extends Model
{
	protected $casts = [
		'currency' => 'array'
	];
    // has many employees
    public function employees()
    {
    	return $this->hasMany(Employee::class);
    }
    // get currency
    public function get_currency()
    {
    	return $this->currency;
    }
}
