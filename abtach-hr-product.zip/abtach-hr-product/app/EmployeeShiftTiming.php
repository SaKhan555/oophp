<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class EmployeeShiftTiming extends Model
{
    protected $guarded = ['id'];
    protected $table = 'employee_shift_timing_histories';

}
