<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Employee;
use App\EmployeeAttendanceReport;
class AddEmployeeAttendanceReport extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'employee:add_attendance_report';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Generates Employee Attendance Report';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $employees = Employee::active()->where('attendance_generated', 0)->orderBy('id', 'asc')->limit(6)->get();
        foreach($employees as $employee){
            if($employee){
                $month = carbon()->now()->format('m-Y');
                $checkinouts = period_interval(carbon()->parse("26-$month")->subMonths(1));
                $days = [];
                foreach($checkinouts as $day) {
                    $days[] = formatDate($day, 'd-m-Y');
                }
                $only_month = carbon()->createFromFormat('m-Y', $month)->format('m');
                $year = carbon()->createFromFormat('m-Y', $month)->format('Y');
                $leaves_applied = $employee->total_applied_leaves($only_month);
                $leaves_approved = $employee->total_approved_leaves($only_month);
                $month_attendance_data = array_map(function($day) use($employee){
                    if(!$employee->hour_based){
                        $current_attendance = new \App\Employee\Attendance($employee, $day);
                    } else {
                        $current_attendance = new \App\Employee\FlexibleAttendance($employee, $day);
                    }
                    $sandwitch = false;
                    if(formatDate($day, 'l') == 'Friday'){
                        $friday_date = carbon()->parse($day);
                        $monday_date = carbon()->parse($day)->addDays(3);
                        if($employee->hour_based){
                            $monday_attendance = new \App\Employee\FlexibleAttendance($employee, $monday_date->format('d-m-Y'));
                        } else {
                            $monday_attendance = new \App\Employee\Attendance($employee, $monday_date->format('d-m-Y'));
                        }
                        if(($current_attendance->actual_status() == 'absent' && $monday_attendance->actual_status() == 'absent') && ($employee->join_date->lessThan($friday_date))){
                            $sandwitch = true;
                        }
                    }
                    return [
                        'late_in' => ($current_attendance->actual_status() == 'late in'),
                        'early_out' => ($current_attendance->actual_status() == 'early out'),
                        'absent' => ($current_attendance->actual_status() == 'absent'),
                        'half_day' => ($current_attendance->actual_status() == 'half day'),
                        'extra_day' => ($employee->allowed_extra_days && $current_attendance->actual_status() == 'extra day'),
                        'extra_half_day' => ($employee->allowed_extra_days && $current_attendance->actual_status() == 'extra half day'),
                        'sandwitch' => $sandwitch
                    ];
                }, $days);
                $late_incomings = count(array_filter($month_attendance_data, function($i){
                    return $i['late_in'] == 1;
                }));
                $early_outs = count(array_filter($month_attendance_data, function($i){
                    return $i['early_out'] == 1;
                }));
                $absents = count(array_filter($month_attendance_data, function($i){
                    return $i['absent'] == 1;
                }));
                $halfdays = count(array_filter($month_attendance_data, function($i){
                    return $i['half_day'] == 1;
                }));
                $extra_days = count(array_filter($month_attendance_data, function($i){
                    return $i['extra_day'] == 1;
                }));
                $extra_half_days = count(array_filter($month_attendance_data, function($i){
                    return $i['extra_half_day'] == 1;
                }));
                $sandwitch_leaves = count(array_filter($month_attendance_data, function($i){
                    return $i['sandwitch'] == 1;
                }));
                $absents = (($absents - ($sandwitch_leaves * 2)) + ($sandwitch_leaves * 4));
                // calculate absents for new joinings
                $start_month = carbon()->parse("01-10-2018")->subMonth()->format('m');
                $att_start_date = carbon()->parse("26-$start_month-2018");
                if($employee->join_date->greaterThan($att_start_date)){
                    if($employee->join_date->format('d') > 26){
                        $diff_in_days = $att_start_date->diffInDays($employee->join_date);
                        $absents -= $diff_in_days;
                    } else {
                        $total_days_in_prev_month = cal_days_in_month(CAL_GREGORIAN, "$start_month", '2018');
                        if($total_days_in_prev_month == 31){
                            $absents -= 6;
                        } elseif($total_days_in_prev_month == 28){
                            $absents -= 3;
                        } elseif($total_days_in_prev_month == 29){
                            $absents -= 4;
                        } else {
                            $absents -= 5;
                        }
                    }
                }

                if($employee->is_flexible_timing){
                    $total_deduction = $absents;
                } elseif(strtolower($employee->sex) == 'female' && in_array(strtolower($employee->current_status), ['probation', 'permanent','notice period'])) {
                    $total_deduction = ((((floor($early_outs / 3) / 2)) + ($halfdays / 2)) + $absents);
                } else {
                    $total_deduction = ((((floor(($late_incomings + $early_outs) / 3) / 2)) + ($halfdays / 2)) + $absents);
                }

                EmployeeAttendanceReport::create([
                    'month' => carbon()->now()->format('Y-m-26'),
                    'employee_id' => $employee->id,
                    'sandwitch_leaves' => $sandwitch_leaves,
                    'absents' => $absents,
                    'late_ins' => ($employee->is_flexible_timing) ? 0 : $late_incomings,
                    'early_outs' => ($employee->is_flexible_timing) ? 0 : $early_outs,
                    'half_days' => ($employee->is_flexible_timing) ? 0 : $halfdays,
                    'extra_days' => ($extra_days + ($extra_half_days / 2)),
                    'leaves_applied' => $leaves_applied,
                    'leaves_approved' => $leaves_approved,
                    'total_deduction' => $total_deduction,
                    'flexible_timing' => ($employee->is_flexible_timing) ? 1 : 0
                ]);
                $employee->update([
                    'attendance_generated' => 1
                ]);
            }
        }
    }
}
