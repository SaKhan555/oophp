<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\Mail;
use App\Mail\SeparationEmployeeEmail;
use App\Employee;

class SendSeparationReport extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'employee:separation_report';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Send Employee Separation Report';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct(Employee $employee)
    {
        parent::__construct();
        $this->employee = $employee;
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $current = carbon()->now();
        if($current->format('l') == 'Friday'){
            $current = $current->addDays(3);
        } else {
            $current = $current->addDay();
        }
        $separations = $this->employee->where('current_status', 'Notice Period')->whereHas('employee_status',function($q) use($current){
            return $q->where('status', 'Notice Period')->whereDate('end_at', '=', $current->format('Y-m-d'))->orderBy('status_at', 'desc')->limit(1);
        })->get();
        if($separations->count()){
            // separation emails
            $separation_emails = [];
            foreach($separations as $separation){
                $separation_emails = array_merge($this->employee->active()->whereIn('id',$separation->all_manager_ids())->pluck('email')->toArray(), $separation_emails);
            }

            $hr_emails = $this->employee->active()->where('department_id', 10)->pluck('email')->toArray();
            $finance_emails = $this->employee->active()->where('department_id', 1)->pluck('email')->toArray();
            $it_emails = $this->employee->active()->where('department_id', 11)->pluck('email')->toArray();

            $cc_emails = array_filter(array_unique(array_merge(
                $hr_emails,
                $finance_emails,
                $it_emails,
                [ config('general.emails.cc_default'), 'muhammad.uzair@abtach.org' ]
            )), function($cc_email) use($separation_emails) {
                return !in_array($cc_email, $separation_emails);
            });
            Mail::to(array_unique($separation_emails))->cc($cc_emails)->send(new SeparationEmployeeEmail($separations));
        }

    }
}
