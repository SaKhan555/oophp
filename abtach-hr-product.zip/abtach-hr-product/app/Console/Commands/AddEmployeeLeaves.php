<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Employee;
use App\EmployeeLeave;
use Carbon\Carbon;

class AddEmployeeLeaves extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'employee:addleaves';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Add two leaves to employee account';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $last_month = Carbon::parse('first day of this month');
        $employees = Employee::where(['current_status' => 'Permanent'])->get();
        foreach($employees as $employee) {
            $employee_leave = $employee->leaves()->whereMonth('month',$last_month->format('m'))->whereYear('month', $last_month->format('Y'))->first();
            if(!$employee_leave) {
                $data = [
                    'employee_id' => $employee->id,
                    'total_leave' => 2,
                    'month' => $last_month->format('Y-m-d'),
                ];
                EmployeeLeave::create($data);
            }
        }
    }
}
