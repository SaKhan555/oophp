<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\Mail;
use App\Mail\NewJoiningEmployeeEmail;
use App\Employee;

class SendNewJoiningReport extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'employee:new_joining_report';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Send Email For New Joining Employees';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct(Employee $employee)
    {
        parent::__construct();
        $this->employee = $employee;
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        // $note = \App\Note::find(1);
        $current = carbon()->now();
        if($current->format('l') == 'Friday'){
            $current = $current->addDays(3);
        } else {
            $current = $current->addDay();
        }
        $new_joinings = $this->employee->whereDate('join_date', '=', $current->format('Y-m-d'))->get();

        if($new_joinings->count()){
            // new joining emails
            $new_joining_emails = [];
            foreach($new_joinings as $new_joining){
                $new_joining_emails = array_merge($this->employee->active()->whereIn('id',$new_joining->all_manager_ids())->pluck('email')->toArray(), $new_joining_emails);
            }

            $hr_emails = $this->employee->active()->where('department_id', 10)->pluck('email')->toArray();
            $finance_emails = $this->employee->active()->where('department_id', 1)->pluck('email')->toArray();
            $it_emails = $this->employee->active()->where('department_id', 11)->pluck('email')->toArray();

            $cc_emails = array_filter(array_unique(array_merge(
                $hr_emails,
                $finance_emails,
                $it_emails,
                [ config('general.emails.cc_default'), 'muhammad.uzair@abtach.org' ]
            )), function($cc_email) use($new_joining_emails) {
                return !in_array($cc_email, $new_joining_emails);
            });

            Mail::to(array_unique($new_joining_emails))->cc($cc_emails)->send(new NewJoiningEmployeeEmail($new_joinings));
        }
    }
}
