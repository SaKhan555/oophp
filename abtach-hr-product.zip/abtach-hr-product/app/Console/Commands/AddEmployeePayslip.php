<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Employee;
use App\EmployeeSalarySlip;
use Barryvdh\DomPDF\PDF;

class AddEmployeePayslip extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'employee:add_payslip';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Generates Employee Payslip';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    // pdf
    protected $pdf;
    public function __construct(PDF $pdf)
    {
        parent::__construct();
        $this->pdf = $pdf;
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $month = carbon()->now();
        $employees = Employee::active()->where('payslip_generated', 0)->whereDate('join_date', '<=', "2018-{$month->format('m')}-25")->orderBy('id', 'asc')->limit(3)->get();
        foreach($employees as $employee){
            if($employee){
                $current_payroll = new \App\Employee\Payroll($employee, $month->format('m-Y'));
                // $title = 'Salary Slip for the month of '.$month->format('F Y');
                // $salary_generated = 'Salary-E-'.$employee->employee_id.'-'.$month->format('m-Y').'.pdf';
                $data = [
                    'employee_id' => $employee->id,
                    'employee_code' => $employee->employee_id,
                    'month' => $month->format('Y-m-30'),
                    'additions' => $current_payroll->additions,
                    'deductions' => $current_payroll->deductions,
                    'deduction_days_amounts' => $current_payroll->deduction_days_amounts,
                    'per_day_salary' => $current_payroll->per_day_salary,
                    'gross_salary' => $current_payroll->gross_salary,
                    'net_salary' => $current_payroll->net_salary,
                    'actual_salary' => $current_payroll->actual_salary,
                    'total_days' => $current_payroll->total_days,
                    'earning_days' => $current_payroll->earning_days,
                    // 'pdf' => $salary_generated
                ];
                EmployeeSalarySlip::create($data);
                // $pdf = $this->pdf->loadView('employee.payroll.pdf', ['current_payroll' => $current_payroll,'employee'=> $employee, 'title' => $title])->save('public/uploads/payslips/' . $salary_generated);
                $employee->update(['payslip_generated' => 1]);
            }
        }
    }
}
