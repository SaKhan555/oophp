<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Employee;
use Illuminate\Support\Facades\Mail;
use App\Mail\EmployeeSetPasswordEmail;

class SendSetPasswordEmail extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'employee:setpassword';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Send set password link to employees';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $employee = Employee::where('set_password_email', 0)->active()->where('email','!=',null)->orderBy('id','asc')->first();
        if($employee && $employee->email){
            Mail::to($employee->email)->send(new EmployeeSetPasswordEmail($employee));
            $data = ['set_password_email' => 1];
            Employee::where('id', $employee->id)->update($data);
        }
    }
}
