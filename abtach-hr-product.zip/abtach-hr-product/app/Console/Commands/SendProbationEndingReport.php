<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Employee;
use App\User;
use App\Notification;
use Illuminate\Support\Facades\Mail;
use App\Mail\ProbationEndReportEmail;

class SendProbationEndingReport extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'employee:send_probation_end_report {type}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Sends probation ending report before one week';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $type = $this->argument('type');
        if($type == 'week') {
            $day = carbon()->now()->addWeek();
        } elseif($type == 'day') {
            $day = carbon()->now();
        }
        $employees = Employee::whereHas('employee_status', function($q) use($day) {
            return $q->where('status', 'Probation')
                        ->whereDate('end_at', '=', $day->format('Y-m-d'));
        })->get();
        if($employees->count()){
            $emails = array_merge([config('general.emails.cc_default'), config('general.emails.hr')], config('general.HR_emails'));
            Mail::to($emails)->send(new ProbationEndReportEmail($employees));
            $this->send_notifications($day, $employees);
        }
    }

    /**
     * send notifications
     */
    private function send_notifications($day, $employees)
    {
        $user_ids = User::where('type', 'admin')->pluck('id')->toArray();
        foreach($user_ids as $user_id){
            foreach($employees as $employee){
                $data = [
                    'user_id' => $user_id,
                    'title' => "Probation Ending",
                    'content' => "{$employee->full_name} {$employee->father_name}'s probation period is ending on {$day->format('d F Y')}",
                ];
                Notification::create($data);
            }
        }
    }
}
