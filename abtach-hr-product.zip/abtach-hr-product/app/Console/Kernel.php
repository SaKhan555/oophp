<?php

namespace App\Console;

use Illuminate\Console\Scheduling\Schedule;
use Illuminate\Foundation\Console\Kernel as ConsoleKernel;

class Kernel extends ConsoleKernel
{
    /**
     * The Artisan commands provided by your application.
     *
     * @var array
     */
    protected $commands = [
        '\App\Console\Commands\NotifyEmployee',
        '\App\Console\Commands\AddEmployeeLeaves',
        '\App\Console\Commands\AddEmployeePayslip',
        '\App\Console\Commands\AddEmployeeAttendanceReport',
        '\App\Console\Commands\SendSetPasswordEmail',
        '\App\Console\Commands\SendNewJoiningReport',
        '\App\Console\Commands\SendSeparationReport',
        '\App\Console\Commands\SendProbationEndingReport',
    ];

    /**
     * Define the application's command schedule.
     *
     * @param  \Illuminate\Console\Scheduling\Schedule  $schedule
     * @return void
     */
    protected function schedule(Schedule $schedule)
    {
         // $schedule->command('employee:notify')->hourly();
         $schedule->command('employee:addleaves')->monthlyOn(1, '1:00');
         $schedule->command('employee:new_joining_report')->dailyAt('12:00');
         $schedule->command('employee:separation_report')->dailyAt('12:00');
         $schedule->command('employee:send_probation_end_report week')->dailyAt('12:00');
         $schedule->command('employee:send_probation_end_report day')->dailyAt('12:00');
         $schedule->command('employee:add_attendance_report')->everyMinute();
         // $schedule->command('employee:add_payslip')->everyMinute();
         // $schedule->command('employee:setpassword')->everyMinute();
    }

    /**
     * Register the Closure based commands for the application.
     *
     * @return void
     */
    protected function commands()
    {
        require base_path('routes/console.php');
    }
}
