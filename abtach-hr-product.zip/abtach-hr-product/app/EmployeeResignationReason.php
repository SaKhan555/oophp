<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class EmployeeResignationReason extends Model
{
	protected $guarded = ['id'];

	// has many resignations
	public function resignations()
	{
		return $this->hasMany(EmployeeResignation::class, 'reason_id', 'id');
	}
}
