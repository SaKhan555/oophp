<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AgentFactor extends Model
{
	protected $table = 'agent_factors';
    protected $guarded = ['id'];
}
