<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class EmployeeLeaveType extends Model
{
    //
}
