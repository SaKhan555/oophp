<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Contracts\Queue\ShouldQueue;
use App\EmployeeGrievanceComment;

class EmployeeGrievanceCommentEmail extends Mailable
{
    use Queueable, SerializesModels;

    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct(EmployeeGrievanceComment $grievance_comment)
    {
        $this->grievance_comment = $grievance_comment;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        $grievance_comment = $this->grievance_comment;
        $grievance = $grievance_comment->grievance;
        $employee = $grievance->employee;
        return $this->subject("Grievance Comment")
                    ->markdown('admin.emails.employee.grievance.comment')
                    ->with([
                        'grievance_comment' => $grievance_comment,
                        'grievance' => $grievance,
                        'employee' => $employee
                    ]);
    }
}
