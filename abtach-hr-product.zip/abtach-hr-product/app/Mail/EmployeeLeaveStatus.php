<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Contracts\Queue\ShouldQueue;
use App\EmployeeLeaveApplication;
use App\EmployeeLeaveApproval;
use App\Employee;

class EmployeeLeaveStatus extends Mailable
{
    use Queueable, SerializesModels;

    /**
     * The leave_application instance.
     *
     * @var EmployeeLeaveApplication
     */
    protected $leave_application;
    /**
     * The employee instance.
     *
     * @var EmployeeLeaveApplication
     */
    protected $employee;
    /**
     * The employee_leave_approval instance.
     *
     * @var EmployeeLeaveApplication
     */
    protected $leave_approval;

    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct(EmployeeLeaveApplication $leave_application,EmployeeLeaveApproval $leave_approval, Employee $employee)
    {
        $this->leave_application = $leave_application;
        $this->leave_approval = $leave_approval;
        $this->employee = $employee;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        $employee = $this->employee;
        $leave_application = $this->leave_application;
        $leave_approval = $this->leave_approval;
        $status = ($leave_approval->status) ? 'approved' : 'disapproved';
        $comments = $leave_approval->comments;
        return $this->subject("Leave Application has been ".$status."!")->from(config('app.hr_email'))
                ->view('admin.emails.employee.leave_status')->with([
                    'leave_application' => $leave_application,
                    'leave_approval' => $leave_approval,
                    'employee' => $employee,
                    'status' => $status,
                    'comments' => $comments
                ]);
    }
}
