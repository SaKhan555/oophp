<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Contracts\Queue\ShouldQueue;
use App\Employee;
use App\EmployeeShiftTiming;

class NotifyEmployeeShift extends Mailable
{
    use Queueable, SerializesModels;

    /**
     * @var Employee
     */
    public $employee;
    /**
     * @var EmployeeShiftTiming
     */
    public $employee_shift_timing;
    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct(Employee $employee, EmployeeShiftTiming $employee_shift_timing)
    {
        $this->employee = $employee;
        $this->employee_shift_timing = $employee_shift_timing;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        return $this->subject('Shift Timings Changed')
                    ->from(config('app.hr_email'))
                    ->view('admin.emails.employee.shift_timing')->with([
                        'employee_shift_timing' => $this->employee_shift_timing,
                        'employee' => $this->employee
                    ]);
    }
}
