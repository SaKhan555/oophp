<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Contracts\Queue\ShouldQueue;
use App\Employee;
use App\EmployeeResignation;

class EmployeeResignationEmail extends Mailable
{
    use Queueable, SerializesModels;

    /**
     * @var Employee
     */
    public $employee;
    /**
     * @var EmployeeResignation
     */
    public $resignation;
    /**
     * @var effective_date
     */
    public $effective_date;
    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct(Employee $employee, EmployeeResignation $resignation)
    {
        $this->employee = $employee;
        $this->resignation = $resignation;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        $employee = $this->employee;
        $resignation = $this->resignation;
        return $this->subject('Resignation Letter')->markdown('admin.emails.employee.resignation')->with([
            'employee' => $employee,
            'resignation' => $resignation
        ]);
    }
}
