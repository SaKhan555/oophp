<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Contracts\Queue\ShouldQueue;
use App\EmployeeReview;

class EmployeeReviewEmail extends Mailable
{
    use Queueable, SerializesModels;

    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct(EmployeeReview $review)
    {
        $this->review = $review;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        $review = $this->review;
        $employee = $review->by_employee;
        return $this->subject("Employee Review")
                    ->markdown('admin.emails.employee.employee_review')
                    ->with([
                        'review' => $review,
                        'employee' => $employee
                    ]);
    }
}
