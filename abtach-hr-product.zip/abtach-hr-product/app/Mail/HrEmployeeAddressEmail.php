<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Contracts\Queue\ShouldQueue;
use App\Employee;

class HrEmployeeAddressEmail extends Mailable
{
    use Queueable, SerializesModels;
    /**
     * @var Employee
     */
    public $employee;
     /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct(Employee $employee)
    {
        $this->employee = $employee;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
         $employee = $this->employee;
        return $this->subject('Update Address')
                    ->from('hr@abtach.com')
                    ->view('admin.emails.hr.employee_address')->with([
                        'employee' => $employee
                    ]);
    }
}
