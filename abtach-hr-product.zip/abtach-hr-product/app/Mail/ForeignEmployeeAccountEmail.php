<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Contracts\Queue\ShouldQueue;
use App\ForeignAgent;

class ForeignEmployeeAccountEmail extends Mailable
{
    use Queueable, SerializesModels;

    private $foreign_agent;
    private $password;
    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct(ForeignAgent $foreign_agent, $password)
    {
        $this->foreign_agent = $foreign_agent;
        $this->password = $password;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        return $this->from('noreply@payment-global.com', 'Payment System')->subject('Account Details')
                    ->view('admin.emails.foreign_agent.account')
                    ->with([
                        'agent' => $this->foreign_agent,
                        'password' => $this->password
                    ]);
    }
}
