<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Contracts\Queue\ShouldQueue;
use App\EmployeeTicket;
use App\EmployeeTicketCategory;

class EmployeeTicketEmail extends Mailable
{
    use Queueable, SerializesModels;


    /**
     * @var EmployeeTicket
     */
    public $ticket;
    /**
     * @var EmployeeTicketCategory
     */
    public $ticket_category;
    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct(EmployeeTicketCategory $ticket_category, EmployeeTicket $ticket)
    {
        $this->ticket_category = $ticket_category;
        $this->ticket = $ticket;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        $ticket_category = $this->ticket_category;
        $ticket = $this->ticket;
        $employee = $ticket->employee;
        return $this->from($ticket_category->email)->subject('Ticket - '.$ticket->subject)->markdown('admin.emails.employee.ticket')->with([
            'ticket_category' => $ticket_category,
            'ticket' => $ticket,
            'employee' => $employee
        ]);
    }
}
