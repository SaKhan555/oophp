<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Contracts\Queue\ShouldQueue;
use App\EmployeeGrievance;

class EmployeeGrievanceEmail extends Mailable
{
    use Queueable, SerializesModels;

    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct(EmployeeGrievance $grievance)
    {
        $this->grievance = $grievance;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        $grievance = $this->grievance;
        $employee = $grievance->employee;
        return $this->subject("Grievance")
                    ->markdown('admin.emails.employee.grievance.grievance')
                    ->with([
                        'grievance' => $grievance,
                        'employee' => $employee
                    ]);
    }
}
