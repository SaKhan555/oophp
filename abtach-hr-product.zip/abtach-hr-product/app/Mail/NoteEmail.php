<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Contracts\Queue\ShouldQueue;
use App\Note;
use App\EmailLog;

class NoteEmail extends Mailable
{
    use Queueable, SerializesModels;

    /**
     * @var EmployeeNote
     */
    public $note;
    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct(Note $note)
    {
        $this->note = $note;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        $note = $this->note;
        $subject = ($note->title) ? 'Announcement - '.$note->title : 'Announcement';
        return $this->subject($subject)->markdown('admin.emails.employee.note')->with(['note' => $note]);
    }
}
