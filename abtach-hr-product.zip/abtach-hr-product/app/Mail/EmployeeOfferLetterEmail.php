<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Contracts\Queue\ShouldQueue;
use App\EmployeeGrievance;

class EmployeeOfferLetterEmail extends Mailable
{
    use Queueable, SerializesModels;

    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct($file_url, $data)
    {
        $this->file_url = $file_url;
        $this->data = $data;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        $data = $this->data;
        $file_url = $this->file_url;
        return $this->subject("Offer Letter")
                    ->attach($file_url)
                    ->markdown('admin.emails.employee.offer_letter')
                    ->with([
                        'data' => $data,
                    ]);
    }
}
