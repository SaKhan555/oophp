<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Contracts\Queue\ShouldQueue;
use App\Employee;
use App\EmailLog;

class NotifyEmployeeNoticePeriod extends Mailable
{
    use Queueable, SerializesModels;

    /**
     * @var Employee
     */
    public $employee;
    /**
     * @var end_date
     */
    public $end_date;
    /**
     * @var subject
     */
    public $subject;
    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct(Employee $employee, $end_date, $subject='Notice Period')
    {
        $this->employee = $employee;
        $this->end_date = formatDate($end_date,'d F Y');
        $this->subject = $subject;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        $employee = $this->employee;
        $end_date = $this->end_date;
        EmailLog::create([
            'employee_id' => $employee->id,
            'email' => $employee->email,
            'content' => '',
            // 'content' => htmlspecialchars(view('admin.emails.employee.noticeperiod')->with([
            //                 'end_date' => $end_date,
            //                 'employee' => $employee,
            //             ])),
            'reason' => 'employee notice period'
        ]);
        return $this->subject($this->subject)
            ->markdown('admin.emails.employee.noticeperiod')->with([
                'employee' => $employee,
                'end_date' => $end_date
        ]);
    }
}
