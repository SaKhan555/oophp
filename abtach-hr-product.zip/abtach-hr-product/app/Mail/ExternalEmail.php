<?php

namespace App\Mail;

use Illuminate\Http\Request;
use Carbon\Carbon;
use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Contracts\Queue\ShouldQueue;

class ExternalEmail extends Mailable
{
    use Queueable, SerializesModels;

    /**
     * @var
     */
	public $data_content;
    /**
     * Create a new message instance.
     *
     * @param PaymentHistory $salary_slip
     * @param $payslip
     */
    public function __construct($data_content)
    {
      
		$this->data_content = $data_content;

    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
		$file = null;
		if(isset($this->data_content['attachment'])){
			$file = public_path('/uploads/external/'.$this->data_content['attachment']);
		}

         $email = $this->from('Younus.Dawood@abtach.org', 'Younus Dawood')
            ->subject($this->data_content['subject']);
		if(isset($this->data_content['attachment'])){
			$file = public_path('/uploads/external/'.$this->data_content['attachment']);
			$email = $email->attach($file);
		}
			
         $email->view('admin.emails.external.default');
    }
}
