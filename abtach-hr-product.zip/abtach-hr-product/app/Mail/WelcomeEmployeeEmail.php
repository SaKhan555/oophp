<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Contracts\Queue\ShouldQueue;
use App\Employee;
use App\EmployeeDepartmentAssign;

class WelcomeEmployeeEmail extends Mailable
{
    use Queueable, SerializesModels;

     /**
     * @var Employee
     */
    public $employee;
    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct(Employee $employee)
    {
        $this->employee = $employee;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        $employee = $this->employee;
        $email_template = \App\EmailTemplate::find(1);
        $content = str_replace([
            '@firstname@',
            '@lastname@',
            '@designation@',
            '@department@',
            '@reportingauthority@',
            '@reportingauthoritydesignation@',
        ], [
            $employee->full_name,
            $employee->father_name,
            $employee->designation,
            $employee->department,
            $employee->manager_employee->full_name,
            $employee->manager_employee->designation
        ], $email_template->content);
        return $this->subject('Welcoming '.$employee->full_name)
                    ->view('admin.emails.employee.welcome')->with([
                        'employee' => $employee,
                        'content' => $content
                    ]);
    }
}
