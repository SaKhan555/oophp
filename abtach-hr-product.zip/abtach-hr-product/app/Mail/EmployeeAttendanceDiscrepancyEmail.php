<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Contracts\Queue\ShouldQueue;
use App\EmployeeAttendanceDiscrepancy;
use App\Employee;

class EmployeeAttendanceDiscrepancyEmail extends Mailable
{
    use Queueable, SerializesModels;

    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct(Employee $employee, EmployeeAttendanceDiscrepancy $discrepancy)
    {
        $this->discrepancy = $discrepancy;
        $this->employee = $employee;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        $employee = $this->employee;
        $manager = $employee->manager_employee;
        $discrepancy = $this->discrepancy;
        $attendance = $discrepancy->attendance;
        $attendance_date = ($attendance) ? $attendance->created_at->format('d M Y') : formatDate($discrepancy->attendance_date, 'd M Y');
        return $this->subject("Attendance Discrepancy")
                    ->markdown('admin.emails.employee.attendance_discrepancy')
                    ->with([
                        'discrepancy' => $discrepancy,
                        'attendance' => $attendance,
                        'employee' => $employee,
                        'manager' => $manager,
                        'attendance_date' => $attendance_date
                    ]);
    }
}
