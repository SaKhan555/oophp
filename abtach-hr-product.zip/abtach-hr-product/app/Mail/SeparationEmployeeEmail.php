<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Contracts\Queue\ShouldQueue;
use App\Employee;

class SeparationEmployeeEmail extends Mailable
{
    use Queueable, SerializesModels;

    public $separations;
    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct($separations)
    {
        $this->separations = $separations;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        $separations = $this->separations;
        return $this->subject("Separations For Tomorrow")->markdown('admin.emails.employee.separation_report')->with(['separations' => $separations]);
    }
}
