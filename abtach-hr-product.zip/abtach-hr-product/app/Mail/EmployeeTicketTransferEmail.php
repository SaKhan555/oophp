<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Contracts\Queue\ShouldQueue;
use App\EmployeeTicket;
use App\EmployeeTicketTransfer;
use App\EmployeeTicketCategory;

class EmployeeTicketTransferEmail extends Mailable
{
    use Queueable, SerializesModels;

    /**
     * @var EmployeeTicketCategory
     */
    public $ticket_transfer;
    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct(EmployeeTicketTransfer $ticket_transfer)
    {
        $this->ticket_transfer = $ticket_transfer;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        $ticket_transfer = $this->ticket_transfer;
        $ticket = $ticket_transfer->ticket;
        $employee = $ticket_transfer->employee;
        $ticket_category = $ticket->category;
        return $this->from($ticket_category->email)->subject('Ticket Transfered - '.$ticket->subject)->markdown('admin.emails.employee.ticket_transfer')->with([
            'ticket' => $ticket,
            'employee' => $employee,
            'ticket_transfer' => $ticket_transfer,
            'ticket_category' => $ticket_category
        ]);
    }
}
