<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Contracts\Queue\ShouldQueue;
use App\Employee;
use App\EmployeeDepartmentAssign;
use App\EmailLog;

class NotifyEmployeeDepartment extends Mailable
{
    use Queueable, SerializesModels;

     /**
     * @var Employee
     */
    public $employee;
    /**
     * @var EmployeeDepartmentAssign
     */
    public $employee_department;
    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct(Employee $employee, EmployeeDepartmentAssign $employee_department)
    {
        $this->employee = $employee;
        $this->employee_department = $employee_department;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        $employee = $this->employee;
        // create log
        EmailLog::create([
            'employee_id' => $employee->id,
            'email' => $employee->email,
            'content' => htmlspecialchars(view('admin.emails.employee.department_change')->with([
                        'employee_department' => $this->employee_department,
                        'employee' => $employee
                    ])),
            'reason' => 'department changed'
        ]);

        return $this->subject('Department Changed')
                    ->from(config('app.hr_email'))
                    ->view('admin.emails.employee.department_change')->with([
                        'employee_department' => $this->employee_department,
                        'employee' => $employee
                    ]);
    }
}
