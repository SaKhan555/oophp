<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Contracts\Queue\ShouldQueue;
use App\Employee;
use App\EmailLog;

class NotifyEmployeeSeparation extends Mailable
{
    use Queueable, SerializesModels;

    /**
     * @var Employee
     */
    public $employee;
    /**
     * @var effective_date
     */
    public $effective_date;
    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct(Employee $employee, $effective_date)
    {
        $this->employee = $employee;
        $this->effective_date = formatDate($effective_date,'d F Y');
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        $employee = $this->employee;
        $effective_date = $this->effective_date;
        EmailLog::create([
            'employee_id' => $employee->id,
            'email' => $employee->email,
            'content' => '',
            // 'content' => htmlspecialchars(view('admin.emails.employee.separation')->with([
            //                 'effective_date' => $effective_date,
            //                 'employee' => $employee,
            //             ])),
            'reason' => 'employee notice period'
        ]);
        return $this->subject('Separation Announcement')->markdown('admin.emails.employee.separation')->with([
            'employee' => $employee,
            'effective_date' => $effective_date
        ]);
    }
}
