<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Contracts\Queue\ShouldQueue;
use App\Employee;
use App\EmployeeResignationComment;

class ResignationCommentEmail extends Mailable
{
    use Queueable, SerializesModels;

    /**
     * @var ResignationComment
     */
    public $resignation_comment;
    /**
     * @var Employee
     */
    public $employee;
    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct(EmployeeResignationComment $resignation_comment, Employee $employee)
    {
        $this->employee = $employee;
        $this->resignation_comment = $resignation_comment;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        $employee = $this->employee;
        $resignation_comment = $this->resignation_comment;
        $resignation = $resignation_comment->resignation;
        $status = ($resignation_comment->status) ? 'approved' : 'disapproved';
        return $this->subject("Your resignation has been $status")
            ->markdown('admin.emails.employee.resignation.comment')->with([
                'employee' => $employee,
                'resignation_comment' => $resignation_comment,
                'resignation' => $resignation,
                'status' => $status
        ]);
    }
}
