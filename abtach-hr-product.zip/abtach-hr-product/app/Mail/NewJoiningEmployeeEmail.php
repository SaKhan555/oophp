<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Contracts\Queue\ShouldQueue;
use App\Employee;

class NewJoiningEmployeeEmail extends Mailable
{
    use Queueable, SerializesModels;

    public $new_joinings;
    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct($new_joinings)
    {
        $this->new_joinings = $new_joinings;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        $new_joinings = $this->new_joinings;
        return $this->subject("Joinings For Tomorrow")->markdown('admin.emails.employee.new_joining_report')->with(['new_joinings' => $new_joinings]);
    }
}
