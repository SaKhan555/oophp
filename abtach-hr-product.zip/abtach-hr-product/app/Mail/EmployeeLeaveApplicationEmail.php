<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Contracts\Queue\ShouldQueue;
use App\EmployeeLeaveApplication;
use App\Employee;

class EmployeeLeaveApplicationEmail extends Mailable
{
    use Queueable, SerializesModels;
    /**
     * The leave_application instance.
     *
     * @var EmployeeLeaveApplication
     */
    protected $leave_application;
    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct(EmployeeLeaveApplication $leave_application)
    {
        $this->leave_application = $leave_application;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        $leave_application = $this->leave_application;
        $employee = $leave_application->employee;
        $employee_manager = $employee->manager_employee;
        return $this->subject("Leave Application")->from(config('app.hr_email'))
                ->view('admin.emails.employee.leave_application')->with([
                    'leave_application' => $leave_application,
                    'employee' => $employee,
                    'employee_manager' => $employee_manager
                ]);
    }
}
