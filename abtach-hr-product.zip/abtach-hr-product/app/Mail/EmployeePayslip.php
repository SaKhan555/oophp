<?php

namespace App\Mail;

use App\PaymentHistory;
use Carbon\Carbon;
use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Contracts\Queue\ShouldQueue;

class EmployeePayslip extends Mailable
{
    use Queueable, SerializesModels;
    /**
     * @var
     */
    public $salary_slip;
    /**
     * @var
     */
    public $payslip;

    /**
     * Create a new message instance.
     *
     * @param PaymentHistory $salary_slip
     * @param $payslip
     */
    public function __construct(PaymentHistory $salary_slip, $payslip)
    {
        //
        $this->salary_slip = $salary_slip;
        $this->payslip = $payslip;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        $file = public_path('/uploads/payslip/'.$this->payslip);	
         $this->from(config('app.hr_email'), config('general.accounts.name'))
            ->subject('Salary Slip for the month of '. Carbon::parse($this->salary_slip->salary_month)->format('F Y'))
            ->attach($file)
            ->markdown('admin.emails.employee.payslip');
    }
}
