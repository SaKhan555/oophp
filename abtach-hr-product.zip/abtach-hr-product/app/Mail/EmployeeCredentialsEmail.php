<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Contracts\Queue\ShouldQueue;
use App\Employee;

class EmployeeCredentialsEmail extends Mailable
{
    use Queueable, SerializesModels;

    /**
     * @var Employee
     */
    public $employee;
    /**
     * @var EmployeeDepartmentAssign
     */
    public $password;

    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct(Employee $employee, $password)
    {
        $this->employee = $employee;
        $this->password = $password;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        $employee = $this->employee;
        return $this->subject('Login Credentials')
                    ->from(config('app.hr_email'))
                    ->view('admin.emails.employee.credentials')->with([
                        'password' => $this->password,
                        'employee' => $employee
                    ]);
    }
}
