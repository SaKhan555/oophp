<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Contracts\Queue\ShouldQueue;
use App\Employee;

class ProbationEndReportEmail extends Mailable
{
    use Queueable, SerializesModels;

    public $employees;
    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct($employees)
    {
        $this->employees = $employees;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        $employees = $this->employees;
        return $this->subject("Probation Ending Report")->markdown('admin.emails.employee.probation_ending_report')->with(['employees' => $employees]);
    }
}
