<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Contracts\Queue\ShouldQueue;
use App\Employee;
use App\EmployeeDepartmentAssign;
use App\EmailLog;

class NotifyInsuranceEmployee extends Mailable
{
    use Queueable, SerializesModels;

     /**
     * @var Employee
     */
    public $employee;
    /**
     * @var EmployeeDepartmentAssign
     */
    public $employee_department;
    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct(Employee $employee)
    {
        $this->employee = $employee;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        $employee = $this->employee;
     
        return $this->subject('Employee ('.$this->employee->employee_id.') - Insurance Information Received!')
                    ->view('admin.emails.employee.insurance_information')->with([
                        'employee' => $employee
                    ]);
    }
}
