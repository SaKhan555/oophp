<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Contracts\Queue\ShouldQueue;
use App\Employee;
use App\EmployeeManager;
use App\EmailLog;

class NotifyEmployeeReporting extends Mailable
{
    use Queueable, SerializesModels;

     /**
     * @var Employee
     */
    public $employee;
    /**
     * @var EmployeeManager
     */
    public $employee_manager;
    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct(Employee $employee, EmployeeManager $employee_manager)
    {
        $this->employee = $employee;
        $this->employee_manager = $employee_manager;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        $employee = $this->employee;
        // create log
        EmailLog::create([
            'employee_id' => $employee->id,
            'email' => $employee->email,
            'content' => htmlspecialchars(view('admin.emails.employee.manager_change')->with([
                        'employee_manager' => $this->employee_manager,
                        'employee' => $employee
                    ])),
            'reason' => 'manager changed'
        ]);
        
        return $this->subject('Reporting Authority Changed ')
                    ->from(config('app.hr_email'))
                    ->view('admin.emails.employee.manager_change')->with([
                        'employee_manager' => $this->employee_manager,
                        'employee' => $employee
                    ]);
    }
}
