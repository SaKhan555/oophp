<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Contracts\Queue\ShouldQueue;
use App\EmployeeAttendance;
use App\EmployeeAttendanceDiscrepancyComment;
use App\Employee;

class EmployeeAttendanceDiscrepancyCommentEmail extends Mailable
{
    use Queueable, SerializesModels;

    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct(EmployeeAttendanceDiscrepancyComment $discrepancy_comment)
    {
        $this->discrepancy_comment = $discrepancy_comment;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        $discrepancy_comment = $this->discrepancy_comment;
        $discrepancy = $discrepancy_comment->discrepancy;
        $employee = $discrepancy->employee;
        $manager = $discrepancy_comment->manager;
        $attendance = $discrepancy->attendance;
        $status = ($discrepancy_comment->status) ? 'Approved' : 'Disapproved';
        return $this->subject("Attendance Discrepancy $status")
                    ->markdown('admin.emails.employee.attendance_discrepancy_comment')
                    ->with([
                        'discrepancy' => $discrepancy,
                        'attendance' => $attendance,
                        'employee' => $employee,
                        'manager' => $manager,
                        'status' => $status,
                        'discrepancy_comment' => $discrepancy_comment
                    ]);
    }
}
