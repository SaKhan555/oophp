<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Contracts\Queue\ShouldQueue;
use App\EmployeeTicketComment;

class EmployeeTicketReopenEmployeeEmail extends Mailable
{
    use Queueable, SerializesModels;


    /**
     * @var EmployeeComment
     */
    public $ticket_comment;
    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct(EmployeeTicketComment $ticket_comment)
    {
        $this->ticket_comment = $ticket_comment;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        $ticket_comment = $this->ticket_comment;
        $ticket = $ticket_comment->ticket;
        $ticket_category = $ticket->category;
        $employee = $ticket->employee;
        return $this->from($ticket_category->email)->subject('Ticket - '.$ticket->subject.' - Re-opened')->markdown('admin.emails.employee.ticket_reopen_employee')->with([
            'ticket_comment' => $ticket_comment,
            'ticket' => $ticket,
            'employee' => $employee,
            'ticket_category' => $ticket_category
        ]);
    }
}
