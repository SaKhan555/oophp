<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\Traits\RecordActivity;
use Illuminate\Database\Eloquent\SoftDeletes;

class Note extends Model
{
    use RecordActivity, SoftDeletes;

    protected $guarded = ['id'];
    protected $casts = [
        'employee_ids' => 'array',
        'department_ids' => 'array',
    ];
    // get conten attribute
    public function getContentAttribute($content)
    {
        return htmlspecialchars_decode($content);
    }
    // belongs to a user
    public function user()
    {
    	return $this->belongsTo(User::class, 'user_id');
    }
    // has many employees
    public function employees()
    {
        return $this->hasMany(EmployeeNote::class, 'note_id','id');
    }
    // employee notes
    public function employee_notes()
    {
        return $this->belongsToMany(Employee::class,'employee_notes');
    }
    // departments
    public function departments()
    {
        $department_ids = json_decode($this->department_ids);
        if($department_ids){
        	$department_ids = json_decode($this->department_ids);
            return implode(',',EmployeeDepartment::whereIn('id', $department_ids)->pluck('name')->toArray());
        }
    }

}
