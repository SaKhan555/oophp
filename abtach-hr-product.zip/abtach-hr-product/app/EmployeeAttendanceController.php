<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class EmployeeAttendanceController extends Model
{
    //
}
