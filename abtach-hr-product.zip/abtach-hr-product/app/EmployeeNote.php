<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class EmployeeNote extends Model
{
    use SoftDeletes;
    
    protected $guarded = ['id'];
    
   /**
    * belongs to a note
    */
   public function note_details()
   {
   		return $this->belongsTo(Note::class, 'note_id', 'id');
   }
   /**
    * belongs to a employee
    */
   public function employee_details()
   {
   		return $this->belongsTo(Employee::class, 'employee_id', 'id');
   }
}
