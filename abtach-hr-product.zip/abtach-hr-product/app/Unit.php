<?php
 
namespace App;

use Illuminate\Database\Eloquent\Model;

class Unit extends Model
{
    protected $guarded = ['id'];
    protected $casts = ['options'=>'json'];
    protected $hidden = [
        'agent_report', 'show_report','pl_report_status','pl_report_summary_status','cost_report_status', 'separate_report'
    ];
    public function scopeSearch($query)
    {
        $s = trim(request('s'));
        if($s) {
            $query = $query->where('name', 'LIKE', '%' . $s . '%')
                ->orWhere('key', 'LIKE', '%' . $s . '%');
        }

        return $query;

    }
    public function rules ($id=null, $merge=[]) {
        return array_merge(
            [
                'name' => 'required|unique:units,name' . ($id ? ",$id" : ''),
                'key' => 'required'
            ],
            $merge);
    }
	public function unit_employee()
    {
        return $this->belongsToMany(Employee::class, 'employee_units', 'unit_id',  'employee_id');
    }
}
