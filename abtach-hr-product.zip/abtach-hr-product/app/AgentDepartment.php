<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AgentDepartment extends Model
{
    protected $table = 'agent_departments';
   	protected $fillable = ['agent_id','department_id'];
}
