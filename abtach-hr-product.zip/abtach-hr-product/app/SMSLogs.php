<?php
namespace App;

use Illuminate\Database\Eloquent\Model;
use App\Traits\RecordActivity;

class SMSLogs extends Model
{
	use RecordActivity;
	
    protected $table = 'sms_logs';
    protected $guarded = ['id'];


}