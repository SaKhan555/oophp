<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class EmployeeFinalSettlement extends Model
{
	use SoftDeletes;
	
	protected $guarded = ['id'];

	// belongs to an employee
	public function employee()
	{
		return $this->belongsTo(Employee::class);
	}
	// belongs to status
	public function status()
	{
		return $this->belongsTo(EmployeeFinalSettlementStatus::class);
	}
	// search scope
	public function scopeSearch($query)
	{
		$status = request('status');
		$keyword = request('s');
		$employee_status = request('employee_status');
		if($status) {
			$query = $query->where('status_id', $status);
		}
		if($keyword){
			$query = $query->whereHas('employee', function($q) use($keyword){
				return $q->search();
			});
		}
		if($employee_status){
			if($employee_status == 'termination') {
				$query = $query->whereHas('employee', function($q){
					return $q = $q->whereHas('employee_status', function($q){
	                    return $q->where('type', 'termination');
	                });
				});
			} else {
				$query = $query->whereHas('employee', function($q) use($employee_status) {
					return $q->where('current_status', $employee_status);
				});
			}
		}
		return $query;
	}
	// employee status
	public function employee_status()
	{
		if($this->employee){
			$employee_current_status = $this->employee->employee_status()->first();
			switch ($employee_current_status->status) {
				case 'Notice Period':
					$employee_status = 'resigned';
					break;
				case 'Separation':
					if($employee_current_status->type == 'termination'){
						$employee_status = 'terminated';
					} else {
						$employee_status = 'separated';
					}
					break;
				default:
					$employee_status = $employee_current_status->status;
					break;
			}
			return $employee_status;
		}
	}
}
