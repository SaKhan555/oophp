<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Brand extends Model
{
    // belongs to many agents
    public function agents()
    {
    	return $this->belongsToMany(Agent::class);
    }
}
