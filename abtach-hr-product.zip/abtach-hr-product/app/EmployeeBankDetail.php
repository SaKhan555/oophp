<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class EmployeeBankDetail extends Model
{
	protected $fillable = ['employee_id', 'transit_number', 'financial_institution_number', 'account_number', 'void_cheque'];
}
