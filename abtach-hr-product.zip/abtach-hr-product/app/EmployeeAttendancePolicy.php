<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class EmployeeAttendancePolicy extends Model
{
	protected $guarded = ['id'];
	protected $casts = [
		'check_in_grace' => 'array',
		'check_out_grace' => 'array',
		'half_day_grace' => 'array',
	];
	protected $dates = [
		'effective_date'
	];
}
