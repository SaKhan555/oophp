<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class JobSubscription extends Model
{
    protected $guarded = ['id'];
}
