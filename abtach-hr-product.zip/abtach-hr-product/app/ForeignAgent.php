<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ForeignAgent extends Model
{
	protected $guarded = ['id'];

	// password text
	public function password_text()
	{
		return $this->hasOne(EmployeeForeignPassword::class);
	}
	// brand
	public function brand()
	{
		return $this->belongsTo(Brand::class);
	}
}
