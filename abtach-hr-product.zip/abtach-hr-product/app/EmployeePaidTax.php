<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class EmployeePaidTax extends Model
{
    protected $guarded = ['id'];
    protected $dates = ['month'];

    // bleongs to employee
    public function employee()
    {
    	return $this->belongsTo(Employee::class);
    }
}
