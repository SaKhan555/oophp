<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class EmployeeIncentive extends Model
{
    protected $guarded = ['id'];
    protected $dates = ['date'];

    public function employee()
    {
    	return $this->belongsTo(Employee::class);
    }
}
