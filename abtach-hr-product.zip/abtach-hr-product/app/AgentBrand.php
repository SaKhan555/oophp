<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AgentBrand extends Model
{
    const CREATED_AT = 'inserted_at';
    const UPDATED_AT = 'modified_at';

    protected $primaryKey = 'agent_brand_id';

    protected $guarded = ['id'];
    protected $table = 'agent_brands';
    // belongs to agent
    public function agent()
    {
    	return $this->belongsTo(Agent::class);
    }
    // belongs to brand
    public function brand()
    {
    	return $this->belongsTo(Brand::class);
    }
    // agent brand target
    public function target()
    {
        $agent = AgentTarget::where('agent_id' ,$this->agent_id)->where('brand_id', $this->brand_id)->latest()->first();
        if($agent){
            return $agent->target;
        }
    }
    // agent brand target date
    public function target_date()
    {
        $agent = AgentTarget::where('agent_id' ,$this->agent_id)->where('brand_id', $this->brand_id)->latest()->first();
        if($agent){
            return $agent->created_at->format('d/m/Y');
        }    
    }
    // targets
    public function targets()
    {
        $targets = AgentTarget::where('agent_id', $this->agent_id)->where('brand_id', $this->brand_id)->latest()->get();
        return $targets;
    }
}

