<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class EmployeeSalary extends Model
{
    protected $guarded = ['id'];
    protected $casts = [
    	'breakups' => 'array'
    ];
}
