<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class EmployeeAttendanceDiscrepancyComment extends Model
{
    protected $guarded = ['id'];

    // manager
    public function manager()
    {
    	return $this->belongsTo(Employee::class, 'manager_id');
    }
    // attendance
    public function attendance()
    {
    	return $this->belongsTo(EmployeeAttendance::class, 'attendance_id');
    }
    // discrepancy
    public function discrepancy()
    {
    	return $this->belongsTo(EmployeeAttendanceDiscrepancy::class, 'discrepancy_id');
    }
}
