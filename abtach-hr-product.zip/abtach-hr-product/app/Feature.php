<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Feature extends Model
{
	protected $table = 'portal_features';
	protected $fillable = ['status'];
}
