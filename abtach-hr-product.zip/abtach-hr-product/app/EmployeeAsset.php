<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\Traits\RecordActivity;

class EmployeeAsset extends Model
{
	use RecordActivity;

    protected $guarded = ['id'];
    protected $dates = ['effective_date', 'return_date'];

    // employee
    public function employee()
    {
    	return $this->belongsTo(Employee::class);
    }
    // asset category
    public function category()
    {
    	return $this->belongsTo(AssetCategory::class);
    }
}
