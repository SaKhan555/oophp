<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use App\Traits\RecordActivity;

class JobApplication extends Model
{
    use RecordActivity, SoftDeletes;
    
    protected $table = 'job_applications';
    protected $guarded = ['id'];

    public function scopeSearch($query)
    {
        $s = trim(request('s'));
        $status = request('status');
        $from = trim(request('from'));
        $to = trim(request('to'));
        if(request('category')) {
            $query = $query->where('career_job_id', request('category'));
        }
        if(!is_null($status)) {
            $query = $query->where('status', $status);
        } else {
            $query = $query->where('status', 1);
        }
        if($s) {
            $query = $query->where('name', 'LIKE', '%' . $s . '%')
                ->orWhere('phone', 'LIKE', '%' . $s . '%')
                ->orWhere('email', 'LIKE', '%' . $s . '%');
        }
        if($from && $to){
            $query = $query->whereBetween(\DB::raw('DATE(created_at)'), array($from, $to));
        }


        return $query;

    }


	
}
