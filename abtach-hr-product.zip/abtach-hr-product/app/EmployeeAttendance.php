<?php

namespace App;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;

class EmployeeAttendance extends Model
{
    protected $dates = ['checked_at'];
    protected $guarded = ['id'];
    public function employee()
    {
        return $this->belongsTo(Employee::class,'employee_id','employee_id');
    }
    public function employee_setting()
    {
        return $this->belongsTo(EmployeeSetting::class, 'employee_id','employee_id');
    }
    public function logs()
    {
        return $this->hasMany(EmployeeAttendanceLog::class);
    }
    // has one discrepancy
    public function discrepancy()
    {
        return $this->hasOne(EmployeeAttendanceDiscrepancy::class, 'attendance_id');
    }

    public function scopeSearch($query)
    {
        /* $s = trim(request('s'));
         if($s) {
             $query = $query->where('full_name', 'LIKE', '%' . $s . '%')
                 ->orWhere('email', 'LIKE', '%' . $s . '%');
         }*/
        if(request('employee_id')){
            $query = $query->where('employee_id', request('employee_id'));
        }
        if(request()->has('from') && request()->has('to')){
            $from = Carbon::createFromFormat('d/m/Y', request('from'))->toDateString();
            $to =  Carbon::createFromFormat('d/m/Y', request('to'))->toDateString();

            if($from != $to){
                $query = $query->whereBetween('checked_at', [$from, $to]);
            } else {
                $query = $query->whereDate('checked_at', '=', $to);
            }

        }
        return $query;

    }

    // status
    public function status()
    {
        return ($this->status == '01') ? 'Check In' : 'Check Out';
    }
    // details
    public function details()
    {
        $details = '';
        $employee = $this->employee;
        $checked_at = $this->checked_at;
        if($employee){
            $details = $employee->full_name.' ';
        }
        $details .= ' '.$this->status().' at '.formatDate($checked_at, 'h:i:s a').' on '.formatDate($checked_at, 'd M Y');
        return $details;
    }

    /**
     * create log
     */
    public function create_log($data = [])
    {
        $this->logs()->create(array_merge([
                'employee_id' => auth()->id(),
            ], $data));
    }
}
