<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\Traits\RecordActivity;

class EmployeeVehicle extends Model
{
	use RecordActivity;
    protected $guarded = ['id'];
    public function employee_detail()
    {
        return $this->hasOne(Employee::class, 'id', 'employee_id');
    }

	
}
