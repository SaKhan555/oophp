<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PortalSetting extends Model
{
    protected $fillable = ['setting_key', 'setting_value'];

    /**
     * type
     */
    public function type()
    {
    	return $this->belongsTo(PortalSettingType::class, 'type_id');
    }
}
