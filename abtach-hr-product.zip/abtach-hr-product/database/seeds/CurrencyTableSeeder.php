<?php

use App\Currency;
use Illuminate\Database\Seeder;

class CurrencyTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $currencies = [
            ['name' => 'USD', 'symbol' => '$'],
            ['name' => 'EUR', 'symbol' => '€'],
            ['name' => 'JPY', 'symbol' => '¥'],
            ['name' => 'CAD', 'symbol' => '$'],
            ['name' => 'AUD', 'symbol' => '$'],
            ['name' => 'HKD', 'symbol' => '$'],
            ['name' => 'GBP', 'symbol' => '£'],
            ['name' => 'CNY', 'symbol' => '¥']
        ];
        foreach ($currencies as $currency) {
            Currency::create([
                'name' => $currency['name'],
                'symbol' =>  $currency['symbol']
            ]);
        }
    }
}
