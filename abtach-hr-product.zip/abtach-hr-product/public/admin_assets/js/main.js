$(document).ready(function(){
	$('.editable').editable();
	$('.editable-date').on('click', function(){
        $('.editable-input .input-medium').datepicker({
        	autoclose: true
        }).blur();
        $('.editable-input .form-control').datepicker({
        	autoclose: true
        }).blur();
    });
});